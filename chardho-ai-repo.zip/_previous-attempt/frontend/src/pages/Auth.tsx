import { FormEvent, useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../ctx';
import { Msgs, useAction } from '../ui';

function Frame({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="center"><div className="card auth">
      <div className="brand">CHARDHO <span>AI</span></div>
      <p className="muted">CREATE. AUTOMATE. PROMOTE. GROW.</p>
      <h1>{title}</h1>{children}
      <p className="muted">Powered by CHARDHO LLP</p>
    </div></div>
  );
}

export function Login() {
  const { refreshUser } = useApp();
  const nav = useNavigate();
  const a = useAction();
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [needsVerify, setNeedsVerify] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setNeedsVerify(false);
    const r = await a.run(() => api('/auth/login', { body: { email, password } }));
    if (r) { await refreshUser(); nav('/dashboard'); }
    else if (a.error.includes('verify')) setNeedsVerify(true);
  };
  const google = async () => { window.location.href = '/api/auth/google'; };
  return (
    <Frame title="Sign in">
      <form onSubmit={submit}>
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
        <label>Password<input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
        <Msgs a={a} />
        {a.error.toLowerCase().includes('verify') && <button type="button" className="secondary" onClick={() => api('/auth/resend-verification', { body: { email } }).then(() => a.setOk('Verification link sent if the account exists.'))}>Resend verification email</button>}
        <div className="row" style={{ marginTop: '.8rem' }}>
          <button disabled={a.busy}>{a.busy ? 'Signing in…' : 'Sign in'}</button>
          <button type="button" className="secondary" onClick={google}>Continue with Google</button>
        </div>
      </form>
      {needsVerify && null}
      <p><Link to="/forgot">Forgot password?</Link> · <Link to="/register">Create free account</Link></p>
    </Frame>
  );
}

export function Register() {
  const a = useAction();
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [done, setDone] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); const r = await a.run(() => api('/auth/register', { body: f })); if (r) setDone(true); };
  if (done) return <Frame title="Check your email"><p>If this email can be registered, we sent a verification link. Verify it, then sign in.</p><Link to="/login">Back to sign in</Link></Frame>;
  return (
    <Frame title="Create your free account">
      <form onSubmit={submit}>
        <label>Name<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoComplete="name" /></label>
        <label>Email<input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} autoComplete="email" /></label>
        <label>Password<input type="password" required minLength={10} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" /></label>
        <p className="muted">At least 10 characters with upper case, lower case and a number.</p>
        <Msgs a={a} /><button disabled={a.busy}>{a.busy ? 'Creating…' : 'Create account'}</button>
      </form>
      <p>Already registered? <Link to="/login">Sign in</Link></p>
    </Frame>
  );
}

export function VerifyEmail() {
  const [sp] = useSearchParams(); const a = useAction();
  useEffect(() => { void a.run(() => api('/auth/verify-email', { body: { token: sp.get('token') } }), 'Email verified.'); /* eslint-disable-next-line */ }, []);
  return <Frame title="Email verification">{a.busy ? <p>Verifying…</p> : <Msgs a={a} />}<Link to="/login">Go to sign in</Link></Frame>;
}

export function Forgot() {
  const a = useAction(); const [email, setEmail] = useState('');
  return (
    <Frame title="Reset your password">
      <form onSubmit={(e) => { e.preventDefault(); void a.run(() => api('/auth/forgot-password', { body: { email } }), 'If the account exists, a reset link has been sent.'); }}>
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <Msgs a={a} /><button disabled={a.busy}>Send reset link</button>
      </form>
      <p><Link to="/login">Back to sign in</Link></p>
    </Frame>
  );
}

export function Reset() {
  const [sp] = useSearchParams(); const a = useAction(); const [password, setPassword] = useState('');
  return (
    <Frame title="Choose a new password">
      <form onSubmit={(e) => { e.preventDefault(); void a.run(() => api('/auth/reset-password', { body: { token: sp.get('token'), password } }), 'Password updated. You can sign in now.'); }}>
        <label>New password<input type="password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" /></label>
        <Msgs a={a} /><button disabled={a.busy}>Update password</button>
      </form>
      <p><Link to="/login">Sign in</Link></p>
    </Frame>
  );
}
