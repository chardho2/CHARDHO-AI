import { useState } from 'react';
import { api } from '../api';
import { useApp } from '../ctx';
import { Alert, Badge, Msgs, useAction, useLoad } from '../ui';

const NoBiz = () => <Alert kind="warn">Create a business profile first (Business menu).</Alert>;

export function Agents() {
  const { business } = useApp();
  const agents = useLoad(() => api<{ items: { key: string; name: string; description: string }[] }>('/agents'), []);
  const hist = useLoad(() => business ? api<{ items: any[] }>(`/agents/tasks?businessId=${business.id}`) : Promise.resolve({ items: [] }), [business?.id]);
  const a = useAction();
  const [request, setRequest] = useState(''); const [picked, setPicked] = useState<string[]>([]); const [result, setResult] = useState<any>(null);
  if (!business) return <NoBiz />;
  const run = async () => {
    const r = await a.run(() => api('/agents/execute', { body: { businessId: business.id, request, agents: picked.length ? picked : undefined, language: business.languages[0] } }));
    if (r) { setResult(r); void hist.reload(); }
  };
  return (
    <>
      <h1>AI agents</h1>
      <p className="hero">Describe what you need. The orchestrator picks the right agents (or choose them yourself). Agents prepare drafts and advice; they cannot publish or contact anyone.</p>
      <div className="card">
        <label>What should the team do?<textarea value={request} onChange={(e) => setRequest(e.target.value)} placeholder="e.g. Plan a launch campaign for our new product and write a LinkedIn announcement" /></label>
        <details><summary>Choose agents manually (optional, max 3)</summary>
          <div className="row" style={{ marginTop: '.5rem' }}>{agents.data?.items.map((g) => (
            <label key={g.key} style={{ display: 'flex', gap: '.35rem', alignItems: 'center', fontWeight: 400 }}>
              <input type="checkbox" style={{ width: 'auto' }} checked={picked.includes(g.key)} disabled={!picked.includes(g.key) && picked.length >= 3} onChange={(e) => setPicked(e.target.checked ? [...picked, g.key] : picked.filter((k) => k !== g.key))} />{g.name}</label>
          ))}</div></details>
        <Msgs a={a} />
        <button disabled={a.busy || request.trim().length < 3} onClick={run} style={{ marginTop: '.6rem' }}>{a.busy ? 'Agents are working…' : 'Run agents'}</button>
      </div>
      {result && result.results.map((r: any) => (
        <div className="card" key={r.taskId}><h2>{agents.data?.items.find((g) => g.key === r.agent)?.name ?? r.agent}</h2><pre className="out">{r.output}</pre>
          <button className="secondary" onClick={() => navigator.clipboard.writeText(r.output)}>Copy</button></div>
      ))}
      <div className="card"><h2>Execution history</h2>
        {hist.error && <Alert>{hist.error}</Alert>}
        <table><thead><tr><th>Agent</th><th>Status</th><th>Model</th><th>Tokens</th><th>When</th></tr></thead><tbody>
          {hist.data?.items.map((t) => <tr key={t.id}><td>{t.agentKey}</td><td><Badge v={t.status} />{t.error && <div className="muted">{t.error}</div>}</td><td>{t.provider ?? '–'}</td><td>{t.promptTokens + t.outputTokens}</td><td>{new Date(t.createdAt).toLocaleString()}</td></tr>)}
        </tbody></table></div>
    </>
  );
}

const TYPES = ['INSTAGRAM_POST', 'FACEBOOK_POST', 'LINKEDIN_POST', 'X_POST', 'YOUTUBE_DESCRIPTION', 'REELS_SCRIPT', 'YOUTUBE_SCRIPT', 'BLOG_ARTICLE', 'SEO_ARTICLE', 'PRODUCT_DESCRIPTION', 'AD_COPY', 'CAMPAIGN', 'EMAIL_NEWSLETTER', 'WHATSAPP_DRAFT'];

export function Studio() {
  const { business } = useApp();
  const a = useAction();
  const items = useLoad(() => business ? api<{ items: any[] }>(`/content?businessId=${business.id}`) : Promise.resolve({ items: [] }), [business?.id]);
  const [f, setF] = useState({ type: 'LINKEDIN_POST', topic: '', tone: 'professional', audience: '', length: 'medium', count: 1, language: business?.languages[0] ?? 'en' });
  const [edit, setEdit] = useState<{ id: string; body: string; hashtags: string } | null>(null);
  if (!business) return <NoBiz />;
  const gen = () => a.run(async () => { await api('/content/generate', { body: { ...f, businessId: business.id, audience: f.audience || undefined } }); await items.reload(); }, 'Draft(s) created and saved.');
  const save = () => edit && a.run(async () => { await api(`/content/${edit.id}`, { method: 'PATCH', body: { body: edit.body, hashtags: edit.hashtags.split(/[ ,]+/).map((h) => h.replace(/^#/, '')).filter(Boolean) } }); setEdit(null); await items.reload(); }, 'Saved as a new version. Any earlier approval was invalidated.');
  const download = (c: any) => { const url = URL.createObjectURL(new Blob([c.currentVersion?.body ?? ''], { type: 'text/plain' })); Object.assign(document.createElement('a'), { href: url, download: `${c.type.toLowerCase()}.txt` }).click(); URL.revokeObjectURL(url); };
  return (
    <>
      <h1>Content studio</h1>
      <div className="card">
        <div className="grid">
          <label>Type<select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>{TYPES.map((t) => <option key={t} value={t}>{t.replace(/_/g, ' ').toLowerCase()}</option>)}</select></label>
          <label>Language<select value={f.language} onChange={(e) => setF({ ...f, language: e.target.value })}>{[...new Set([...(business.languages), 'en', 'hi', 'es', 'fr', 'de', 'pt', 'ar', 'te', 'ta'])].map((l) => <option key={l}>{l}</option>)}</select></label>
          <label>Tone<select value={f.tone} onChange={(e) => setF({ ...f, tone: e.target.value })}>{['professional', 'friendly', 'playful', 'bold', 'inspirational', 'formal'].map((t) => <option key={t}>{t}</option>)}</select></label>
          <label>Length<select value={f.length} onChange={(e) => setF({ ...f, length: e.target.value })}><option>short</option><option>medium</option><option>long</option></select></label>
          <label>Variants<select value={f.count} onChange={(e) => setF({ ...f, count: Number(e.target.value) })}>{[1, 2, 3, 4, 5].map((n) => <option key={n}>{n}</option>)}</select></label>
          <label>Audience<input value={f.audience} onChange={(e) => setF({ ...f, audience: e.target.value })} placeholder="default: your target audience" /></label>
        </div>
        <label>Topic<textarea value={f.topic} onChange={(e) => setF({ ...f, topic: e.target.value })} /></label>
        <Msgs a={a} /><button disabled={a.busy || f.topic.trim().length < 3} onClick={gen}>{a.busy ? 'Generating…' : f.count > 1 ? `Generate ${f.count} variants` : 'Generate'}</button>
      </div>
      {items.error && <Alert>{items.error}</Alert>}
      {items.data?.items.map((c) => (
        <div className="card" key={c.id}>
          <div className="row"><b className="grow">{c.type.replace(/_/g, ' ').toLowerCase()}</b><Badge v={c.status} /></div>
          {edit?.id === c.id ? (<>
            <textarea value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} style={{ minHeight: 180 }} aria-label="Content body" />
            <label>Hashtags<input value={edit.hashtags} onChange={(e) => setEdit({ ...edit, hashtags: e.target.value })} /></label>
            <div className="row" style={{ marginTop: '.5rem' }}><button onClick={save} disabled={a.busy}>Save</button><button className="secondary" onClick={() => setEdit(null)}>Cancel</button></div>
          </>) : (<>
            <pre className="out">{c.currentVersion?.body}{c.currentVersion?.hashtags?.length ? '\n\n' + c.currentVersion.hashtags.map((h: string) => '#' + h).join(' ') : ''}</pre>
            {c.currentVersion?.qualityNotes && !c.currentVersion.qualityNotes.passed && <Alert kind="warn">Quality check: {c.currentVersion.qualityNotes.issues.join(' ')}</Alert>}
            <div className="row">
              <button className="secondary" onClick={() => setEdit({ id: c.id, body: c.currentVersion.body, hashtags: c.currentVersion.hashtags.join(' ') })}>Edit</button>
              <button className="secondary" onClick={() => navigator.clipboard.writeText(c.currentVersion.body)}>Copy</button>
              <button className="secondary" onClick={() => download(c)}>Download</button>
              <button className="secondary" disabled={a.busy} onClick={() => a.run(async () => { await api('/content/generate', { body: { businessId: business.id, type: c.type, topic: f.topic || c.currentVersion.body.slice(0, 200), tone: c.tone ?? 'professional', language: c.language, length: 'medium', count: 1 } }); await items.reload(); }, 'New draft generated.')}>Regenerate</button>
              {c.status === 'QUALITY_CHECKED' && <button className="green" onClick={() => a.run(async () => { await api(`/approvals/${c.id}/submit`, { method: 'POST' }); await items.reload(); }, 'Sent to the approval center.')}>Send for review</button>}
              <button className="danger" onClick={() => a.run(async () => { await api(`/content/${c.id}`, { method: 'DELETE' }); await items.reload(); })}>Delete</button>
            </div></>)}
        </div>
      ))}
    </>
  );
}

export function Approvals() {
  const { business } = useApp();
  const a = useAction();
  const q = useLoad(async () => business ? { list: await api<{ items: any[] }>(`/approvals?businessId=${business.id}`), accts: await api<{ items: any[] }>(`/social/accounts?businessId=${business.id}`) } : null, [business?.id]);
  const [acct, setAcct] = useState<Record<string, string>>({}); const [when, setWhen] = useState<Record<string, string>>({});
  if (!business) return <NoBiz />;
  const reload = () => q.reload();
  return (
    <>
      <h1>Approval center</h1>
      <p className="hero">Flow: draft → quality check → your review → your approval → schedule → publish. Editing content cancels its approval and any scheduled post.</p>
      <Msgs a={a} />{q.error && <Alert>{q.error}</Alert>}
      {q.data?.list.items.length === 0 && <p className="muted">Nothing waiting. Generate content in the Content studio and send it for review.</p>}
      {q.data?.list.items.map((c) => {
        const platformAccts = q.data!.accts.items.filter((x) => !c.platform || x.platform === c.platform);
        const approval = c.approvals?.[0]; const job = c.publishingJobs?.[0];
        return (
          <div className="card" key={c.id}>
            <div className="row"><b className="grow">{c.type.replace(/_/g, ' ').toLowerCase()}</b><Badge v={c.status} /></div>
            <pre className="out">{c.currentVersion?.body}{c.currentVersion?.hashtags?.length ? '\n\n' + c.currentVersion.hashtags.map((h: string) => '#' + h).join(' ') : ''}</pre>
            {c.status === 'QUALITY_CHECKED' && <button onClick={() => a.run(async () => { await api(`/approvals/${c.id}/submit`, { method: 'POST' }); await reload(); })}>Send for review</button>}
            {c.status === 'IN_REVIEW' && (
              <div className="row">
                <select aria-label="Destination account" className="grow" value={acct[c.id] ?? ''} onChange={(e) => setAcct({ ...acct, [c.id]: e.target.value })}>
                  <option value="">Choose destination account…</option>{platformAccts.map((x) => <option key={x.id} value={x.id}>{x.platform} · {x.displayName}{x.isDemo ? ' (demo)' : ''}</option>)}</select>
                <button className="green" disabled={!acct[c.id] || a.busy} onClick={() => a.run(async () => { await api(`/approvals/${c.id}/approve`, { body: { versionId: c.currentVersionId, socialAccountId: acct[c.id] } }); await reload(); }, 'Approved.')}>I have reviewed this: approve</button>
                {platformAccts.length === 0 && <span className="muted">No matching account. Connect one in Social accounts.</span>}
              </div>)}
            {c.status === 'APPROVED' && approval && (
              <div className="row">
                <input type="datetime-local" aria-label="Publish at" className="grow" value={when[c.id] ?? ''} onChange={(e) => setWhen({ ...when, [c.id]: e.target.value })} />
                <button disabled={!when[c.id] || a.busy} onClick={() => a.run(async () => { await api(`/approvals/${c.id}/schedule`, { body: { approvalId: approval.id, scheduledFor: new Date(when[c.id]).toISOString() } }); await reload(); }, 'Scheduled.')}>Schedule</button>
                <button className="secondary" onClick={() => a.run(async () => { await api(`/approvals/${c.id}/revoke`, { body: {} }); await reload(); })}>Revoke approval</button>
              </div>)}
            {c.status === 'SCHEDULED' && job && (
              <div className="row"><span className="grow muted">Scheduled for {new Date(job.scheduledFor).toLocaleString()}</span>
                <button className="secondary" onClick={() => a.run(async () => { await api(`/approvals/jobs/${job.id}/cancel`, { method: 'POST' }); await reload(); }, 'Cancelled.')}>Cancel publishing</button></div>)}
          </div>
        );
      })}
    </>
  );
}
