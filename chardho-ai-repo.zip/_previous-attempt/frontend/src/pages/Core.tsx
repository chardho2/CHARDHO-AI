import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { Business, useApp } from '../ctx';
import { Alert, Badge, Msgs, useAction, useLoad } from '../ui';

const empty = { name: '', website: '', industry: '', description: '', productsServices: '', location: '', targetAudience: '', marketingObjectives: '', competitors: '', languages: 'en' };

export function BusinessForm({ existing, onDone }: { existing?: Business; onDone: (b: Business) => void }) {
  const a = useAction();
  const [f, setF] = useState(existing ? { ...empty, ...existing, website: existing.website ?? '', competitors: existing.competitors.join(', '), languages: existing.languages.join(', ') } as typeof empty : empty);
  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const body = { ...f, competitors: f.competitors.split(',').map((s) => s.trim()).filter(Boolean), languages: f.languages.split(',').map((s) => s.trim()).filter(Boolean) };
    const r = await a.run(() => existing ? api<{ business: Business }>(`/businesses/${existing.id}`, { method: 'PATCH', body }) : api<{ business: Business }>('/businesses', { body }), 'Saved.');
    if (r) onDone(r.business);
  };
  return (
    <form onSubmit={submit}>
      <div className="grid">
        <label>Business name *<input required value={f.name} onChange={set('name')} /></label>
        <label>Website<input type="url" placeholder="https://" value={f.website} onChange={set('website')} /></label>
        <label>Industry<input value={f.industry} onChange={set('industry')} /></label>
        <label>Location<input value={f.location} onChange={set('location')} /></label>
      </div>
      <label>Business description<textarea value={f.description} onChange={set('description')} /></label>
      <label>Products and services<textarea value={f.productsServices} onChange={set('productsServices')} /></label>
      <label>Target audience<textarea value={f.targetAudience} onChange={set('targetAudience')} /></label>
      <label>Marketing objectives<textarea value={f.marketingObjectives} onChange={set('marketingObjectives')} /></label>
      <div className="grid">
        <label>Competitors (comma separated)<input value={f.competitors} onChange={set('competitors')} /></label>
        <label>Preferred languages (codes, comma separated)<input value={f.languages} onChange={set('languages')} /></label>
      </div>
      <Msgs a={a} /><button disabled={a.busy}>{existing ? 'Save changes' : 'Create business'}</button>
    </form>
  );
}

export function Businesses() {
  const { businesses, business, setBusinessId, refreshBusinesses } = useApp();
  const nav = useNavigate();
  const [adding, setAdding] = useState(businesses.length === 0);
  const [editing, setEditing] = useState(false);
  const a = useAction();
  return (
    <>
      <h1>Business profiles</h1>
      <p className="hero">Tell the agents about your business. The more accurate the profile, the better and safer their output (they never invent facts you did not give them).</p>
      {businesses.length > 0 && (
        <div className="card"><div className="row">
          {businesses.map((b) => <button key={b.id} className={b.id === business?.id ? '' : 'secondary'} onClick={() => setBusinessId(b.id)}>{b.name}</button>)}
          <button className="green" onClick={() => { setAdding(true); setEditing(false); }}>+ Add business</button>
        </div></div>
      )}
      {adding && <div className="card"><h2>New business</h2><BusinessForm onDone={async (b) => { await refreshBusinesses(); setBusinessId(b.id); setAdding(false); nav('/dashboard'); }} /></div>}
      {business && !adding && (
        <div className="card">
          <div className="row"><h2 className="grow">{business.name}</h2>
            <button className="secondary" onClick={() => setEditing(!editing)}>{editing ? 'Close' : 'Edit'}</button>
            <button className="danger" disabled={a.busy} onClick={() => { if (confirm(`Delete "${business.name}"? Its data will be hidden.`)) void a.run(async () => { await api(`/businesses/${business.id}`, { method: 'DELETE' }); await refreshBusinesses(); }); }}>Delete</button>
          </div>
          <Msgs a={a} />
          {editing && <BusinessForm key={business.id} existing={business} onDone={async () => { await refreshBusinesses(); setEditing(false); }} />}
        </div>
      )}
    </>
  );
}

export function Dashboard() {
  const { business, user } = useApp();
  const stats = useLoad(() => business ? api<any>(`/analytics?businessId=${business.id}`) : Promise.resolve(null), [business?.id]);
  const ann = useLoad(() => api<{ items: { id: string; title: string; body: string }[] }>('/support/announcements'), []);
  const report = useAction();
  const { refreshBusinesses } = useApp();
  if (!business) return <><h1>Welcome{user?.name ? `, ${user.name}` : ''}</h1><p className="hero">Start by creating your first business profile.</p><Link className="btn" to="/business">Create business profile</Link></>;
  const count = (rows: { status: string; _count: number }[] | undefined, s: string) => rows?.find((r) => r.status === s)?._count ?? 0;
  const i = stats.data?.internal;
  return (
    <>
      <h1>{business.name}</h1>
      <p className="hero">Your AI digital workforce is ready. Nothing is ever published without your approval.</p>
      {ann.data?.items.map((x) => <Alert key={x.id} kind="ok"><b>{x.title}</b> {x.body}</Alert>)}
      {stats.error && <Alert>{stats.error}</Alert>}
      <div className="grid">
        <div className="card"><h2>Content</h2><p style={{ fontSize: '2rem', margin: 0 }}>{i?.content ?? '–'}</p><p className="muted">{count(i?.byStatus, 'IN_REVIEW')} waiting for review · {count(i?.byStatus, 'PUBLISHED')} published</p><Link to="/approvals">Open approval center</Link></div>
        <div className="card"><h2>Leads</h2><p style={{ fontSize: '2rem', margin: 0 }}>{i?.leads?.reduce((n: number, r: any) => n + r._count, 0) ?? '–'}</p><Link to="/leads">Open CRM</Link></div>
        <div className="card"><h2>Agent tasks</h2><p style={{ fontSize: '2rem', margin: 0 }}>{i?.agentTasks?.reduce((n: number, r: any) => n + r._count, 0) ?? '–'}</p><Link to="/agents">Ask an agent</Link></div>
      </div>
      <div className="card">
        <div className="row"><h2 className="grow">Business intelligence report</h2>
          <button disabled={report.busy} onClick={() => report.run(async () => { await api('/marketing/report', { body: { businessId: business.id } }); await refreshBusinesses(); }, 'Report generated.')}>{business.intelligenceReport ? 'Regenerate' : 'Generate report'}</button></div>
        <Msgs a={report} />
        {report.busy && <p className="muted">The Marketing Manager is working. This can take a minute.</p>}
        {business.intelligenceReport ? <pre className="out">{business.intelligenceReport.text}</pre> : <p className="muted">No report yet. Generate one from your business profile.</p>}
      </div>
      <p className="muted">{stats.data?.platformAnalytics?.note}</p>
    </>
  );
}

export function Settings() {
  const { user, theme, setTheme, logout } = useApp();
  const a = useAction(); const [confirm, setConfirm] = useState('');
  const exportData = () => a.run(async () => {
    const d = await api('/users/me/export');
    const url = URL.createObjectURL(new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' }));
    Object.assign(document.createElement('a'), { href: url, download: 'chardho-ai-export.json' }).click(); URL.revokeObjectURL(url);
  }, 'Export downloaded.');
  return (
    <>
      <h1>Settings</h1>
      <div className="card"><h2>Profile</h2><p>{user?.email} <Badge v={user?.role === 'USER' ? 'live' : 'demo'} /> <span className="muted">{user?.role}</span></p>
        <label>Theme<select value={theme} onChange={(e) => setTheme(e.target.value)}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></label></div>
      <div className="card"><h2>Your data</h2><p className="muted">Download everything you own as JSON. Credentials are never included.</p><button className="secondary" disabled={a.busy} onClick={exportData}>Export my data</button><Msgs a={a} /></div>
      <div className="card"><h2>Delete account</h2><p className="muted">Permanently deletes your account and all business data. This cannot be undone.</p>
        <label>Type your email to confirm<input value={confirm} onChange={(e) => setConfirm(e.target.value)} /></label>
        <button className="danger" disabled={a.busy || confirm.toLowerCase() !== user?.email.toLowerCase()} onClick={() => a.run(async () => { await api('/users/me', { method: 'DELETE', body: { confirmEmail: confirm } }); await logout(); })}>Delete my account</button></div>
    </>
  );
}
