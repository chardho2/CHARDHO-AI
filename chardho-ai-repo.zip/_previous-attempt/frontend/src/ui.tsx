import { ReactNode, useCallback, useEffect, useState } from 'react';
import { errMsg } from './api';

export const Alert = ({ kind = 'error', children }: { kind?: 'error' | 'ok' | 'warn'; children: ReactNode }) => (
  <div className={`alert ${kind}`} role={kind === 'error' ? 'alert' : 'status'}>{children}</div>
);

export const Badge = ({ v }: { v: string }) => <span className={`badge ${v}`}>{v.replace(/_/g, ' ').toLowerCase()}</span>;

/** Loads data and exposes loading/error/reload so every screen handles failures visibly. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const load = useCallback(async () => { setLoading(true); setError(''); try { setData(await fn()); } catch (e) { setError(errMsg(e)); } finally { setLoading(false); } }, deps);
  useEffect(() => { void load(); }, [load]);
  return { data, error, loading, reload: load };
}

/** Wraps an async action with busy/error/success state. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const run = async <T,>(fn: () => Promise<T>, success = ''): Promise<T | undefined> => {
    setBusy(true); setError(''); setOk('');
    try { const r = await fn(); setOk(success); return r; } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  return { busy, error, ok, run, setError, setOk };
}

export const Msgs = ({ a }: { a: { error: string; ok: string } }) => (<>{a.error && <Alert>{a.error}</Alert>}{a.ok && <Alert kind="ok">{a.ok}</Alert>}</>);

export const Field = ({ label, children }: { label: string; children: ReactNode }) => (<label>{label}{children}</label>);
