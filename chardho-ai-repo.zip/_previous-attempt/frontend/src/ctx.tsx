import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import { api } from './api';

export interface User { id: string; email: string; name?: string | null; role: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'USER'; preferredTheme?: string }
export interface Business { id: string; name: string; website?: string; industry?: string; description?: string; productsServices?: string; location?: string; targetAudience?: string; marketingObjectives?: string; competitors: string[]; languages: string[]; intelligenceReport?: { text: string } | null }

interface Ctx {
  user: User | null; loading: boolean; refreshUser: () => Promise<void>; logout: () => Promise<void>;
  businesses: Business[]; business: Business | null; setBusinessId: (id: string) => void; refreshBusinesses: () => Promise<void>;
  theme: string; setTheme: (t: string) => void;
}
const C = createContext<Ctx>(null as never);
export const useApp = () => useContext(C);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [businessId, setBusinessIdState] = useState<string>(() => localStorage.getItem('businessId') ?? '');
  const [theme, setThemeState] = useState<string>(() => localStorage.getItem('theme') ?? 'system');

  useEffect(() => {
    const dark = theme === 'dark' || (theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  }, [theme]);
  const setTheme = (t: string) => { localStorage.setItem('theme', t); setThemeState(t); if (user) api('/users/me', { method: 'PATCH', body: { preferredTheme: t } }).catch(() => {}); };

  const refreshBusinesses = useCallback(async () => {
    const r = await api<{ items: Business[] }>('/businesses');
    setBusinesses(r.items);
  }, []);
  const refreshUser = useCallback(async () => {
    try { const r = await api<{ user: User }>('/auth/me'); setUser(r.user); await refreshBusinesses(); }
    catch { setUser(null); setBusinesses([]); }
    finally { setLoading(false); }
  }, [refreshBusinesses]);
  useEffect(() => { void refreshUser(); }, [refreshUser]);

  const logout = async () => { await api('/auth/logout', { method: 'POST' }); setUser(null); setBusinesses([]); };
  const setBusinessId = (id: string) => { localStorage.setItem('businessId', id); setBusinessIdState(id); };
  const business = businesses.find((b) => b.id === businessId) ?? businesses[0] ?? null;

  return <C.Provider value={{ user, loading, refreshUser, logout, businesses, business, setBusinessId, refreshBusinesses, theme, setTheme }}>{children}</C.Provider>;
}
