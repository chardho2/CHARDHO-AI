import nodemailer from 'nodemailer';
import { config } from '../config';
import { logger } from './logger';

const transport = config.SMTP_HOST
  ? nodemailer.createTransport({
      host: config.SMTP_HOST,
      port: config.SMTP_PORT,
      secure: config.SMTP_PORT === 465,
      auth: config.SMTP_USER ? { user: config.SMTP_USER, pass: config.SMTP_PASS } : undefined,
    })
  : null;

/**
 * Sends system emails (verification, reset). When SMTP is not configured the
 * message is logged so local development works; integration status reports this as "demo".
 */
export async function sendSystemEmail(to: string, subject: string, text: string): Promise<void> {
  if (!transport) {
    logger.warn({ to, subject, text }, '[mailer:demo] SMTP not configured; email logged instead of sent');
    return;
  }
  await transport.sendMail({ from: config.SMTP_FROM, to, subject, text });
}

export const mailerIsDemo = !transport;
