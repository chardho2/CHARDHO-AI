import { prisma } from './db';
import { notFound } from './errors';

/**
 * Tenant isolation: every business-scoped resource must be reached through one of these helpers.
 * Returning 404 (not 403) for foreign records avoids leaking that an id exists.
 * Admin roles deliberately get NO bypass here; admin tooling uses its own limited routes.
 */
export async function assertBusinessAccess(userId: string, businessId: string) {
  const b = await prisma.business.findFirst({ where: { id: businessId, ownerId: userId, deletedAt: null } });
  if (!b) throw notFound('Business not found');
  return b;
}

export async function assertContentAccess(userId: string, contentId: string) {
  const c = await prisma.contentItem.findFirst({
    where: { id: contentId, deletedAt: null, business: { ownerId: userId, deletedAt: null } },
  });
  if (!c) throw notFound('Content not found');
  return c;
}
