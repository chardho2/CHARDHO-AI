import crypto from 'crypto';
import { Prisma, SocialAccount, ContentVersion } from '@prisma/client';
import { prisma } from '../lib/db';
import { decrypt } from '../lib/crypto';
import { logger } from '../lib/logger';
import { hashContent } from './content';

/** Result of calling a platform. `retryable` is true ONLY when we are certain no post was created. */
class PublishError extends Error {
  constructor(message: string, public retryable: boolean, public response?: unknown) {
    super(message);
  }
}

const caption = (v: ContentVersion) =>
  [v.body, v.hashtags.length ? v.hashtags.map((h) => `#${h}`).join(' ') : ''].filter(Boolean).join('\n\n');

async function call(url: string, init: RequestInit): Promise<{ status: number; body: any }> {
  let res: Response;
  try {
    res = await fetch(url, { ...init, signal: AbortSignal.timeout(20_000) });
  } catch (e) {
    const name = (e as Error).name;
    // A timeout may happen AFTER the platform created the post, so it is not safe to retry automatically.
    throw new PublishError(`Network error: ${(e as Error).message}`, name !== 'TimeoutError' && name !== 'AbortError');
  }
  const text = await res.text();
  let body: any = text;
  try {
    body = JSON.parse(text);
  } catch {
    /* keep raw text */
  }
  return { status: res.status, body };
}

function check(r: { status: number; body: any }, what: string) {
  if (r.status >= 200 && r.status < 300) return;
  // Only 429 is a guaranteed "not created"; 5xx may have partially succeeded, so require manual retry.
  throw new PublishError(`${what} failed (HTTP ${r.status})`, r.status === 429, r.body);
}

type Publisher = (acct: SocialAccount, token: string, v: ContentVersion) => Promise<{ externalId: string; response: unknown }>;

const publishers: Partial<Record<SocialAccount['platform'], Publisher>> = {
  async X(_a, token, v) {
    const r = await call('https://api.x.com/2/tweets', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: caption(v) }),
    });
    check(r, 'X post');
    return { externalId: String(r.body?.data?.id ?? ''), response: r.body };
  },

  async LINKEDIN(a, token, v) {
    const r = await call('https://api.linkedin.com/v2/ugcPosts', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'X-Restli-Protocol-Version': '2.0.0' },
      body: JSON.stringify({
        author: `urn:li:person:${a.externalId}`,
        lifecycleState: 'PUBLISHED',
        specificContent: {
          'com.linkedin.ugc.ShareContent': { shareCommentary: { text: caption(v) }, shareMediaCategory: 'NONE' },
        },
        visibility: { 'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC' },
      }),
    });
    check(r, 'LinkedIn post');
    return { externalId: String(r.body?.id ?? ''), response: r.body };
  },

  async FACEBOOK(a, token, v) {
    const r = await call(`https://graph.facebook.com/v19.0/${encodeURIComponent(a.externalId)}/feed`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ message: caption(v), access_token: token }),
    });
    check(r, 'Facebook post');
    return { externalId: String(r.body?.id ?? ''), response: r.body };
  },

  async INSTAGRAM(a, token, v) {
    // Instagram feed posts require an image; publishing is a two-step container flow.
    const media = v.mediaIds[0] ? await prisma.mediaAsset.findUnique({ where: { id: v.mediaIds[0] } }) : null;
    if (!media || media.kind !== 'IMAGE' || !/^https:\/\//.test(media.url)) {
      throw new PublishError('Instagram posts need an attached image with a public https URL.', false);
    }
    const c = await call(`https://graph.facebook.com/v19.0/${encodeURIComponent(a.externalId)}/media`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ image_url: media.url, caption: caption(v), access_token: token }),
    });
    check(c, 'Instagram media container');
    const p = await call(`https://graph.facebook.com/v19.0/${encodeURIComponent(a.externalId)}/media_publish`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ creation_id: String(c.body?.id), access_token: token }),
    });
    check(p, 'Instagram publish');
    return { externalId: String(p.body?.id ?? ''), response: { container: c.body, publish: p.body } };
  },

  // YOUTUBE intentionally absent: the Data API publishes videos, not text posts.
};

async function publishToPlatform(acct: SocialAccount, v: ContentVersion) {
  if (acct.isDemo) {
    // Clearly labelled simulation so the full workflow is testable without credentials.
    return { externalId: `demo-${crypto.randomUUID()}`, response: { demo: true, note: 'Simulated publish: no real post was created.' } };
  }
  const fn = publishers[acct.platform];
  if (!fn) throw new PublishError(`Publishing to ${acct.platform} is not supported for text posts yet.`, false);
  if (acct.tokenExpiresAt && acct.tokenExpiresAt < new Date()) {
    throw new PublishError('The account connection has expired. Please reconnect the account.', false);
  }
  return fn(acct, decrypt(acct.accessTokenEnc), v);
}

const MAX_ATTEMPTS = 3;

export async function publishJob(jobId: string): Promise<void> {
  // Atomic claim: only one worker can move PENDING → IN_PROGRESS, which prevents double publishing.
  const claim = await prisma.publishingJob.updateMany({
    where: { id: jobId, status: 'PENDING', scheduledFor: { lte: new Date() } },
    data: { status: 'IN_PROGRESS', attempts: { increment: 1 } },
  });
  if (claim.count === 0) return;

  const job = await prisma.publishingJob.findUniqueOrThrow({
    where: { id: jobId },
    include: { approval: { include: { version: true } }, content: true, socialAccount: true },
  });

  const fail = async (msg: string, response?: unknown, retry = false) => {
    const again = retry && job.attempts < MAX_ATTEMPTS;
    await prisma.$transaction([
      prisma.publishingJob.update({
        where: { id: job.id },
        data: {
          status: again ? 'PENDING' : 'FAILED',
          scheduledFor: again ? new Date(Date.now() + 2 ** job.attempts * 60_000) : undefined,
          error: msg.slice(0, 1000),
          apiResponse: (response ?? Prisma.JsonNull) as Prisma.InputJsonValue,
        },
      }),
      prisma.contentItem.update({ where: { id: job.contentId }, data: { status: again ? 'SCHEDULED' : 'FAILED' } }),
    ]);
    await prisma.notification.create({
      data: {
        userId: (await prisma.approval.findUniqueOrThrow({ where: { id: job.approvalId } })).approvedById,
        title: again ? 'Publishing will be retried' : 'Publishing failed',
        body: msg.slice(0, 300),
      },
    });
  };

  // Defence in depth: re-verify the approval at the moment of publishing.
  const { approval, content } = job;
  const valid =
    approval.status === 'APPROVED' &&
    content.currentVersionId === approval.versionId &&
    hashContent(approval.version) === approval.contentHash &&
    !job.socialAccount.disconnectedAt;
  if (!valid) return fail('Blocked: approval is no longer valid for the current content or account.');

  await prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'PUBLISHING' } });
  try {
    const r = await publishToPlatform(job.socialAccount, approval.version);
    await prisma.$transaction([
      prisma.publishingJob.update({
        where: { id: job.id },
        data: { status: 'SUCCEEDED', externalPostId: r.externalId, apiResponse: r.response as Prisma.InputJsonValue, publishedAt: new Date(), error: null },
      }),
      prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'PUBLISHED' } }),
    ]);
  } catch (e) {
    const pe = e instanceof PublishError ? e : new PublishError((e as Error).message, false);
    logger.warn({ jobId, err: pe.message }, 'publish failed');
    await fail(pe.message, pe.response, pe.retryable);
  }
}

export async function processDueJobs(limit = 20) {
  const due = await prisma.publishingJob.findMany({
    where: { status: 'PENDING', scheduledFor: { lte: new Date() } },
    orderBy: { scheduledFor: 'asc' },
    take: limit,
    select: { id: true },
  });
  for (const j of due) await publishJob(j.id);
  return due.length;
}
