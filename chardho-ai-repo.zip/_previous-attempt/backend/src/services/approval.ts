import crypto from 'crypto';
import { Prisma } from '@prisma/client';
import { prisma } from '../lib/db';
import { conflict, badRequest, notFound } from '../lib/errors';
import { hashContent } from './content';

/**
 * THE approval engine. Nothing in the codebase publishes without passing through these functions.
 * Agents have no tool that reaches them; every entry point is a route behind requireAuth that acts
 * as the logged-in human (approvedById = req.user.id).
 */

export async function submitForReview(contentId: string) {
  const item = await prisma.contentItem.findUnique({ where: { id: contentId }, include: { currentVersion: true } });
  if (!item?.currentVersion) throw notFound('Content not found');
  if (item.status !== 'QUALITY_CHECKED') {
    throw conflict('Content must pass the quality check before review. Fix the listed issues and try again.', 'QUALITY_NOT_PASSED');
  }
  return prisma.contentItem.update({ where: { id: contentId }, data: { status: 'IN_REVIEW' } });
}

export async function approveContent(args: {
  contentId: string;
  versionId: string;
  socialAccountId: string;
  userId: string;
}) {
  return prisma.$transaction(async (tx) => {
    const item = await tx.contentItem.findFirst({
      where: { id: args.contentId, deletedAt: null },
      include: { currentVersion: true },
    });
    if (!item?.currentVersion) throw notFound('Content not found');
    if (item.status !== 'IN_REVIEW') throw conflict('Only content that is in review can be approved.', 'NOT_IN_REVIEW');
    // The human must approve exactly the version they were looking at.
    if (item.currentVersionId !== args.versionId) {
      throw conflict('This content changed since you opened it. Review the latest version and approve again.', 'STALE_VERSION');
    }
    const v = item.currentVersion;
    if (hashContent(v) !== v.contentHash) throw conflict('Content integrity check failed.', 'HASH_MISMATCH');

    const account = await tx.socialAccount.findFirst({
      where: { id: args.socialAccountId, businessId: item.businessId, disconnectedAt: null },
    });
    if (!account) throw badRequest('Choose a connected account that belongs to this business.');
    if (item.platform && account.platform !== item.platform) {
      throw badRequest(`This content is for ${item.platform}; choose a ${item.platform} account.`);
    }

    // Retire any earlier approval for this content before creating the new one.
    await tx.approval.updateMany({
      where: { contentId: item.id, status: { in: ['PENDING', 'APPROVED'] } },
      data: { status: 'INVALIDATED', invalidatedAt: new Date(), invalidReason: 'Superseded by a newer approval' },
    });
    const approval = await tx.approval.create({
      data: {
        contentId: item.id,
        versionId: v.id,
        contentHash: v.contentHash,
        socialAccountId: account.id,
        approvedById: args.userId,
        status: 'APPROVED',
        approvedAt: new Date(),
      },
    });
    await tx.contentItem.update({ where: { id: item.id }, data: { status: 'APPROVED' } });
    return approval;
  });
}

export async function rejectContent(contentId: string, userId: string, reason?: string) {
  return prisma.$transaction(async (tx) => {
    const item = await tx.contentItem.findUnique({ where: { id: contentId } });
    if (!item) throw notFound('Content not found');
    await tx.approval.updateMany({
      where: { contentId, status: { in: ['PENDING', 'APPROVED'] } },
      data: { status: 'REVOKED', invalidatedAt: new Date(), invalidReason: reason ?? `Revoked by ${userId}` },
    });
    await tx.publishingJob.updateMany({
      where: { contentId, status: 'PENDING' },
      data: { status: 'CANCELLED', cancelledAt: new Date(), error: 'Cancelled: approval revoked' },
    });
    return tx.contentItem.update({ where: { id: contentId }, data: { status: 'QUALITY_CHECKED' } });
  });
}

/** Schedule an APPROVED version. The idempotency key makes double-scheduling/publishing impossible. */
export async function schedulePublish(args: { approvalId: string; scheduledFor: Date }) {
  const approval = await prisma.approval.findUnique({
    where: { id: args.approvalId },
    include: { version: true, content: true },
  });
  if (!approval) throw notFound('Approval not found');
  if (approval.status !== 'APPROVED') throw conflict('This approval is no longer valid. Review and approve the content again.', 'APPROVAL_INVALID');
  if (approval.content.currentVersionId !== approval.versionId || hashContent(approval.version) !== approval.contentHash) {
    throw conflict('Content changed after approval; fresh approval required.', 'APPROVAL_STALE');
  }
  if (args.scheduledFor.getTime() < Date.now() - 60_000) throw badRequest('Scheduled time is in the past.');

  const key = crypto
    .createHash('sha256')
    .update(`${approval.id}:${approval.versionId}:${approval.socialAccountId}`)
    .digest('hex');

  const existing = await prisma.publishingJob.findUnique({ where: { idempotencyKey: key } });
  if (existing && !['CANCELLED', 'FAILED'].includes(existing.status)) {
    throw conflict(`Already ${existing.status.toLowerCase()}. Duplicate publishing is prevented.`, 'DUPLICATE_PUBLISH');
  }

  try {
    const job = await prisma.$transaction(async (tx) => {
      const j = existing
        ? await tx.publishingJob.update({
            where: { id: existing.id },
            data: { status: 'PENDING', scheduledFor: args.scheduledFor, error: null, cancelledAt: null, attempts: 0 },
          })
        : await tx.publishingJob.create({
            data: {
              contentId: approval.contentId,
              approvalId: approval.id,
              socialAccountId: approval.socialAccountId,
              scheduledFor: args.scheduledFor,
              idempotencyKey: key,
            },
          });
      await tx.contentItem.update({ where: { id: approval.contentId }, data: { status: 'SCHEDULED' } });
      return j;
    });
    return job;
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      throw conflict('Duplicate publishing is prevented.', 'DUPLICATE_PUBLISH');
    }
    throw e;
  }
}

export async function cancelPublish(jobId: string) {
  const claimed = await prisma.publishingJob.updateMany({
    where: { id: jobId, status: 'PENDING' }, // atomic: cannot cancel something already in flight or done
    data: { status: 'CANCELLED', cancelledAt: new Date() },
  });
  if (claimed.count === 0) throw conflict('Only scheduled posts that have not started publishing can be cancelled.', 'NOT_CANCELLABLE');
  const job = await prisma.publishingJob.findUniqueOrThrow({ where: { id: jobId } });
  await prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'APPROVED' } });
  return job;
}
