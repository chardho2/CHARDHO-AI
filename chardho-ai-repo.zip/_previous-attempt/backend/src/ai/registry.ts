import { Prisma } from '@prisma/client';
import { config } from '../config';
import { prisma } from '../lib/db';
import { decrypt } from '../lib/crypto';
import { logger } from '../lib/logger';
import { HttpError, tooMany } from '../lib/errors';
import { GeminiProvider } from './providers/gemini';
import { OllamaProvider } from './providers/ollama';
import { OpenAICompatibleProvider } from './providers/openai';
import { GenerateRequest, GenerateResult, ProviderAdapter, ProviderError } from './providers/types';

interface Candidate {
  adapter: ProviderAdapter;
  priority: number;
  isPaid: boolean;
  inputCostPer1k: number;
  outputCostPer1k: number;
  capabilities: string[];
  dailyRequestLimit?: number | null;
}

const period = () => new Date().toISOString().slice(0, 7); // YYYY-MM

/**
 * Builds the ordered list of usable providers: environment defaults merged with owner-managed
 * ProviderConfig rows. Local/free providers sort first; paid ones are only included when the owner
 * has explicitly authorised paid usage AND the monthly budget is not exhausted.
 */
async function buildCandidates(capability = 'text'): Promise<Candidate[]> {
  const rows = await prisma.providerConfig.findMany();
  const byName = new Map(rows.map((r) => [r.name, r]));
  const out: Candidate[] = [];

  const push = (
    name: string,
    defaults: { priority: number; isPaid: boolean; inCost: number; outCost: number },
    make: (row: (typeof rows)[number] | undefined) => ProviderAdapter | null,
  ) => {
    const row = byName.get(name);
    if (row && !row.enabled) return;
    const adapter = make(row);
    if (!adapter) return;
    const isPaid = row?.isPaid ?? defaults.isPaid;
    if (isPaid) {
      const approved = config.ALLOW_PAID_PROVIDERS && (row ? row.paidApproved : true);
      if (!approved) return;
    }
    const capabilities = row?.capabilities ?? ['text'];
    if (!capabilities.includes(capability)) return;
    out.push({
      adapter,
      priority: row?.priority ?? defaults.priority,
      isPaid,
      inputCostPer1k: row ? Number(row.inputCostPer1k) : defaults.inCost,
      outputCostPer1k: row ? Number(row.outputCostPer1k) : defaults.outCost,
      capabilities,
      dailyRequestLimit: row?.dailyRequestLimit,
    });
  };

  push('ollama', { priority: 10, isPaid: false, inCost: 0, outCost: 0 }, (row) =>
    new OllamaProvider(row?.baseUrl ?? config.OLLAMA_BASE_URL, row?.model ?? config.OLLAMA_MODEL),
  );
  push('gemini', { priority: 20, isPaid: false, inCost: 0, outCost: 0 }, (row) => {
    const key = row?.apiKeyEnc ? decrypt(row.apiKeyEnc) : config.GEMINI_API_KEY;
    return key ? new GeminiProvider(key, row?.model ?? config.GEMINI_MODEL) : null;
  });
  // Placeholder rates: owner should confirm against the provider's current price list and edit in the admin portal.
  push('openai', { priority: 90, isPaid: true, inCost: 0.00015, outCost: 0.0006 }, (row) => {
    const key = row?.apiKeyEnc ? decrypt(row.apiKeyEnc) : config.OPENAI_API_KEY;
    return key ? new OpenAICompatibleProvider('openai', key, row?.model ?? config.OPENAI_MODEL, row?.baseUrl ?? undefined) : null;
  });

  // Any additional OpenAI-compatible providers the owner has added (Groq, OpenRouter, vLLM, ...)
  for (const row of rows) {
    if (['ollama', 'gemini', 'openai'].includes(row.name) || !row.enabled || !row.baseUrl || !row.apiKeyEnc) continue;
    push(row.name, { priority: row.priority, isPaid: row.isPaid, inCost: 0, outCost: 0 }, () =>
      new OpenAICompatibleProvider(row.name, decrypt(row.apiKeyEnc!), row.model, row.baseUrl!),
    );
  }

  let candidates = out.sort((a, b) => a.priority - b.priority);

  // Enforce the monthly paid budget.
  if (candidates.some((c) => c.isPaid)) {
    const spent = await prisma.apiProviderCost.findMany({ where: { period: period() } });
    const paidNames = new Set(candidates.filter((c) => c.isPaid).map((c) => c.adapter.name));
    const paidSpend = spent.filter((s) => paidNames.has(s.provider)).reduce((n, s) => n + Number(s.costUsd), 0);
    if (paidSpend >= config.PAID_MONTHLY_BUDGET_USD) candidates = candidates.filter((c) => !c.isPaid);
  }

  // Per-provider daily request caps.
  const dayStart = new Date();
  dayStart.setUTCHours(0, 0, 0, 0);
  const capped: Candidate[] = [];
  for (const c of candidates) {
    if (c.dailyRequestLimit) {
      const used = await prisma.usageRecord.count({ where: { provider: c.adapter.name, createdAt: { gte: dayStart } } });
      if (used >= c.dailyRequestLimit) continue;
    }
    capped.push(c);
  }
  return capped;
}

/** Transparent fair-use numbers for a user (shown in the UI, enforced before every AI call). */
export async function getFairUse(userId: string) {
  const dayStart = new Date();
  dayStart.setUTCHours(0, 0, 0, 0);
  const agg = await prisma.usageRecord.aggregate({
    where: { userId, createdAt: { gte: dayStart } },
    _count: true,
    _sum: { promptTokens: true, outputTokens: true },
  });
  const tokens = (agg._sum.promptTokens ?? 0) + (agg._sum.outputTokens ?? 0);
  return {
    requests: { used: agg._count, limit: config.FAIR_USE_DAILY_AI_REQUESTS },
    tokens: { used: tokens, limit: config.FAIR_USE_DAILY_TOKENS },
    resetsAt: new Date(dayStart.getTime() + 86_400_000).toISOString(),
  };
}

export async function assertFairUse(userId: string) {
  const f = await getFairUse(userId);
  if (f.requests.used >= f.requests.limit || f.tokens.used >= f.tokens.limit) {
    throw tooMany(`Daily fair-use limit reached. Limits reset at ${f.resetsAt}. This keeps the platform free for everyone.`);
  }
}

export interface ProviderResult extends GenerateResult {
  provider: string;
  model: string;
  costUsd: number;
}

/**
 * Tries providers in priority order. Retryable failures (rate limit, outage) fall through to the next
 * provider; non-retryable failures surface immediately. Usage and cost are recorded on success.
 */
export async function generateWithFallback(
  userId: string,
  req: GenerateRequest,
  opts: { taskId?: string; capability?: string; signal?: AbortSignal } = {},
): Promise<ProviderResult> {
  await assertFairUse(userId);
  const candidates = await buildCandidates(opts.capability);
  if (candidates.length === 0) {
    throw new HttpError(
      503,
      'No AI provider is available. The platform owner needs to start Ollama or configure a free provider key.',
      'NO_PROVIDER',
    );
  }

  const failures: string[] = [];
  for (const c of candidates) {
    try {
      const r = await c.adapter.generate(req, opts.signal);
      const costUsd = (r.promptTokens / 1000) * c.inputCostPer1k + (r.outputTokens / 1000) * c.outputCostPer1k;
      await recordUsage(userId, opts.taskId, c.adapter.name, c.adapter.model, r, costUsd);
      return { ...r, provider: c.adapter.name, model: c.adapter.model, costUsd };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      failures.push(msg);
      logger.warn({ provider: c.adapter.name, err: msg }, 'provider failed');
      if (e instanceof ProviderError && !e.retryable) throw e;
    }
  }
  throw new HttpError(503, `All AI providers failed: ${failures.join('; ')}`, 'PROVIDERS_FAILED');
}

async function recordUsage(userId: string, taskId: string | undefined, provider: string, model: string, r: GenerateResult, costUsd: number) {
  const cost = new Prisma.Decimal(costUsd.toFixed(6));
  await prisma.$transaction([
    prisma.usageRecord.create({
      data: { userId, taskId, provider, model, promptTokens: r.promptTokens, outputTokens: r.outputTokens, costUsd: cost },
    }),
    prisma.apiProviderCost.upsert({
      where: { provider_period: { provider, period: period() } },
      create: { provider, period: period(), requests: 1, tokens: BigInt(r.promptTokens + r.outputTokens), costUsd: cost },
      update: {
        requests: { increment: 1 },
        tokens: { increment: BigInt(r.promptTokens + r.outputTokens) },
        costUsd: { increment: cost },
      },
    }),
  ]);
}

/** Status for the admin portal and integration badges. */
export async function providerStatus() {
  const candidates = await buildCandidates();
  return candidates.map((c) => ({
    name: c.adapter.name,
    model: c.adapter.model,
    paid: c.isPaid,
    priority: c.priority,
    dailyRequestLimit: c.dailyRequestLimit ?? null,
  }));
}
