import { estimateTokens, GenerateRequest, GenerateResult, ProviderAdapter, ProviderError } from './types';

/** Works for OpenAI and any OpenAI-compatible endpoint (Groq, Together, OpenRouter, vLLM...). */
export class OpenAICompatibleProvider implements ProviderAdapter {
  constructor(
    readonly name: string,
    private apiKey: string,
    readonly model: string,
    private baseUrl = 'https://api.openai.com/v1',
  ) {}

  async generate(req: GenerateRequest, signal?: AbortSignal): Promise<GenerateResult> {
    let res: Response;
    try {
      res = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.apiKey}` },
        signal,
        body: JSON.stringify({
          model: this.model,
          temperature: req.temperature ?? 0.7,
          max_tokens: req.maxOutputTokens ?? 2048,
          response_format: req.json ? { type: 'json_object' } : undefined,
          messages: [
            { role: 'system', content: req.system },
            { role: 'user', content: req.prompt },
          ],
        }),
      });
    } catch (e) {
      throw new ProviderError(`${this.name} unreachable: ${(e as Error).message}`, this.name, true);
    }
    if (!res.ok) throw new ProviderError(`${this.name} HTTP ${res.status}`, this.name, res.status === 429 || res.status >= 500);
    const data = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };
    const text = data.choices?.[0]?.message?.content ?? '';
    return {
      text,
      promptTokens: data.usage?.prompt_tokens ?? estimateTokens(req.system + req.prompt),
      outputTokens: data.usage?.completion_tokens ?? estimateTokens(text),
    };
  }
}
