import { estimateTokens, GenerateRequest, GenerateResult, ProviderAdapter, ProviderError } from './types';

export class GeminiProvider implements ProviderAdapter {
  readonly name = 'gemini';
  constructor(
    private apiKey: string,
    readonly model: string,
  ) {}

  async generate(req: GenerateRequest, signal?: AbortSignal): Promise<GenerateResult> {
    let res: Response;
    try {
      res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(this.model)}:generateContent`, {
        method: 'POST',
        // Key goes in a header, not the URL, so it never lands in access logs.
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': this.apiKey },
        signal,
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: req.system }] },
          contents: [{ role: 'user', parts: [{ text: req.prompt }] }],
          generationConfig: {
            temperature: req.temperature ?? 0.7,
            maxOutputTokens: req.maxOutputTokens ?? 2048,
            responseMimeType: req.json ? 'application/json' : 'text/plain',
          },
        }),
      });
    } catch (e) {
      throw new ProviderError(`Gemini unreachable: ${(e as Error).message}`, this.name, true);
    }
    if (!res.ok) {
      // 429 = quota exhausted on the free tier: retryable via fallback provider.
      throw new ProviderError(`Gemini HTTP ${res.status}`, this.name, res.status === 429 || res.status >= 500);
    }
    const data = (await res.json()) as {
      candidates?: { content?: { parts?: { text?: string }[] } }[];
      usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number };
    };
    const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
    return {
      text,
      promptTokens: data.usageMetadata?.promptTokenCount ?? estimateTokens(req.system + req.prompt),
      outputTokens: data.usageMetadata?.candidatesTokenCount ?? estimateTokens(text),
    };
  }
}
