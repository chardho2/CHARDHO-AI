import { estimateTokens, GenerateRequest, GenerateResult, ProviderAdapter, ProviderError } from './types';

export class OllamaProvider implements ProviderAdapter {
  readonly name = 'ollama';
  constructor(
    private baseUrl: string,
    readonly model: string,
  ) {}

  async generate(req: GenerateRequest, signal?: AbortSignal): Promise<GenerateResult> {
    let res: Response;
    try {
      res = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal,
        body: JSON.stringify({
          model: this.model,
          stream: false,
          format: req.json ? 'json' : undefined,
          options: { temperature: req.temperature ?? 0.7, num_predict: req.maxOutputTokens ?? 2048 },
          messages: [
            { role: 'system', content: req.system },
            { role: 'user', content: req.prompt },
          ],
        }),
      });
    } catch (e) {
      throw new ProviderError(`Ollama unreachable: ${(e as Error).message}`, this.name, true);
    }
    if (!res.ok) throw new ProviderError(`Ollama HTTP ${res.status}`, this.name, res.status >= 500);
    const data = (await res.json()) as {
      message?: { content?: string };
      prompt_eval_count?: number;
      eval_count?: number;
    };
    const text = data.message?.content ?? '';
    return {
      text,
      promptTokens: data.prompt_eval_count ?? estimateTokens(req.system + req.prompt),
      outputTokens: data.eval_count ?? estimateTokens(text),
    };
  }
}
