export interface GenerateRequest {
  system: string;
  prompt: string;
  /** Ask the model for strict JSON output where the provider supports it. */
  json?: boolean;
  maxOutputTokens?: number;
  temperature?: number;
}

export interface GenerateResult {
  text: string;
  promptTokens: number;
  outputTokens: number;
}

export interface ProviderAdapter {
  readonly name: string;
  readonly model: string;
  generate(req: GenerateRequest, signal?: AbortSignal): Promise<GenerateResult>;
}

export class ProviderError extends Error {
  constructor(
    message: string,
    public provider: string,
    /** true when trying another provider or retrying later could succeed (rate limit, 5xx, network) */
    public retryable = true,
  ) {
    super(message);
  }
}

/** Rough token estimate for providers that don't report usage (≈4 chars/token). */
export const estimateTokens = (s: string) => Math.ceil(s.length / 4);
