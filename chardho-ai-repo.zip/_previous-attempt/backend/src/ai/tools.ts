import { prisma } from '../lib/db';

/**
 * Agent tools are the ONLY way agents touch data. Every tool is read-only and is bound to a single
 * businessId that the orchestrator has already verified belongs to the requesting user, so an agent
 * cannot read another tenant's records, run code, hit the network or publish anything.
 */
type Tool = (businessId: string) => Promise<string>;

const TOOLS: Record<string, Tool> = {
  async get_business_profile(businessId) {
    const b = await prisma.business.findUniqueOrThrow({ where: { id: businessId } });
    return JSON.stringify(
      {
        name: b.name,
        website: b.website,
        industry: b.industry,
        description: b.description,
        productsServices: b.productsServices,
        location: b.location,
        targetAudience: b.targetAudience,
        marketingObjectives: b.marketingObjectives,
        competitors: b.competitors,
        socialLinks: b.socialLinks,
        languages: b.languages,
      },
      null,
      2,
    );
  },

  async list_recent_content(businessId) {
    const items = await prisma.contentItem.findMany({
      where: { businessId, deletedAt: null },
      orderBy: { createdAt: 'desc' },
      take: 8,
      include: { currentVersion: { select: { body: true } } },
    });
    if (items.length === 0) return 'No content has been created yet.';
    return items.map((i) => `- [${i.type}/${i.status}] ${(i.currentVersion?.body ?? '').slice(0, 200)}`).join('\n');
  },

  async list_recorded_influencers(businessId) {
    const list = await prisma.influencer.findMany({ where: { businessId, deletedAt: null }, take: 25 });
    if (list.length === 0) return 'The user has not recorded any influencers yet. Do not suggest specific named people.';
    return list
      .map((i) =>
        `- @${i.handle} (${i.platform}) niche=${i.niche ?? 'n/a'} country=${i.country ?? 'n/a'} followers=${i.followers ?? 'unknown'} engagement=${i.engagementRate ?? 'unknown'} source=${i.metricsSource ?? 'unverified'}`,
      )
      .join('\n');
  },

  async list_recorded_leads(businessId) {
    const [count, byStatus] = await Promise.all([
      prisma.lead.count({ where: { businessId, deletedAt: null } }),
      prisma.lead.groupBy({ by: ['status'], where: { businessId, deletedAt: null }, _count: true }),
    ]);
    // Aggregate only: no personal contact data is ever passed to the model.
    return `Total leads: ${count}. By status: ${byStatus.map((s) => `${s.status}=${s._count}`).join(', ') || 'none'}.`;
  },

  async get_analytics_summary(businessId) {
    const since = new Date(Date.now() - 30 * 86_400_000);
    const rows = await prisma.analyticsSnapshot.groupBy({
      by: ['source', 'metric'],
      where: { businessId, capturedAt: { gte: since } },
      _sum: { value: true },
      _count: true,
    });
    if (rows.length === 0) return 'No analytics data has been collected yet (connect accounts and publish content first).';
    return rows.map((r) => `- ${r.source}/${r.metric}: total=${r._sum.value} over ${r._count} snapshots (last 30 days)`).join('\n');
  },
};

export async function runTools(names: string[], businessId: string): Promise<string> {
  const parts: string[] = [];
  for (const n of names) {
    const tool = TOOLS[n];
    if (!tool) continue; // unknown tool names are ignored, never executed
    parts.push(`### ${n}\n${await tool(businessId)}`);
  }
  return parts.join('\n\n');
}
