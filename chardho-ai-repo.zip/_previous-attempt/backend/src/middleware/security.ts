import type { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { config } from '../config';
import { forbidden } from '../lib/errors';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * CSRF defence for cookie-authenticated browsers:
 *  1. Session cookie is SameSite=Lax + HttpOnly.
 *  2. CORS only allows APP_URL.
 *  3. Every state-changing request must carry a custom header that a cross-site form cannot set,
 *     and its Origin (when present) must match APP_URL.
 * Bearer-token API clients and signed webhooks are exempt (no ambient credentials).
 */
export function csrfGuard(req: Request, _res: Response, next: NextFunction) {
  if (SAFE_METHODS.has(req.method)) return next();
  if (req.headers.authorization?.startsWith('Bearer ')) return next();
  if (req.path.startsWith('/api/webhooks/')) return next();

  const origin = req.headers.origin;
  if (origin && origin !== config.APP_URL) return next(forbidden('Cross-origin request blocked'));
  if (req.headers['x-requested-with'] !== 'chardho-web') return next(forbidden('Missing CSRF header'));
  next();
}

export const globalLimiter = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please slow down.' },
});

export const authLimiter = rateLimit({
  windowMs: 15 * 60_000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in a few minutes.' },
});

export const aiLimiter = rateLimit({
  windowMs: 60_000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.id ?? req.ip ?? 'anon',
  message: { error: 'AI request rate exceeded. Please wait a moment.' },
});
