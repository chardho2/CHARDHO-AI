import { logger } from './lib/logger';
import { prisma } from './lib/db';
import { processDueJobs } from './services/publisher';
import { enqueueScheduled, processQueuedRuns } from './services/workflows';

/** Standalone worker: publishes due approved posts and runs queued / scheduled workflows. */
async function tick() {
  try {
    await enqueueScheduled();
    const runs = await processQueuedRuns();
    const jobs = await processDueJobs();
    if (runs || jobs) logger.info({ runs, jobs }, 'worker processed work');
  } catch (err) {
    logger.error({ err }, 'worker tick failed');
  }
}

logger.info('CHARDHO AI worker started');
const timer = setInterval(tick, 30_000);
void tick();

const stop = async () => {
  clearInterval(timer);
  await prisma.$disconnect();
  process.exit(0);
};
process.on('SIGTERM', stop);
process.on('SIGINT', stop);
