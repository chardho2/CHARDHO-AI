import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { parse } from 'csv-parse/sync';
import { stringify } from 'csv-stringify/sync';
import { LeadStatus, Prisma } from '@prisma/client';
import { prisma } from '../lib/db';
import { asyncHandler, validateBody } from '../middleware/validate';
import { requireAuth, requireVerifiedEmail } from '../middleware/auth';
import { aiLimiter } from '../middleware/security';
import { assertBusinessAccess } from '../lib/tenant';
import { badRequest, notFound } from '../lib/errors';
import { cleanText } from '../services/content';
import { runAgent } from '../ai/orchestrator';

export const leadsRouter = Router();
leadsRouter.use(requireAuth);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });

/** Stable duplicate key: email, else phone digits, else company+contact name. */
export function dedupeKey(l: { email?: string | null; phone?: string | null; companyName?: string | null; contactName?: string | null }) {
  if (l.email) return `e:${l.email.trim().toLowerCase()}`;
  if (l.phone) return `p:${l.phone.replace(/\D/g, '')}`;
  return `n:${(l.companyName ?? '').trim().toLowerCase()}|${(l.contactName ?? '').trim().toLowerCase()}`;
}

/** Simple transparent scoring so users can see why a lead ranks where it does. */
export function scoreLead(l: { email?: string | null; phone?: string | null; companyName?: string | null; industry?: string | null }, bizIndustry?: string | null) {
  let s = 0;
  if (l.email) s += 30;
  if (l.phone) s += 20;
  if (l.companyName) s += 15;
  if (l.industry) s += 10;
  if (l.industry && bizIndustry && l.industry.toLowerCase() === bizIndustry.toLowerCase()) s += 25;
  return Math.min(100, s);
}

const leadSchema = z.object({
  businessId: z.string().min(1),
  source: z.string().trim().min(1).max(100).default('manual'),
  companyName: z.string().trim().max(200).optional(),
  contactName: z.string().trim().max(200).optional(),
  email: z.string().email().max(254).optional().or(z.literal('').transform(() => undefined)),
  phone: z.string().trim().max(40).optional(),
  industry: z.string().trim().max(150).optional(),
  // Required: record how this contact info was lawfully obtained (no unauthorised harvesting).
  consentBasis: z.string().trim().min(3, 'Describe how you obtained this contact (e.g. website enquiry, event sign-up)').max(300),
  notes: z.string().trim().max(4000).optional(),
});

leadsRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const businessId = String(req.query.businessId ?? '');
    await assertBusinessAccess(req.user!.id, businessId);
    const items = await prisma.lead.findMany({
      where: { businessId, deletedAt: null },
      orderBy: [{ score: 'desc' }, { createdAt: 'desc' }],
      take: 500,
    });
    res.json({ items });
  }),
);

leadsRouter.post(
  '/',
  validateBody(leadSchema),
  asyncHandler(async (req, res) => {
    const b = req.body as z.infer<typeof leadSchema>;
    const biz = await assertBusinessAccess(req.user!.id, b.businessId);
    const key = dedupeKey(b);
    const dup = await prisma.lead.findUnique({ where: { businessId_dedupeKey: { businessId: b.businessId, dedupeKey: key } } });
    if (dup && !dup.deletedAt) return res.status(409).json({ error: 'A lead with the same contact already exists.', existingId: dup.id });
    const data = {
      ...b,
      companyName: b.companyName && cleanText(b.companyName),
      contactName: b.contactName && cleanText(b.contactName),
      notes: b.notes && cleanText(b.notes),
      dedupeKey: key,
      score: scoreLead(b, biz.industry),
      assignedToId: req.user!.id,
      activity: [{ at: new Date().toISOString(), event: 'created', by: req.user!.id }] as Prisma.InputJsonValue,
    };
    // Re-creating a previously soft-deleted lead revives it instead of violating the unique key.
    const lead = dup
      ? await prisma.lead.update({ where: { id: dup.id }, data: { ...data, deletedAt: null, status: 'NEW' } })
      : await prisma.lead.create({ data });
    res.status(201).json({ lead });
  }),
);

leadsRouter.patch(
  '/:id',
  validateBody(
    z.object({
      status: z.nativeEnum(LeadStatus).optional(),
      notes: z.string().max(4000).optional(),
      score: z.number().int().min(0).max(100).optional(),
    }),
  ),
  asyncHandler(async (req, res) => {
    const lead = await prisma.lead.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
    if (!lead) throw notFound('Lead not found');
    const activity = [...((lead.activity as any[]) ?? []), { at: new Date().toISOString(), event: 'updated', by: req.user!.id, changes: Object.keys(req.body) }].slice(-200);
    const updated = await prisma.lead.update({
      where: { id: lead.id },
      data: { ...req.body, notes: req.body.notes !== undefined ? cleanText(req.body.notes) : undefined, activity },
    });
    res.json({ lead: updated });
  }),
);

leadsRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const lead = await prisma.lead.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
    if (!lead) throw notFound('Lead not found');
    await prisma.lead.update({ where: { id: lead.id }, data: { deletedAt: new Date() } });
    res.json({ ok: true });
  }),
);

/** CSV import: duplicates are skipped and reported. The importer attests consent basis for the whole file. */
leadsRouter.post(
  '/import',
  upload.single('file'),
  asyncHandler(async (req, res) => {
    const businessId = String(req.body?.businessId ?? '');
    const consentBasis = String(req.body?.consentBasis ?? '').trim();
    const biz = await assertBusinessAccess(req.user!.id, businessId);
    if (!req.file) throw badRequest('Attach a CSV file');
    if (!/\.csv$/i.test(req.file.originalname) || !/csv|text\/plain|excel/.test(req.file.mimetype)) throw badRequest('Only .csv files are accepted');
    if (consentBasis.length < 3) throw badRequest('Describe how these contacts were lawfully obtained (consentBasis).');

    let rows: Record<string, string>[];
    try {
      rows = parse(req.file.buffer.toString('utf8'), { columns: (h: string[]) => h.map((x) => x.trim().toLowerCase()), skip_empty_lines: true, trim: true, bom: true });
    } catch {
      throw badRequest('Could not parse CSV. Expected a header row such as: company,name,email,phone,industry');
    }
    if (rows.length > 2000) throw badRequest('Import is limited to 2,000 rows at a time');

    let created = 0, duplicates = 0, invalid = 0;
    for (const r of rows) {
      const email = r.email?.trim() || undefined;
      if (email && !z.string().email().safeParse(email).success) { invalid++; continue; }
      const l = { companyName: cleanText(r.company ?? r.companyname ?? ''), contactName: cleanText(r.name ?? r.contact ?? ''), email, phone: r.phone, industry: r.industry };
      if (!l.companyName && !l.contactName && !email && !l.phone) { invalid++; continue; }
      const key = dedupeKey(l);
      try {
        await prisma.lead.create({
          data: { businessId, source: 'csv-import', ...l, consentBasis, dedupeKey: key, score: scoreLead(l, biz.industry), assignedToId: req.user!.id, activity: [{ at: new Date().toISOString(), event: 'imported', by: req.user!.id }] },
        });
        created++;
      } catch (e) {
        if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') duplicates++;
        else throw e;
      }
    }
    res.json({ created, duplicates, invalid });
  }),
);

leadsRouter.get(
  '/export.csv',
  asyncHandler(async (req, res) => {
    const businessId = String(req.query.businessId ?? '');
    await assertBusinessAccess(req.user!.id, businessId);
    const leads = await prisma.lead.findMany({ where: { businessId, deletedAt: null }, orderBy: { createdAt: 'asc' } });
    // Prefix risky leading characters so spreadsheet apps don't execute cell values as formulas.
    const safe = (v?: string | null) => (v && /^[=+\-@\t\r]/.test(v) ? `'${v}` : v ?? '');
    const csv = stringify(
      leads.map((l) => ({ company: safe(l.companyName), name: safe(l.contactName), email: safe(l.email), phone: safe(l.phone), industry: safe(l.industry), status: l.status, score: l.score, source: l.source, consent_basis: safe(l.consentBasis), notes: safe(l.notes) })),
      { header: true },
    );
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="leads.csv"');
    res.send(csv);
  }),
);

/** AI outreach DRAFT for one lead. Nothing is sent; the user copies it into their own email client. */
leadsRouter.post(
  '/:id/outreach-draft',
  requireVerifiedEmail,
  aiLimiter,
  asyncHandler(async (req, res) => {
    const lead = await prisma.lead.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
    if (!lead) throw notFound('Lead not found');
    const { output } = await runAgent({
      userId: req.user!.id,
      businessId: lead.businessId,
      agentKey: 'LEAD_GENERATION',
      instruction: `Draft one short, personalised, compliant first-contact message to ${lead.contactName ?? 'the contact'} at ${lead.companyName ?? 'their company'} (industry: ${lead.industry ?? 'unknown'}). Contact basis: ${lead.consentBasis}. Include a polite way to opt out. Output only the message.`,
      signal: AbortSignal.timeout(120_000),
    });
    res.json({ draft: output, note: 'Draft only. Review it and send it yourself; CHARDHO AI never sends messages automatically.' });
  }),
);
