import { Router } from 'express';
import { z } from 'zod';
import { Prisma, SocialPlatform } from '@prisma/client';
import { prisma } from '../lib/db';
import { config } from '../config';
import { asyncHandler, validateBody } from '../middleware/validate';
import { requireAuth, requireVerifiedEmail } from '../middleware/auth';
import { aiLimiter } from '../middleware/security';
import { assertBusinessAccess } from '../lib/tenant';
import { notFound } from '../lib/errors';
import { audit } from '../lib/audit';
import { mailerIsDemo } from '../lib/mailer';
import { providerStatus } from '../ai/registry';
import { runAgent } from '../ai/orchestrator';
import { cleanText } from '../services/content';
import { executeRun, TEMPLATES, workflowDefSchema } from '../services/workflows';

const biz = (req: any) => assertBusinessAccess(req.user.id, String(req.query.businessId ?? req.body?.businessId ?? ''));

// ───────── Business intelligence ─────────
export const marketingRouter = Router();
marketingRouter.use(requireAuth);

marketingRouter.post(
  '/report',
  requireVerifiedEmail,
  aiLimiter,
  validateBody(z.object({ businessId: z.string().min(1) })),
  asyncHandler(async (req, res) => {
    await biz(req);
    const { output, task } = await runAgent({
      userId: req.user!.id,
      businessId: req.body.businessId,
      agentKey: 'MARKETING_MANAGER',
      instruction: 'Create a business intelligence report with these sections: Summary, Positioning, Audience segments, Competitor considerations (only from the competitors listed), Marketing opportunities (prioritised), 30-day action plan. Flag any missing profile information.',
      signal: AbortSignal.timeout(150_000),
    });
    const updated = await prisma.business.update({ where: { id: req.body.businessId }, data: { intelligenceReport: { text: output, taskId: task.id } as Prisma.InputJsonValue, reportGeneratedAt: new Date() } });
    res.json({ report: updated.intelligenceReport, generatedAt: updated.reportGeneratedAt });
  }),
);

// ───────── Calendar ─────────
export const calendarRouter = Router();
calendarRouter.use(requireAuth);

calendarRouter.get('/', asyncHandler(async (req, res) => {
  await biz(req);
  const items = await prisma.calendarEntry.findMany({ where: { businessId: String(req.query.businessId) }, orderBy: { scheduledFor: 'asc' }, take: 300 });
  res.json({ items });
}));

calendarRouter.post('/', validateBody(z.object({
  businessId: z.string().min(1), title: z.string().trim().min(1).max(200), scheduledFor: z.coerce.date(),
  platform: z.nativeEnum(SocialPlatform).optional(), contentId: z.string().optional(), notes: z.string().max(1000).optional(),
})), asyncHandler(async (req, res) => {
  await biz(req);
  if (req.body.contentId) {
    const c = await prisma.contentItem.findFirst({ where: { id: req.body.contentId, businessId: req.body.businessId, deletedAt: null } });
    if (!c) throw notFound('Content not found');
  }
  // A calendar entry is a plan only. Publishing still requires approval + scheduling.
  const item = await prisma.calendarEntry.create({ data: { ...req.body, title: cleanText(req.body.title), notes: req.body.notes && cleanText(req.body.notes) } });
  res.status(201).json({ item });
}));

calendarRouter.delete('/:id', asyncHandler(async (req, res) => {
  const e = await prisma.calendarEntry.findFirst({ where: { id: req.params.id, business: { ownerId: req.user!.id } } });
  if (!e) throw notFound('Entry not found');
  await prisma.calendarEntry.delete({ where: { id: e.id } });
  res.json({ ok: true });
}));

// ───────── Influencers (user-recorded data only) ─────────
export const influencersRouter = Router();
influencersRouter.use(requireAuth);

const influencerSchema = z.object({
  businessId: z.string().min(1), handle: z.string().trim().min(1).max(100).transform((h) => h.replace(/^@/, '')),
  platform: z.nativeEnum(SocialPlatform), niche: z.string().max(100).optional(), country: z.string().max(100).optional(),
  audienceCategory: z.string().max(100).optional(), followers: z.number().int().min(0).optional(),
  engagementRate: z.number().min(0).max(100).optional(), contactEmail: z.string().email().optional(),
  metricsSource: z.string().max(200).optional(), notes: z.string().max(2000).optional(),
});

influencersRouter.get('/', asyncHandler(async (req, res) => {
  await biz(req);
  const q = req.query as Record<string, string>;
  const items = await prisma.influencer.findMany({
    where: {
      businessId: q.businessId, deletedAt: null,
      ...(q.niche ? { niche: { contains: q.niche, mode: 'insensitive' } } : {}),
      ...(q.country ? { country: { contains: q.country, mode: 'insensitive' } } : {}),
      ...(q.platform ? { platform: q.platform as SocialPlatform } : {}),
      ...(q.audience ? { audienceCategory: { contains: q.audience, mode: 'insensitive' } } : {}),
    },
    orderBy: { createdAt: 'desc' }, take: 200,
  });
  res.json({ items, note: 'Only influencers you have recorded appear here. CHARDHO AI never invents influencer identities, metrics or contacts.' });
}));

influencersRouter.post('/', validateBody(influencerSchema), asyncHandler(async (req, res) => {
  await biz(req);
  const { businessId, notes, ...rest } = req.body;
  const verified = rest.followers !== undefined || rest.engagementRate !== undefined;
  const item = await prisma.influencer.create({
    data: { ...rest, businessId, notes: notes && cleanText(notes), metricsSource: rest.metricsSource ?? (verified ? 'manual-entry (unverified)' : undefined), metricsVerifiedAt: undefined },
  }).catch((e) => { if (e?.code === 'P2002') return null; throw e; });
  if (!item) return res.status(409).json({ error: 'This influencer is already recorded.' });
  res.status(201).json({ item });
}));

influencersRouter.post('/:id/verify', asyncHandler(async (req, res) => {
  const inf = await prisma.influencer.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!inf) throw notFound('Influencer not found');
  // The user attests they checked the numbers against the platform or a creator-provided media kit.
  res.json({ item: await prisma.influencer.update({ where: { id: inf.id }, data: { metricsVerifiedAt: new Date(), metricsSource: inf.metricsSource?.replace(' (unverified)', '') ?? 'user-verified' } }) });
}));

influencersRouter.post('/:id/proposal', requireVerifiedEmail, aiLimiter, validateBody(z.object({ campaignGoal: z.string().trim().min(3).max(1000) })), asyncHandler(async (req, res) => {
  const inf = await prisma.influencer.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!inf) throw notFound('Influencer not found');
  const { output } = await runAgent({
    userId: req.user!.id, businessId: inf.businessId, agentKey: 'INFLUENCER_MANAGER',
    instruction: `Draft a collaboration proposal and a short outreach email for @${inf.handle} on ${inf.platform} (niche: ${inf.niche ?? 'unknown'}). Campaign goal: ${req.body.campaignGoal}. Use only the recorded facts (followers: ${inf.followers ?? 'unknown'}). Do not invent metrics. Output: PROPOSAL, then EMAIL.`,
    signal: AbortSignal.timeout(120_000),
  });
  res.json({ draft: output, note: 'Draft only. You send it yourself.' });
}));

influencersRouter.delete('/:id', asyncHandler(async (req, res) => {
  const inf = await prisma.influencer.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!inf) throw notFound('Influencer not found');
  await prisma.influencer.update({ where: { id: inf.id }, data: { deletedAt: new Date() } });
  res.json({ ok: true });
}));

// ───────── Automation ─────────
export const automationRouter = Router();
automationRouter.use(requireAuth);

automationRouter.get('/templates', (_req, res) => res.json({ items: TEMPLATES }));

automationRouter.get('/', asyncHandler(async (req, res) => {
  await biz(req);
  res.json({ items: await prisma.automationWorkflow.findMany({ where: { businessId: String(req.query.businessId), deletedAt: null }, orderBy: { createdAt: 'desc' } }) });
}));

automationRouter.post('/', validateBody(workflowDefSchema.extend({ businessId: z.string().min(1), templateKey: z.string().optional() })), asyncHandler(async (req, res) => {
  await biz(req);
  const { businessId, templateKey, ...def } = req.body;
  const wf = await prisma.automationWorkflow.create({ data: { businessId, name: cleanText(def.name), trigger: def.trigger, steps: def.steps, templateKey } });
  await audit(req, 'workflow.create', { entityType: 'AutomationWorkflow', entityId: wf.id });
  res.status(201).json({ workflow: wf });
}));

automationRouter.patch('/:id', validateBody(z.object({ enabled: z.boolean().optional() })), asyncHandler(async (req, res) => {
  const wf = await prisma.automationWorkflow.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!wf) throw notFound('Workflow not found');
  res.json({ workflow: await prisma.automationWorkflow.update({ where: { id: wf.id }, data: req.body }) });
}));

automationRouter.delete('/:id', asyncHandler(async (req, res) => {
  const wf = await prisma.automationWorkflow.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!wf) throw notFound('Workflow not found');
  await prisma.automationWorkflow.update({ where: { id: wf.id }, data: { deletedAt: new Date(), enabled: false } });
  res.json({ ok: true });
}));

automationRouter.post('/:id/run', requireVerifiedEmail, asyncHandler(async (req, res) => {
  const wf = await prisma.automationWorkflow.findFirst({ where: { id: req.params.id, deletedAt: null, business: { ownerId: req.user!.id } } });
  if (!wf) throw notFound('Workflow not found');
  const run = await prisma.workflowRun.create({ data: { workflowId: wf.id, triggerData: { manual: true } } });
  void executeRun(run.id); // fire and forget: client polls /runs
  res.status(202).json({ run });
}));

automationRouter.get('/runs', asyncHandler(async (req, res) => {
  await biz(req);
  const items = await prisma.workflowRun.findMany({ where: { workflow: { businessId: String(req.query.businessId), business: { ownerId: req.user!.id } } }, orderBy: { createdAt: 'desc' }, take: 50, include: { workflow: { select: { name: true } } } });
  res.json({ items });
}));

for (const [action, to, from] of [['pause', 'PAUSED', ['RUNNING', 'QUEUED']], ['cancel', 'CANCELLED', ['RUNNING', 'QUEUED', 'PAUSED']]] as const) {
  automationRouter.post(`/runs/:runId/${action}`, asyncHandler(async (req, res) => {
    const r = await prisma.workflowRun.updateMany({ where: { id: req.params.runId, status: { in: [...from] }, workflow: { business: { ownerId: req.user!.id } } }, data: { status: to } });
    if (!r.count) throw notFound('Run not found or not in a state that allows this');
    res.json({ ok: true });
  }));
}
automationRouter.post('/runs/:runId/resume', asyncHandler(async (req, res) => {
  const r = await prisma.workflowRun.updateMany({ where: { id: req.params.runId, status: 'PAUSED', workflow: { business: { ownerId: req.user!.id } } }, data: { status: 'QUEUED' } });
  if (!r.count) throw notFound('Paused run not found');
  void executeRun(req.params.runId);
  res.json({ ok: true });
}));

// ───────── Notifications, analytics, integrations status ─────────
export const notificationsRouter = Router();
notificationsRouter.use(requireAuth);
notificationsRouter.get('/', asyncHandler(async (req, res) => {
  res.json({ items: await prisma.notification.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' }, take: 50 }) });
}));
notificationsRouter.post('/read-all', asyncHandler(async (req, res) => {
  await prisma.notification.updateMany({ where: { userId: req.user!.id, readAt: null }, data: { readAt: new Date() } });
  res.json({ ok: true });
}));

export const analyticsRouter = Router();
analyticsRouter.use(requireAuth);
analyticsRouter.get('/', asyncHandler(async (req, res) => {
  await biz(req);
  const businessId = String(req.query.businessId);
  const [content, byStatus, jobs, leads, tasks] = await Promise.all([
    prisma.contentItem.count({ where: { businessId, deletedAt: null } }),
    prisma.contentItem.groupBy({ by: ['status'], where: { businessId, deletedAt: null }, _count: true }),
    prisma.publishingJob.groupBy({ by: ['status'], where: { content: { businessId } }, _count: true }),
    prisma.lead.groupBy({ by: ['status'], where: { businessId, deletedAt: null }, _count: true }),
    prisma.agentTask.groupBy({ by: ['status'], where: { businessId }, _count: true }),
  ]);
  const platform = await prisma.analyticsSnapshot.count({ where: { businessId } });
  res.json({
    internal: { content, byStatus, publishing: jobs, leads, agentTasks: tasks },
    platformAnalytics: { available: platform > 0, note: platform ? undefined : 'No platform analytics collected yet. Platform metrics appear only for connected real accounts that have published posts.' },
  });
}));

export const integrationsRouter = Router();
integrationsRouter.use(requireAuth);
integrationsRouter.get('/', asyncHandler(async (_req, res) => {
  const providers = await providerStatus();
  const flag = (configured: boolean) => (configured ? 'live' : 'not_configured');
  res.json({
    items: [
      { key: 'ai', label: 'AI providers', status: providers.length ? 'live' : 'not_configured', detail: providers.map((p) => `${p.name}:${p.model}${p.paid ? ' (paid)' : ' (free)'}`) },
      { key: 'email', label: 'System email (SMTP)', status: mailerIsDemo ? 'demo' : 'live', detail: mailerIsDemo ? ['Emails are logged to the server console, not delivered.'] : [] },
      { key: 'google', label: 'Google sign-in', status: flag(!!config.GOOGLE_CLIENT_ID && !!config.GOOGLE_CLIENT_SECRET) },
      { key: 'linkedin', label: 'LinkedIn publishing', status: flag(!!config.LINKEDIN_CLIENT_ID) },
      { key: 'x', label: 'X publishing', status: flag(!!config.X_CLIENT_ID) },
      { key: 'meta', label: 'Facebook & Instagram publishing', status: flag(!!config.META_APP_ID) },
      { key: 'youtube', label: 'YouTube', status: flag(!!config.YOUTUBE_CLIENT_ID), detail: ['Account connection only; text-post publishing is not available for YouTube.'] },
      { key: 'n8n', label: 'n8n automation bridge', status: flag(!!config.N8N_BASE_URL), detail: ['Built-in workflow engine is always active.'] },
    ],
  });
}));
