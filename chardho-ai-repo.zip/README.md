# CHARDHO AI — Create. Automate. Promote. Grow.

Free multi-agent AI marketing platform (Express + TypeScript + Prisma/PostgreSQL backend, React + Vite frontend).

## Quick start (Docker)
```bash
cp .env.example .env            # set JWT_SECRET, ENCRYPTION_KEY (openssl rand -hex 32), OWNER_EMAIL/PASSWORD, POSTGRES_PASSWORD
docker compose --profile full up -d --build        # postgres, backend(+migrations), worker, frontend, nightly pg_dump backup
docker compose exec backend npx tsx prisma/seed.ts  # creates the Owner account (or run `npm run seed -w backend` locally)
# optional free local AI:  docker compose --profile local-ai up -d ollama && docker compose exec ollama ollama pull llama3.1
open http://localhost:8080
```
## Local development
```bash
docker compose up -d postgres
npm install
cp backend/.env.example backend/.env
cd backend && npx prisma migrate dev --name init && npm run seed
npm run dev:backend   # :4000      (API docs: /api/docs)
npm run worker -w backend
npm run dev:frontend  # :5173
```
**Generate the initial migration once (`prisma migrate dev --name init`) and commit `backend/prisma/migrations/`.** Without it the container falls back to `prisma db push` on first boot.

## Architecture
- `backend/src/agents` 13 agent definitions (system prompt + whitelisted tools). `services/orchestrator.ts` routes a request to agents (LLM planner with keyword fallback), runs them sequentially passing summaries forward, validates input/output with zod, retries 3×, records tasks/usage.
- Agents have no code-execution, no cross-tenant reads and **no publish path**: their only write tool creates `DRAFT`/`QUALITY_CHECKED` content.
- `providers/` Ollama → Gemini (free tier) → OpenAI, chosen by priority, capability, daily limit and availability. **Paid providers are skipped unless `ALLOW_PAID_PROVIDERS=true`** *and* enabled by the owner. Keys are AES-256-GCM encrypted at rest; cost per call is stored in `ApiProviderCost`.
- `services/approvals.ts` approval engine: submit → human approve (version+hash+account+user+time stored) → schedule → worker publishes. Editing creates a new version, invalidates approvals and cancels pending jobs; the worker re-verifies approval and hash at publish time; a unique idempotency key `(content, version, account)` plus an atomic PENDING→IN_PROGRESS claim prevents duplicates; all API responses are stored.
- `jobs/worker.ts` DB-backed worker (safe to run N replicas): publishes due jobs, runs workflow runs, fires scheduled workflows.
- Tenant isolation: every query is scoped by `userId` (and business ownership is checked via `ownBusiness`). Roles: OWNER > SUPER_ADMIN > ADMIN > USER, enforced in `middleware/auth.ts` and `routes/admin.ts`.

## Honest status of integrations
| Integration | Status |
|---|---|
| Email register/verify/reset | Works; without SMTP the links are logged to the server console (shown as "demo" in Settings) |
| Google login | Works once `GOOGLE_CLIENT_ID/SECRET` are set |
| X, LinkedIn, Facebook Page publishing | Implemented against official APIs; needs your app credentials, and each platform's app review/permissions |
| Instagram | Needs a Business account and an attached image (API limitation) |
| YouTube | Connect + analytics only; video upload is **not** implemented (scripts/descriptions are for manual use) |
| Image generation | Only via an owner-enabled paid OpenAI key; otherwise returns a creative brief |
| Video generation | Not implemented; scripts, storyboards and voice-over text are generated |
| n8n | Signed outbound action + signed inbound webhook (`/api/automation/webhook/n8n`) |
| Redis | Provisioned in compose but **not used yet** (queues are Postgres-backed); add it when you need distributed rate limiting |
| Influencer "search" | Searches influencers *you* recorded (metrics require a stated source); it never invents people |

## Security notes
bcrypt(12) passwords, JWT with server-side revocation (`tokenVersion`), rate limits, helmet, zod validation, Prisma (parameterised SQL), magic-byte upload checks, encrypted tokens, HMAC webhooks, audit log. The SPA stores its token in `localStorage`; keep a strict CSP at your proxy and consider moving to httpOnly cookies + CSRF tokens before heavy production use.

## Deployment on a low-cost stack
Frontend → Cloudflare Pages/Netlify (`VITE_API_URL=https://api.example.com`); API + worker → two services from `backend/Dockerfile` (the worker overrides the command to `node dist/jobs/worker.js`; only the API sets `RUN_MIGRATIONS=true`); Postgres → Neon/Supabase free tier; media → a persistent volume (swap `routes/media.ts` for S3/R2 to scale horizontally). Backups: bundled nightly `pg_dump` container or your provider's PITR. Health check: `GET /health`.

## Tests
`npm test` runs unit tests for hashing, quality gates, crypto, workflow conditions, lead dedupe/scoring and agent-output parsing.
**Not yet covered by automated tests: anything touching the database (approval flow, tenant isolation, publishing).** Run through the acceptance list in the master prompt against a real Postgres before launch.
