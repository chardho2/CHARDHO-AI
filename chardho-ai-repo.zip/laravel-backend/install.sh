#!/usr/bin/env bash
# Creates a fresh Laravel 11 app and overlays the CHARDHO AI backend onto it.
# Usage: ./install.sh [target-dir]    (needs php>=8.2, composer, a database from .env)
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${1:-$SRC/../chardho-laravel-app}"

composer create-project laravel/laravel "$DEST" "^11.0" --prefer-dist
cd "$DEST"
php artisan install:api --no-interaction || composer require laravel/sanctum
# overlay: our migration extends the stock users table, so keep Laravel default migrations
for d in app bootstrap config database routes tests; do cp -R "$SRC/$d/." "$DEST/$d/"; done
cp "$SRC/.env.example" .env.example
[ -f .env ] || cp .env.example .env
php artisan key:generate --force
php artisan storage:link || true
echo
echo "Edit .env (DB_*, OWNER_EMAIL/OWNER_PASSWORD, APP_FRONTEND_URL), then run:"
echo "  php artisan migrate --force && php artisan db:seed --force"
echo "  php artisan serve            # API on :8000"
echo "  php artisan chardho:tick --loop   # worker (or add the cron entry for schedule:run)"
