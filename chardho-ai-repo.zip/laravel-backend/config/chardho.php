<?php

return [
    'app_url' => env('APP_FRONTEND_URL', 'http://localhost:5173'),
    'api_url' => env('APP_URL', 'http://localhost:8000'),
    'daily_ai_limit' => (int) env('DAILY_AI_REQUEST_LIMIT', 50),
    // Paid providers are skipped unless the owner explicitly sets this to true.
    'allow_paid' => filter_var(env('ALLOW_PAID_PROVIDERS', false), FILTER_VALIDATE_BOOLEAN),
    'providers' => [
        'ollama' => ['model' => env('OLLAMA_MODEL', 'llama3.1'), 'base_url' => env('OLLAMA_BASE_URL', 'http://localhost:11434')],
        'gemini' => ['model' => env('GEMINI_MODEL', 'gemini-1.5-flash'), 'api_key' => env('GEMINI_API_KEY')],
        'openai' => ['model' => env('OPENAI_MODEL', 'gpt-4o-mini'), 'api_key' => env('OPENAI_API_KEY')],
    ],
    'google' => ['client_id' => env('GOOGLE_CLIENT_ID'), 'client_secret' => env('GOOGLE_CLIENT_SECRET')],
    'n8n' => ['webhook_url' => env('N8N_WEBHOOK_URL'), 'secret' => env('N8N_SHARED_SECRET')],
    'social' => [
        'X' => ['id' => env('X_CLIENT_ID'), 'secret' => env('X_CLIENT_SECRET')],
        'LINKEDIN' => ['id' => env('LINKEDIN_CLIENT_ID'), 'secret' => env('LINKEDIN_CLIENT_SECRET')],
        'FACEBOOK' => ['id' => env('META_APP_ID'), 'secret' => env('META_APP_SECRET')],
        'INSTAGRAM' => ['id' => env('META_APP_ID'), 'secret' => env('META_APP_SECRET')],
        'YOUTUBE' => ['id' => env('YOUTUBE_CLIENT_ID', env('GOOGLE_CLIENT_ID')), 'secret' => env('YOUTUBE_CLIENT_SECRET', env('GOOGLE_CLIENT_SECRET'))],
    ],
];
