<?php

return [
    'paths' => ['api/*', 'media/*'],
    'allowed_methods' => ['*'],
    'allowed_origins' => array_filter([env('APP_FRONTEND_URL', 'http://localhost:5173')]),
    'allowed_origins_patterns' => [],
    'allowed_headers' => ['*'],
    'exposed_headers' => [],
    'max_age' => 600,
    'supports_credentials' => false,   // bearer tokens, no cookies
];
