<?php
// Framework-free check: php tests/Unit/logic_check.php
require __DIR__ . '/../../app/Support/Logic.php';
use App\Support\Logic;
$fail = 0;
function t(string $name, bool $ok) { global $fail; echo ($ok ? "PASS " : "FAIL ") . $name . "\n"; if (!$ok) $fail++; }
t('hash changes with body', Logic::contentHash('a', [], []) !== Logic::contentHash('b', [], []));
t('hash changes with hashtags', Logic::contentHash('a', ['x'], []) !== Logic::contentHash('a', ['y'], []));
t('hash stable ignoring tag order/whitespace', Logic::contentHash(' a ', ['x', 'y'], []) === Logic::contentHash('a', ['y', 'x'], []));
t('quality rejects empty', !Logic::quality('  ', 'X')['ok']);
t('quality rejects X > 280', !Logic::quality(str_repeat('a', 281), 'X')['ok']);
t('quality accepts normal', Logic::quality('Hello world', 'INSTAGRAM')['ok']);
t('quality flags placeholder', !Logic::quality('Buy now [insert link]', null)['ok']);
t('json fences', Logic::parseJsonLoose("```json\n{\"summary\":\"ok\"}\n```")['summary'] === 'ok');
t('json chatter', Logic::parseJsonLoose('Sure! {"summary":"ok"} done')['summary'] === 'ok');
$n = Logic::normalizeAgentOutput(['summary' => 's', 'drafts' => [['type' => 'social_post', 'platform' => 'twitter', 'body' => 'hi']]]);
t('platform twitter->X', $n['drafts'][0]['platform'] === 'X');
try { Logic::normalizeAgentOutput(['summary' => 's', 'drafts' => [['type' => 't', 'body' => '']]]); t('empty body rejected', false); } catch (\InvalidArgumentException) { t('empty body rejected', true); }
t('dedupe email', Logic::dedupeKey(' A@B.com ', null, null, null) === 'a@b.com');
t('dedupe phone', Logic::dedupeKey(null, '+1 (555) 123-4567', null, null) === '15551234567');
t('score max 100', Logic::scoreLead('a@b.c', '1', 'x', 'y', 'won') === 100);
t('score min 0', Logic::scoreLead(null, null, null, null, 'lost') === 0);
$ctx = ['trigger' => ['score' => 80, 'tags' => ['vip'], 'name' => 'Acme Ltd']];
t('cond gt', Logic::condition(['path' => 'trigger.score', 'op' => 'gt', 'value' => 50], $ctx));
t('cond contains array', Logic::condition(['path' => 'trigger.tags', 'op' => 'contains', 'value' => 'vip'], $ctx));
t('cond contains string', Logic::condition(['path' => 'trigger.name', 'op' => 'contains', 'value' => 'Acme'], $ctx));
t('cond exists false', !Logic::condition(['path' => 'trigger.missing', 'op' => 'exists'], $ctx));
t('template', Logic::template('Hi ${trigger.name}!', $ctx) === 'Hi Acme Ltd!');
$csv = Logic::parseCsv("businessName,email\r\n\"Acme, Inc\",a@b.com\n\"Say \"\"hi\"\"\",c@d.com\n");
t('csv quoted comma', $csv[1][0] === 'Acme, Inc' && count($csv) === 3);
t('csv escaped quote', $csv[2][0] === 'Say "hi"');
t('csv injection guard', Logic::csvCell('=cmd()') === "'=cmd()");
t('sniff png', Logic::sniffImage("\x89PNG\r\n\x1a\nxxxx")['ext'] === 'png');
t('sniff rejects php', Logic::sniffImage('<?php echo 1;') === null);
echo $fail ? "\n$fail FAILED\n" : "\nALL PASSED\n"; exit($fail ? 1 : 0);
