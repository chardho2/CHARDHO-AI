<?php

use App\Http\Middleware\EnsureActive;
use App\Http\Middleware\RequireRole;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        apiPrefix: 'api',
        then: function () {
            // Public image URL (Instagram/Facebook fetch media by URL). Unguessable ULIDs, images only.
            Route::get('/media/{id}', [\App\Http\Controllers\MediaController::class, 'show']);
        },
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias(['active' => EnsureActive::class, 'role' => RequireRole::class]);
        $middleware->throttleApi('api');
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $json = fn (Request $r) => $r->is('api/*') || $r->is('media/*') || $r->expectsJson();

        // Same error envelope as the Node API: { error, details? }
        $exceptions->render(function (ValidationException $e, Request $r) use ($json) {
            if (!$json($r)) return null;
            return response()->json(['error' => 'Validation failed', 'details' => $e->errors()], 422);
        });
        $exceptions->render(function (AuthenticationException $e, Request $r) use ($json) {
            return $json($r) ? response()->json(['error' => 'Unauthorized'], 401) : null;
        });
        $exceptions->render(function (ModelNotFoundException|NotFoundHttpException $e, Request $r) use ($json) {
            return $json($r) ? response()->json(['error' => 'Not found'], 404) : null;
        });
        $exceptions->render(function (HttpExceptionInterface $e, Request $r) use ($json) {
            if (!$json($r)) return null;
            return response()->json(['error' => $e->getMessage() ?: 'Request failed'], $e->getStatusCode(), $e->getHeaders());
        });
        $exceptions->render(function (\Throwable $e, Request $r) use ($json) {
            if (!$json($r)) return null;
            report($e);
            return response()->json(['error' => config('app.debug') ? $e->getMessage() : 'Internal server error'], 500);
        });
    })->create();
