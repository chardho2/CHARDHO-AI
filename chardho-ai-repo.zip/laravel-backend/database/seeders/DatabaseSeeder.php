<?php

namespace Database\Seeders;

use App\Models\AiAgent;
use App\Models\Setting;
use App\Models\User;
use App\Services\AgentRegistry;
use App\Services\ProviderManager;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        ProviderManager::ensureDefaults();

        foreach (AgentRegistry::all() as $key => $a) {
            AiAgent::firstOrCreate(['key' => $key], ['name' => $a['name'], 'description' => $a['description'], 'system_prompt' => $a['systemPrompt'], 'tools' => $a['tools'], 'enabled' => true]);
        }

        foreach (['registrationOpen' => true, 'maintenanceMode' => false] as $k => $v) {
            if (Setting::find($k) === null) Setting::put($k, $v);
        }

        // Owner account is created only from env values; there is no default password.
        $email = env('OWNER_EMAIL');
        $pass = env('OWNER_PASSWORD');
        if ($email && $pass) {
            if (strlen($pass) < 12) throw new \RuntimeException('OWNER_PASSWORD must be at least 12 characters');
            $u = User::firstOrNew(['email' => strtolower($email)]);
            if (!$u->exists) { $u->name = 'Owner'; $u->password = $pass; }
            $u->role = 'OWNER';
            $u->email_verified_at ??= now();
            $u->save();
            $this->command?->info("Owner account ready: {$u->email}");
        } else {
            $this->command?->warn('OWNER_EMAIL / OWNER_PASSWORD not set: no owner account created.');
        }
    }
}
