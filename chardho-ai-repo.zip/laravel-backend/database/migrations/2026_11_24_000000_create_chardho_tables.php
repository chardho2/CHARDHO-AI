<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Extend the stock users table.
        Schema::table('users', function (Blueprint $t) {
            $t->string('role')->default('USER')->index();
            $t->string('google_id')->nullable()->unique();
            $t->timestamp('disabled_at')->nullable();
            $t->string('locale', 10)->default('en');
            $t->softDeletes();
        });
        Schema::table('users', fn (Blueprint $t) => $t->string('password')->nullable()->change());

        Schema::create('auth_tokens', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('type'); // EMAIL_VERIFY | PASSWORD_RESET
            $t->string('token_hash')->unique();
            $t->timestamp('expires_at');
            $t->timestamp('used_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'type']);
        });

        Schema::create('businesses', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('name');
            $t->string('website')->nullable();
            $t->string('industry')->nullable();
            $t->text('description')->nullable();
            $t->text('products_services')->nullable();
            $t->string('location')->nullable();
            $t->text('target_audience')->nullable();
            $t->text('objectives')->nullable();
            $t->json('competitors')->nullable();
            $t->json('social_links')->nullable();
            $t->json('languages')->nullable();
            $t->json('intelligence')->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->index(['user_id', 'deleted_at']);
        });

        Schema::create('ai_agents', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->string('key')->unique();
            $t->string('name');
            $t->text('description');
            $t->text('system_prompt');
            $t->json('tools');
            $t->boolean('enabled')->default(true);
            $t->timestamps();
        });

        Schema::create('agent_tasks', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('agent_key');
            $t->ulid('parent_id')->nullable();
            $t->json('input');
            $t->json('output')->nullable();
            $t->string('status')->default('QUEUED');
            $t->unsignedInteger('attempts')->default(0);
            $t->text('error')->nullable();
            $t->string('provider')->nullable();
            $t->string('model')->nullable();
            $t->unsignedInteger('tokens_in')->default(0);
            $t->unsignedInteger('tokens_out')->default(0);
            $t->timestamp('started_at')->nullable();
            $t->timestamp('finished_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'created_at']);
            $t->index(['business_id', 'status']);
        });

        Schema::create('conversations', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('title')->nullable();
            $t->timestamps();
        });
        Schema::create('messages', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignUlid('conversation_id')->constrained('conversations')->cascadeOnDelete();
            $t->string('role');
            $t->longText('content');
            $t->string('agent_key')->nullable();
            $t->timestamps();
        });

        Schema::create('campaigns', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('name');
            $t->string('kind')->default('marketing');
            $t->string('status')->default('planned');
            $t->text('objective')->nullable();
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->json('report')->nullable();
            $t->timestamps();
            $t->softDeletes();
        });

        Schema::create('content_items', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->foreignUlid('campaign_id')->nullable()->constrained('campaigns')->nullOnDelete();
            $t->string('type');
            $t->string('platform')->nullable();
            $t->string('title')->nullable();
            $t->string('status')->default('DRAFT');
            $t->unsignedInteger('current_version')->default(1);
            $t->string('language')->default('en');
            $t->string('tone')->nullable();
            $t->string('audience')->nullable();
            $t->string('created_by_agent')->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->index(['user_id', 'status']);
            $t->index(['business_id', 'type']);
        });
        Schema::create('content_versions', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignUlid('content_id')->constrained('content_items')->cascadeOnDelete();
            $t->unsignedInteger('version');
            $t->longText('body');
            $t->json('hashtags');
            $t->json('media_asset_ids');
            $t->string('content_hash');
            $t->string('created_by');
            $t->timestamps();
            $t->unique(['content_id', 'version']);
        });

        Schema::create('media_assets', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('kind');
            $t->string('mime_type');
            $t->string('path');
            $t->unsignedInteger('size_bytes');
            $t->text('prompt')->nullable();
            $t->string('aspect')->nullable();
            $t->timestamps();
            $t->softDeletes();
        });

        Schema::create('social_accounts', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('platform');
            $t->string('external_id');
            $t->string('display_name')->nullable();
            $t->text('access_token_enc');
            $t->text('refresh_token_enc')->nullable();
            $t->timestamp('expires_at')->nullable();
            $t->json('scopes')->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->unique(['business_id', 'platform', 'external_id']);
        });

        Schema::create('influencers', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('name');
            $t->string('platform');
            $t->string('handle');
            $t->string('profile_url')->nullable();
            $t->string('niche')->nullable();
            $t->string('country')->nullable();
            $t->string('audience')->nullable();
            $t->unsignedBigInteger('followers')->nullable();
            $t->float('engagement')->nullable();
            $t->string('metrics_source')->nullable();
            $t->timestamp('metrics_verified_at')->nullable();
            $t->string('contact_email')->nullable();
            $t->text('notes')->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->unique(['business_id', 'platform', 'handle']);
        });
        Schema::create('influencer_outreach', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('influencer_id')->constrained('influencers')->cascadeOnDelete();
            $t->foreignUlid('campaign_id')->nullable()->constrained('campaigns')->nullOnDelete();
            $t->string('subject')->nullable();
            $t->longText('message');
            $t->string('status')->default('draft');
            $t->text('response')->nullable();
            $t->json('deliverables')->nullable();
            $t->timestamps();
        });

        Schema::create('calendar_entries', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->foreignUlid('content_id')->nullable()->constrained('content_items')->nullOnDelete();
            $t->string('title');
            $t->timestamp('date');
            $t->string('platform')->nullable();
            $t->text('note')->nullable();
            $t->timestamps();
            $t->index(['business_id', 'date']);
        });

        Schema::create('approvals', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignUlid('content_id')->constrained('content_items')->cascadeOnDelete();
            $t->unsignedInteger('version');
            $t->string('content_hash');
            $t->foreignUlid('social_account_id')->constrained('social_accounts');
            $t->foreignId('approved_by_id')->constrained('users');
            $t->timestamp('approved_at');
            $t->timestamp('scheduled_for')->nullable();
            $t->timestamp('invalidated_at')->nullable();
            $t->string('invalid_reason')->nullable();
            $t->timestamps();
            $t->index(['content_id', 'invalidated_at']);
        });
        Schema::create('publishing_jobs', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignUlid('content_id')->constrained('content_items')->cascadeOnDelete();
            $t->foreignUlid('approval_id')->constrained('approvals');
            $t->foreignUlid('social_account_id')->constrained('social_accounts');
            $t->string('idempotency_key')->unique();
            $t->string('status')->default('PENDING');
            $t->timestamp('run_at');
            $t->unsignedInteger('attempts')->default(0);
            $t->string('external_post_id')->nullable();
            $t->json('api_response')->nullable();
            $t->text('error')->nullable();
            $t->timestamps();
            $t->index(['status', 'run_at']);
        });

        Schema::create('automation_workflows', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('name');
            $t->string('trigger');
            $t->json('graph');
            $t->boolean('enabled')->default(true);
            $t->boolean('paused')->default(false);
            $t->timestamp('last_run_at')->nullable();
            $t->timestamps();
            $t->softDeletes();
        });
        Schema::create('workflow_runs', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignUlid('workflow_id')->constrained('automation_workflows')->cascadeOnDelete();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('status')->default('QUEUED')->index();
            $t->json('trigger_data')->nullable();
            $t->json('logs')->nullable();
            $t->unsignedInteger('step_index')->default(0);
            $t->unsignedInteger('attempts')->default(0);
            $t->text('error')->nullable();
            $t->timestamp('started_at')->nullable();
            $t->timestamp('finished_at')->nullable();
            $t->timestamps();
        });

        Schema::create('leads', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('source');
            $t->string('business_name')->nullable();
            $t->string('contact_name')->nullable();
            $t->string('email')->nullable();
            $t->string('phone', 40)->nullable();
            $t->string('consent_basis')->nullable();
            $t->string('industry')->nullable();
            $t->unsignedTinyInteger('score')->default(0);
            $t->string('status')->default('new');
            $t->unsignedBigInteger('assigned_to_id')->nullable();
            $t->text('notes')->nullable();
            $t->json('activity')->nullable();
            $t->string('dedupe_key');
            $t->timestamps();
            $t->softDeletes();
            $t->unique(['business_id', 'dedupe_key']);
        });

        Schema::create('email_campaigns', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('name');
            $t->string('subject');
            $t->longText('body');
            $t->string('status')->default('draft');
            $t->timestamps();
        });

        Schema::create('analytics_snapshots', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignUlid('business_id')->constrained('businesses')->cascadeOnDelete();
            $t->string('platform')->nullable();
            $t->string('metric');
            $t->double('value');
            $t->string('source');
            $t->timestamp('captured_at')->useCurrent();
            $t->timestamps();
            $t->index(['business_id', 'metric', 'captured_at']);
        });

        Schema::create('chardho_notifications', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('title');
            $t->text('body')->nullable();
            $t->timestamp('read_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'read_at']);
        });

        Schema::create('provider_configs', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->string('key')->unique();
            $t->string('name');
            $t->string('model');
            $t->boolean('enabled')->default(true);
            $t->boolean('paid')->default(false);
            $t->unsignedInteger('priority')->default(100);
            $t->unsignedInteger('daily_limit')->nullable();
            $t->json('capabilities');
            $t->text('api_key_enc')->nullable();
            $t->string('base_url')->nullable();
            $t->timestamps();
        });
        Schema::create('integrations', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->string('key')->unique();
            $t->string('name');
            $t->boolean('enabled')->default(false);
            $t->string('status')->default('not_configured');
            $t->text('config_enc')->nullable();
            $t->timestamps();
        });
        Schema::create('usage_records', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('kind');
            $t->string('agent_key')->nullable();
            $t->string('provider')->nullable();
            $t->string('model')->nullable();
            $t->unsignedInteger('tokens_in')->default(0);
            $t->unsignedInteger('tokens_out')->default(0);
            $t->timestamps();
            $t->index(['user_id', 'created_at']);
        });
        Schema::create('api_provider_costs', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->string('provider');
            $t->string('model');
            $t->unsignedInteger('tokens_in');
            $t->unsignedInteger('tokens_out');
            $t->decimal('cost_usd', 12, 6)->default(0);
            $t->timestamps();
            $t->index(['provider', 'created_at']);
        });
        Schema::create('support_tickets', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('subject');
            $t->text('body');
            $t->string('status')->default('open');
            $t->timestamps();
        });
        Schema::create('announcements', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->string('title');
            $t->text('body');
            $t->boolean('active')->default(true);
            $t->timestamps();
        });
        Schema::create('settings', function (Blueprint $t) {
            $t->string('key')->primary();
            $t->json('value');
        });
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->ulid('id')->primary();
            $t->unsignedBigInteger('user_id')->nullable()->index();
            $t->string('action')->index();
            $t->string('entity')->nullable();
            $t->string('entity_id')->nullable();
            $t->json('meta')->nullable();
            $t->string('ip')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['audit_logs', 'settings', 'announcements', 'support_tickets', 'api_provider_costs', 'usage_records', 'integrations', 'provider_configs', 'chardho_notifications', 'analytics_snapshots', 'email_campaigns', 'leads', 'workflow_runs', 'automation_workflows', 'publishing_jobs', 'approvals', 'calendar_entries', 'influencer_outreach', 'influencers', 'social_accounts', 'media_assets', 'content_versions', 'content_items', 'campaigns', 'messages', 'conversations', 'agent_tasks', 'ai_agents', 'businesses', 'auth_tokens'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
