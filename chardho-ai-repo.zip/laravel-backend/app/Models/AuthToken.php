<?php

namespace App\Models;


class AuthToken extends BaseModel
{
    protected $table = 'auth_tokens';

    protected $casts = [
        'expires_at' => 'datetime',
        'used_at' => 'datetime',
    ];
}
