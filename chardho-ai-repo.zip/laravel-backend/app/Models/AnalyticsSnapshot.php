<?php

namespace App\Models;


class AnalyticsSnapshot extends BaseModel
{
    protected $table = 'analytics_snapshots';

    protected $casts = [
        'captured_at' => 'datetime',
    ];
}
