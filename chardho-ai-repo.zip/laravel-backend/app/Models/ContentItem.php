<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class ContentItem extends BaseModel
{
    use SoftDeletes;
    protected $table = 'content_items';

    protected $casts = [
    ];

    public function versions()
    {
        return $this->hasMany(ContentVersion::class, 'content_id');
    }

    public function approvals()
    {
        return $this->hasMany(Approval::class, 'content_id');
    }

    public function jobs()
    {
        return $this->hasMany(PublishingJob::class, 'content_id');
    }

    public function business()
    {
        return $this->belongsTo(Business::class, 'business_id');
    }
}
