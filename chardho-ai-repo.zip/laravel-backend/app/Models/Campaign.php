<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Campaign extends BaseModel
{
    use SoftDeletes;
    protected $table = 'campaigns';

    protected $casts = [
        'report' => 'array',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
    ];

    public function content()
    {
        return $this->hasMany(ContentItem::class, 'campaign_id');
    }

    public function outreach()
    {
        return $this->hasMany(InfluencerOutreach::class, 'campaign_id');
    }
}
