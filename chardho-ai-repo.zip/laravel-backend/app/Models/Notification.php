<?php

namespace App\Models;


class Notification extends BaseModel
{
    protected $table = 'chardho_notifications';

    protected $casts = [
        'read_at' => 'datetime',
    ];
}
