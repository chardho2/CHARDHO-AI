<?php

namespace App\Models;


class ApiProviderCost extends BaseModel
{
    protected $table = 'api_provider_costs';

    protected $casts = [
        'cost_usd' => 'float',
    ];
}
