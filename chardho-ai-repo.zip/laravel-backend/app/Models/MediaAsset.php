<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class MediaAsset extends BaseModel
{
    use SoftDeletes;
    protected $table = 'media_assets';

    protected $casts = [
    ];
}
