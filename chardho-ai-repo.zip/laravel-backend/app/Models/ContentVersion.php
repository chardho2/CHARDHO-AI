<?php

namespace App\Models;


class ContentVersion extends BaseModel
{
    protected $table = 'content_versions';

    protected $casts = [
        'hashtags' => 'array',
        'media_asset_ids' => 'array',
    ];
}
