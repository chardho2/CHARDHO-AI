<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUlids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * Base: ULID keys + camelCase JSON so the React frontend (written for the Node API) works unchanged.
 */
abstract class BaseModel extends Model
{
    use HasUlids;

    public static $snakeAttributes = false;
    protected $guarded = [];

    public function attributesToArray(): array
    {
        $out = [];
        foreach (parent::attributesToArray() as $k => $v) {
            $out[Str::camel($k)] = $v;
        }
        return $out;
    }
}
