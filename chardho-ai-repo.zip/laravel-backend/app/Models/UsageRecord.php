<?php

namespace App\Models;


class UsageRecord extends BaseModel
{
    protected $table = 'usage_records';

    protected $casts = [
    ];
}
