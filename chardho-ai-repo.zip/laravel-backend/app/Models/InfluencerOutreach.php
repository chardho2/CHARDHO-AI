<?php

namespace App\Models;


class InfluencerOutreach extends BaseModel
{
    protected $table = 'influencer_outreach';

    protected $casts = [
        'deliverables' => 'array',
    ];

    public function influencer()
    {
        return $this->belongsTo(Influencer::class, 'influencer_id');
    }
}
