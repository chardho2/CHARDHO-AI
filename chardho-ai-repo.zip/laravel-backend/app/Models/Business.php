<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Business extends BaseModel
{
    use SoftDeletes;
    protected $table = 'businesses';

    protected $casts = [
        'competitors' => 'array',
        'social_links' => 'array',
        'languages' => 'array',
        'intelligence' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
