<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Influencer extends BaseModel
{
    use SoftDeletes;
    protected $table = 'influencers';

    protected $casts = [
        'metrics_verified_at' => 'datetime',
    ];
}
