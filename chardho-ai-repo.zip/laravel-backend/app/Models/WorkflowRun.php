<?php

namespace App\Models;


class WorkflowRun extends BaseModel
{
    protected $table = 'workflow_runs';

    protected $casts = [
        'trigger_data' => 'array',
        'logs' => 'array',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];

    public function workflow()
    {
        return $this->belongsTo(AutomationWorkflow::class, 'workflow_id');
    }
}
