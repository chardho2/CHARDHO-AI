<?php

namespace App\Models;


class PublishingJob extends BaseModel
{
    protected $table = 'publishing_jobs';

    protected $casts = [
        'run_at' => 'datetime',
        'api_response' => 'array',
    ];

    public function account()
    {
        return $this->belongsTo(SocialAccount::class, 'social_account_id');
    }

    public function approval()
    {
        return $this->belongsTo(Approval::class, 'approval_id');
    }

    public function content()
    {
        return $this->belongsTo(ContentItem::class, 'content_id');
    }
}
