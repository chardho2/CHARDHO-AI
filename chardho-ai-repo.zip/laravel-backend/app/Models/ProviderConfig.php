<?php

namespace App\Models;


class ProviderConfig extends BaseModel
{
    protected $table = 'provider_configs';
    protected $hidden = ['api_key_enc'];

    protected $casts = [
        'capabilities' => 'array',
        'enabled' => 'boolean',
        'paid' => 'boolean',
    ];
}
