<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Lead extends BaseModel
{
    use SoftDeletes;
    protected $table = 'leads';

    protected $casts = [
        'activity' => 'array',
    ];
}
