<?php

namespace App\Models;


class EmailCampaign extends BaseModel
{
    protected $table = 'email_campaigns';

    protected $casts = [
    ];
}
