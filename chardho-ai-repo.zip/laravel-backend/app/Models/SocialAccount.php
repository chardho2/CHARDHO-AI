<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class SocialAccount extends BaseModel
{
    use SoftDeletes;
    protected $table = 'social_accounts';
    protected $hidden = ['access_token_enc', 'refresh_token_enc'];

    protected $casts = [
        'scopes' => 'array',
        'expires_at' => 'datetime',
    ];
}
