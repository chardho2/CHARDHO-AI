<?php

namespace App\Models;


class Integration extends BaseModel
{
    protected $table = 'integrations';
    protected $hidden = ['config_enc'];

    protected $casts = [
        'enabled' => 'boolean',
    ];
}
