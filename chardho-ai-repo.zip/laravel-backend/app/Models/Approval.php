<?php

namespace App\Models;


class Approval extends BaseModel
{
    protected $table = 'approvals';

    protected $casts = [
        'approved_at' => 'datetime',
        'scheduled_for' => 'datetime',
        'invalidated_at' => 'datetime',
    ];
}
