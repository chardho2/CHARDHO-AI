<?php

namespace App\Models;


class AgentTask extends BaseModel
{
    protected $table = 'agent_tasks';

    protected $casts = [
        'input' => 'array',
        'output' => 'array',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];

    public function children()
    {
        return $this->hasMany(AgentTask::class, 'parent_id');
    }
}
