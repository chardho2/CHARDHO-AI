<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class AutomationWorkflow extends BaseModel
{
    use SoftDeletes;
    protected $table = 'automation_workflows';

    protected $casts = [
        'graph' => 'array',
        'enabled' => 'boolean',
        'paused' => 'boolean',
        'last_run_at' => 'datetime',
    ];

    public function runs()
    {
        return $this->hasMany(WorkflowRun::class, 'workflow_id');
    }
}
