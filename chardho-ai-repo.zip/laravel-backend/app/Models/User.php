<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    public const RANK = ['USER' => 0, 'ADMIN' => 1, 'SUPER_ADMIN' => 2, 'OWNER' => 3];

    protected $guarded = [];
    protected $hidden = ['password', 'remember_token', 'google_id'];
    protected $casts = ['email_verified_at' => 'datetime', 'disabled_at' => 'datetime', 'password' => 'hashed'];

    public function rank(): int
    {
        return self::RANK[$this->role] ?? 0;
    }

    /** Shape the React frontend expects. */
    public function toPublic(): array
    {
        return ['id' => (string) $this->id, 'email' => $this->email, 'name' => $this->name, 'role' => $this->role, 'emailVerified' => (bool) $this->email_verified_at];
    }
}
