<?php

namespace App\Models;


class SupportTicket extends BaseModel
{
    protected $table = 'support_tickets';

    protected $casts = [
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
