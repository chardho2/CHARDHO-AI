<?php

namespace App\Models;


class Conversation extends BaseModel
{
    protected $table = 'conversations';

    protected $casts = [
    ];

    public function messages()
    {
        return $this->hasMany(Message::class, 'conversation_id');
    }
}
