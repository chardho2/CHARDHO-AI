<?php

namespace App\Models;


class Announcement extends BaseModel
{
    protected $table = 'announcements';

    protected $casts = [
        'active' => 'boolean',
    ];
}
