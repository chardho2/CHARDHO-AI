<?php

namespace App\Models;


class AiAgent extends BaseModel
{
    protected $table = 'ai_agents';

    protected $casts = [
        'tools' => 'array',
        'enabled' => 'boolean',
    ];
}
