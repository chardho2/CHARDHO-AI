<?php

namespace App\Models;


class CalendarEntry extends BaseModel
{
    protected $table = 'calendar_entries';

    protected $casts = [
        'date' => 'datetime',
    ];

    public function content()
    {
        return $this->belongsTo(ContentItem::class, 'content_id');
    }
}
