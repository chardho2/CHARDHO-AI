<?php

namespace App\Http\Controllers;

use App\Models\AutomationWorkflow;
use App\Models\WorkflowRun;
use App\Services\Support;
use App\Services\WorkflowEngine;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

class AutomationController extends Controller
{
    private function graph(array $g): array
    {
        try { return WorkflowEngine::validateGraph($g); }
        catch (\InvalidArgumentException $e) { throw new HttpException(422, $e->getMessage()); }
    }

    private function wf(Request $r, string $id): AutomationWorkflow
    {
        return AutomationWorkflow::where('user_id', $this->uid($r))->findOrFail($id);
    }

    /** Public, but only accepts requests signed with the shared secret over the raw body. */
    public function n8n(Request $r, WorkflowEngine $engine)
    {
        $secret = config('chardho.n8n.secret');
        if (!$secret) throw new HttpException(501, 'n8n not configured');
        $sig = (string) $r->header('X-Chardho-Signature', '');
        $expected = hash_hmac('sha256', $r->getContent(), $secret);
        if ($sig === '' || !hash_equals($expected, strtolower(preg_replace('/^sha256=/', '', $sig)))) throw new HttpException(401, 'Bad signature');
        $b = $r->validate(['userId' => 'required', 'businessId' => 'required|string', 'trigger' => 'required|in:' . implode(',', WorkflowEngine::TRIGGERS), 'data' => 'nullable|array']);
        Support::ownBusiness((int) $b['userId'], $b['businessId']);
        $runs = $engine->fire((int) $b['userId'], $b['businessId'], $b['trigger'], $b['data'] ?? []);
        return ['runs' => array_map(fn ($x) => $x->id, $runs)];
    }

    public function meta()
    {
        return ['triggers' => WorkflowEngine::TRIGGERS, 'templates' => WorkflowEngine::TEMPLATES];
    }

    public function index(Request $r)
    {
        $b = $this->biz($r);
        return AutomationWorkflow::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'name' => 'required|string|max:150', 'trigger' => 'required|in:' . implode(',', WorkflowEngine::TRIGGERS), 'graph' => 'required|array']);
        $b = $this->biz($r, $d['businessId']);
        return response()->json(AutomationWorkflow::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'name' => $d['name'], 'trigger' => $d['trigger'], 'graph' => $this->graph($d['graph'])]), 201);
    }

    public function fromTemplate(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'index' => 'required|integer|min:0']);
        $b = $this->biz($r, $d['businessId']);
        $t = WorkflowEngine::TEMPLATES[$d['index']] ?? throw new HttpException(404, 'Template not found');
        return response()->json(AutomationWorkflow::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'name' => $t['name'], 'trigger' => $t['trigger'], 'graph' => $t['graph']]), 201);
    }

    public function update(Request $r, string $id)
    {
        $d = $r->validate(['name' => 'sometimes|string|max:150', 'enabled' => 'sometimes|boolean', 'paused' => 'sometimes|boolean', 'graph' => 'sometimes|array']);
        $w = $this->wf($r, $id);
        if (isset($d['graph'])) $d['graph'] = $this->graph($d['graph']);
        $w->update($d);
        return $w->fresh();
    }

    public function destroy(Request $r, string $id)
    {
        $w = $this->wf($r, $id);
        $w->update(['enabled' => false]);
        $w->delete();
        return response()->noContent();
    }

    public function run(Request $r, string $id)
    {
        $w = $this->wf($r, $id);
        return response()->json(WorkflowRun::create(['workflow_id' => $w->id, 'user_id' => $this->uid($r), 'trigger_data' => $r->input('data', []), 'logs' => [], 'status' => 'QUEUED']), 202);
    }

    public function runs(Request $r)
    {
        $q = WorkflowRun::where('user_id', $this->uid($r))->with('workflow:id,name')->latest()->limit(100);
        if ($w = $r->query('workflowId')) $q->where('workflow_id', $w);
        return $q->get();
    }

    public function resume(Request $r, string $id)
    {
        $run = WorkflowRun::where('user_id', $this->uid($r))->with('workflow')->findOrFail($id);
        if ($run->status !== 'PAUSED') throw new HttpException(409, 'Run is not paused');
        if ($run->workflow->paused) throw new HttpException(409, 'Workflow is paused; resume the workflow first');
        $run->update(['status' => 'QUEUED']);
        return $run->fresh();
    }

    public function retry(Request $r, string $id)
    {
        $run = WorkflowRun::where('user_id', $this->uid($r))->findOrFail($id);
        if ($run->status !== 'FAILED') throw new HttpException(409, 'Only failed runs can be retried');
        $run->update(['status' => 'QUEUED', 'error' => null, 'attempts' => $run->attempts + 1]);
        return $run->fresh();
    }
}
