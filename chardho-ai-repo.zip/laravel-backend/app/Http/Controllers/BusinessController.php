<?php

namespace App\Http\Controllers;

use App\Models\Business;
use Illuminate\Http\Request;

class BusinessController extends Controller
{
    private function rules(bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';
        return [
            'name' => "$req|string|min:1|max:150", 'website' => 'nullable|url|max:255', 'industry' => 'nullable|string|max:100',
            'description' => 'nullable|string|max:4000', 'productsServices' => 'nullable|string|max:4000', 'location' => 'nullable|string|max:200',
            'targetAudience' => 'nullable|string|max:2000', 'objectives' => 'nullable|string|max:2000',
            'competitors' => 'nullable|array|max:20', 'competitors.*' => 'string|max:200',
            'socialLinks' => 'nullable|array', 'socialLinks.*' => 'url', 'languages' => 'nullable|array|max:10', 'languages.*' => 'string|max:30',
        ];
    }

    public function index(Request $r)
    {
        return Business::where('user_id', $this->uid($r))->latest()->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate($this->rules());
        $d['website'] = $d['website'] ?? null;
        return response()->json(Business::create($this->snake($d) + ['user_id' => $this->uid($r), 'competitors' => $d['competitors'] ?? [], 'languages' => $d['languages'] ?? ['en']]), 201);
    }

    public function show(Request $r, string $id)
    {
        return $this->biz($r, $id);
    }

    public function update(Request $r, string $id)
    {
        $b = $this->biz($r, $id);
        $b->update($this->snake($r->validate($this->rules(true))));
        return $b->fresh();
    }

    public function destroy(Request $r, string $id)
    {
        $this->biz($r, $id)->delete();
        return response()->noContent();
    }
}
