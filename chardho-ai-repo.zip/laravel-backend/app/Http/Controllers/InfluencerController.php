<?php

namespace App\Http\Controllers;

use App\Models\Influencer;
use App\Models\InfluencerOutreach;
use App\Services\ProviderManager;
use App\Services\Support;
use App\Support\Logic;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

class InfluencerController extends Controller
{
    private function mine(Request $r, string $id): Influencer
    {
        return Influencer::where('user_id', $this->uid($r))->findOrFail($id);
    }

    /** Search only returns influencers the user recorded with a stated source. Nothing is invented. */
    public function index(Request $r)
    {
        $b = $this->biz($r);
        $q = Influencer::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->limit(200);
        foreach (['niche', 'country', 'audience'] as $f) if ($v = $r->query($f)) $q->where($f, 'like', "%$v%");
        if ($v = $r->query('platform')) $q->where('platform', strtoupper($v));
        return ['results' => $q->get(), 'note' => 'Results are limited to influencers you have added with a stated data source. CHARDHO AI does not fabricate influencer identities or metrics.'];
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'name' => 'required|string|max:200', 'platform' => 'required|in:' . implode(',', Logic::PLATFORMS), 'handle' => 'required|string|max:100',
            'profileUrl' => 'nullable|url', 'niche' => 'nullable|string|max:100', 'country' => 'nullable|string|max:100', 'audience' => 'nullable|string|max:200',
            'followers' => 'nullable|integer|min:0', 'engagement' => 'nullable|numeric|min:0|max:100', 'metricsSource' => 'nullable|string|max:300', 'contactEmail' => 'nullable|email', 'notes' => 'nullable|string|max:4000']);
        if ((isset($d['followers']) || isset($d['engagement'])) && empty($d['metricsSource'])) {
            return response()->json(['error' => 'Validation failed', 'details' => ['metricsSource' => ['metricsSource is required when recording follower/engagement numbers (no unverified metrics)']]], 422);
        }
        $b = $this->biz($r, $d['businessId']);
        if (Influencer::withTrashed()->where('business_id', $b->id)->where('platform', $d['platform'])->where('handle', $d['handle'])->exists()) {
            throw new HttpException(409, 'Influencer already recorded for this platform/handle');
        }
        return response()->json(Influencer::create($this->snake($d) + ['user_id' => $this->uid($r), 'metrics_verified_at' => !empty($d['metricsSource']) ? now() : null]), 201);
    }

    public function destroy(Request $r, string $id)
    {
        $this->mine($r, $id)->delete();
        return response()->noContent();
    }

    private function ai(Request $r, ProviderManager $pm, string $system, array $payload): array
    {
        Support::assertFairUse($this->uid($r));
        $res = $pm->generate($system, json_encode($payload), true, ['text', 'json']);
        Support::recordUsage($this->uid($r), 'ai_request', 'influencer_manager', $res['provider'], $res['model'], $res['tokensIn'], $res['tokensOut']);
        return Logic::parseJsonLoose($res['text']);
    }

    public function analyze(Request $r, string $id, ProviderManager $pm)
    {
        $i = $this->mine($r, $id);
        $b = \App\Models\Business::findOrFail($i->business_id);
        return $this->ai($r, $pm, 'You assess influencer-brand fit using ONLY the data provided. If data is missing, say so. Return JSON {"fitScore":number 0-100,"reasons":string[],"risks":string[],"missingData":string[]}.',
            ['brand' => ['name' => $b->name, 'audience' => $b->target_audience, 'industry' => $b->industry], 'influencer' => ['niche' => $i->niche, 'country' => $i->country, 'audience' => $i->audience, 'followers' => $i->followers, 'engagement' => $i->engagement, 'metricsSource' => $i->metrics_source]]);
    }

    public function outreach(Request $r, string $id, ProviderManager $pm)
    {
        $d = $r->validate(['campaignId' => 'nullable|string', 'kind' => 'nullable|in:proposal,email']);
        $i = $this->mine($r, $id);
        $b = \App\Models\Business::findOrFail($i->business_id);
        $o = $this->ai($r, $pm, 'Write a concise, honest collaboration ' . ($d['kind'] ?? 'email') . '. Do not invent facts, rates or past work. Return JSON {"subject":string,"message":string}.',
            ['brand' => ['name' => $b->name, 'description' => $b->description], 'influencer' => ['name' => $i->name, 'platform' => $i->platform, 'niche' => $i->niche]]);
        return response()->json(InfluencerOutreach::create(['user_id' => $this->uid($r), 'influencer_id' => $i->id, 'campaign_id' => $d['campaignId'] ?? null, 'subject' => $o['subject'] ?? null, 'message' => $o['message'] ?? '']), 201);
    }

    public function updateOutreach(Request $r, string $id)
    {
        $d = $r->validate(['status' => 'sometimes|in:draft,sent,replied,accepted,declined,completed', 'response' => 'nullable|string|max:4000', 'deliverables' => 'nullable|array',
            'deliverables.*.title' => 'required|string', 'deliverables.*.dueDate' => 'nullable|string', 'deliverables.*.done' => 'boolean', 'message' => 'nullable|string|max:8000']);
        $o = InfluencerOutreach::where('user_id', $this->uid($r))->findOrFail($id);
        $o->update($d);
        return $o->fresh();
    }

    public function outreachList(Request $r)
    {
        return InfluencerOutreach::where('user_id', $this->uid($r))->with('influencer:id,name,platform,handle')->latest()->limit(200)->get();
    }
}
