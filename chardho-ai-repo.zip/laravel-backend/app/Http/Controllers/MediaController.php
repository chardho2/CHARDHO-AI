<?php

namespace App\Http\Controllers;

use App\Models\MediaAsset;
use App\Models\ProviderConfig;
use App\Models\ApiProviderCost;
use App\Services\Orchestrator;
use App\Services\Support;
use App\Support\Logic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\HttpException;

class MediaController extends Controller
{
    private function store(int $userId, string $businessId, string $bytes, string $kind, ?string $prompt = null, ?string $aspect = null): MediaAsset
    {
        $t = Logic::sniffImage($bytes) ?? throw new HttpException(415, 'Unsupported file type. Allowed: PNG, JPEG, WEBP, GIF');
        $file = Str::uuid() . '.' . $t['ext'];
        Storage::disk('local')->put("media/$file", $bytes);
        return MediaAsset::create(['user_id' => $userId, 'business_id' => $businessId, 'kind' => $kind, 'mime_type' => $t['mime'], 'path' => $file, 'size_bytes' => strlen($bytes), 'prompt' => $prompt, 'aspect' => $aspect]);
    }

    /** Public: Instagram/Facebook must be able to fetch the image. IDs are unguessable ULIDs; only images are stored. */
    public function show(string $id)
    {
        $a = MediaAsset::findOrFail($id);
        return response(Storage::disk('local')->get('media/' . basename($a->path)), 200, [
            'Content-Type' => $a->mime_type, 'X-Content-Type-Options' => 'nosniff', 'Content-Security-Policy' => "default-src 'none'", 'Cache-Control' => 'public, max-age=3600',
        ]);
    }

    public function index(Request $r)
    {
        $b = $this->biz($r);
        return MediaAsset::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->limit(100)->get();
    }

    public function upload(Request $r)
    {
        $r->validate(['businessId' => 'required|string', 'file' => 'required|file|max:5120']);
        $b = $this->biz($r, $r->input('businessId'));
        return response()->json($this->store($this->uid($r), $b->id, file_get_contents($r->file('file')->getRealPath()), 'upload'), 201);
    }

    public function destroy(Request $r, string $id)
    {
        $a = MediaAsset::where('user_id', $this->uid($r))->findOrFail($id);
        Storage::disk('local')->delete('media/' . basename($a->path));
        $a->delete();
        return response()->noContent();
    }

    public function generate(Request $r, Orchestrator $orch)
    {
        $d = $r->validate(['businessId' => 'required|string', 'prompt' => 'required|string|min:3|max:1500', 'aspect' => 'nullable|in:1:1,4:5,9:16,16:9']);
        $aspect = $d['aspect'] ?? '1:1';
        $b = $this->biz($r, $d['businessId']);
        Support::assertFairUse($this->uid($r));
        $cfg = ProviderConfig::where('key', 'openai')->first();
        $key = $cfg?->api_key_enc ? Crypt::decryptString($cfg->api_key_enc) : config('chardho.providers.openai.api_key');
        // Image generation needs a paid provider: only with explicit owner authorisation.
        if (!(config('chardho.allow_paid') && $cfg?->enabled && $key && in_array('image', $cfg->capabilities ?? []))) {
            $task = $orch->runAgent($this->uid($r), $b, 'image_agent', ['request' => "Write an image-generation prompt and platform variants for: {$d['prompt']} (aspect $aspect)"]);
            return ['status' => 'provider_unavailable', 'message' => 'No image-generation provider is enabled by the platform owner. A creative brief was generated instead.', 'task' => $task];
        }
        $size = ['1:1' => '1024x1024', '4:5' => '1024x1024', '9:16' => '1024x1792', '16:9' => '1792x1024'][$aspect];
        $res = Http::timeout(120)->withToken($key)->post(($cfg->base_url ?: 'https://api.openai.com/v1') . '/images/generations', ['model' => 'dall-e-3', 'prompt' => $d['prompt'], 'size' => $size, 'response_format' => 'b64_json', 'n' => 1]);
        if (!$res->ok()) throw new HttpException(502, 'Image provider error ' . $res->status());
        $asset = $this->store($this->uid($r), $b->id, base64_decode($res->json('data.0.b64_json')), 'generated', $d['prompt'], $aspect);
        Support::recordUsage($this->uid($r), 'ai_request', 'image_agent', 'openai', 'dall-e-3');
        ApiProviderCost::create(['provider' => 'openai', 'model' => 'dall-e-3', 'tokens_in' => 0, 'tokens_out' => 0, 'cost_usd' => 0.04]);
        return response()->json(['status' => 'ok', 'asset' => $asset], 201);
    }
}
