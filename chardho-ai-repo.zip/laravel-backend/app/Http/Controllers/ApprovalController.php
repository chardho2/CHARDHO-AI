<?php

namespace App\Http\Controllers;

use App\Models\ContentItem;
use App\Services\ApprovalService;
use App\Services\ContentService;
use Illuminate\Http\Request;

class ApprovalController extends Controller
{
    public function __construct(private ApprovalService $svc) {}

    /** Approval center. */
    public function index(Request $r)
    {
        $b = $this->biz($r);
        return ContentItem::where('user_id', $this->uid($r))->where('business_id', $b->id)->whereNotNull('platform')
            ->whereIn('status', ['QUALITY_CHECKED', 'PENDING_APPROVAL', 'APPROVED', 'SCHEDULED', 'PUBLISHING', 'PUBLISHED', 'FAILED'])
            ->with(['versions', 'approvals', 'jobs'])->latest('updated_at')->get()
            ->map(function ($c) {
                ContentService::latestOnly($c);
                $c->setRelation('approvals', $c->approvals->sortByDesc('approved_at')->take(1)->values());
                $c->setRelation('jobs', $c->jobs->sortByDesc('created_at')->take(1)->values());
                return $c;
            });
    }

    public function submit(Request $r, string $id) { return $this->svc->submit($this->uid($r), $id); }

    public function approve(Request $r, string $id)
    {
        $d = $r->validate(['socialAccountId' => 'required|string', 'scheduledFor' => 'nullable|date']);
        return $this->svc->approve($this->uid($r), $id, $d['socialAccountId'], !empty($d['scheduledFor']) ? new \DateTimeImmutable($d['scheduledFor']) : null);
    }

    public function schedule(Request $r, string $id)
    {
        $d = $r->validate(['runAt' => 'nullable|date']);
        return $this->svc->schedule($this->uid($r), $id, !empty($d['runAt']) ? new \DateTimeImmutable($d['runAt']) : null);
    }

    public function cancel(Request $r, string $id)
    {
        $this->svc->cancel($this->uid($r), $id);
        return ['ok' => true];
    }
}
