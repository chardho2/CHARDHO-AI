<?php

namespace App\Http\Controllers;

use App\Models\AgentTask;
use App\Models\UsageRecord;
use App\Services\Orchestrator;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MarketingController extends Controller
{
    public function intelligence(Request $r, Orchestrator $o)
    {
        $b = $this->biz($r, $r->validate(['businessId' => 'required|string'])['businessId']);
        $t = $o->runAgent($this->uid($r), $b, 'marketing_manager', ['request' => 'Create a business intelligence report and suggest prioritised marketing opportunities.']);
        return response()->json($t, $t->status === 'SUCCEEDED' ? 200 : 502);
    }

    public function showIntelligence(Request $r, string $businessId)
    {
        return response()->json($this->biz($r, $businessId)->intelligence);
    }

    public function seo(Request $r, Orchestrator $o)
    {
        $d = $r->validate(['businessId' => 'required|string', 'topic' => 'required|string|min:2|max:300']);
        $t = $o->runAgent($this->uid($r), $this->biz($r, $d['businessId']), 'seo_specialist', ['request' => "SEO keyword ideas, on-page recommendations and a draft SEO article for: {$d['topic']}"]);
        return response()->json($t, $t->status === 'SUCCEEDED' ? 200 : 502);
    }

    public function usage(Request $r)
    {
        $by = UsageRecord::where('user_id', $this->uid($r))->select('agent_key', DB::raw('count(*) as c'), DB::raw('sum(tokens_in) as ti'), DB::raw('sum(tokens_out) as `to`'))->groupBy('agent_key')->get()
            ->map(fn ($x) => ['agentKey' => $x->agent_key, '_count' => (int) $x->c, '_sum' => ['tokensIn' => (int) $x->ti, 'tokensOut' => (int) $x->to]]);
        return ['today' => Support::usageToday($this->uid($r)), 'byAgent' => $by, 'note' => 'Free access is subject to fair-use limits and provider capacity; generation is not unlimited.'];
    }
}
