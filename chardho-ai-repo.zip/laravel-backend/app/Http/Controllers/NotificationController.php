<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index(Request $r)
    {
        $items = Notification::where('user_id', $this->uid($r))->latest()->limit(50)->get();
        return ['items' => $items, 'unread' => $items->filter(fn ($i) => $i->read_at === null)->count(),
            'announcements' => Announcement::where('active', true)->latest()->limit(5)->get()];
    }

    public function read(Request $r)
    {
        Notification::where('user_id', $this->uid($r))->whereNull('read_at')->update(['read_at' => now()]);
        return ['ok' => true];
    }
}
