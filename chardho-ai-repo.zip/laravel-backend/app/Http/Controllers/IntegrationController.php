<?php

namespace App\Http\Controllers;

use App\Models\ProviderConfig;
use Illuminate\Http\Request;

/** Honest status: configured / not_configured / demo. Never claims a connection that does not exist. */
class IntegrationController extends Controller
{
    public function index(Request $r)
    {
        $has = fn (...$k) => collect($k)->every(fn ($x) => !empty(env($x)));
        $paidOk = (bool) config('chardho.allow_paid');
        $ai = ProviderConfig::orderBy('priority')->get(['key', 'name', 'enabled', 'paid', 'model'])->map(fn ($p) => [
            'key' => $p->key, 'name' => $p->name, 'enabled' => (bool) $p->enabled, 'paid' => (bool) $p->paid, 'model' => $p->model,
            'status' => $p->enabled ? ($p->paid && !$paidOk ? 'blocked_paid' : 'enabled') : 'disabled',
        ]);
        $social = [
            'X' => ['X_CLIENT_ID', 'X_CLIENT_SECRET'], 'LINKEDIN' => ['LINKEDIN_CLIENT_ID', 'LINKEDIN_CLIENT_SECRET'],
            'FACEBOOK' => ['META_APP_ID', 'META_APP_SECRET'], 'INSTAGRAM' => ['META_APP_ID', 'META_APP_SECRET'],
            'YOUTUBE' => ['YOUTUBE_CLIENT_ID', 'YOUTUBE_CLIENT_SECRET'],
        ];
        return [
            'ai' => $ai,
            'social' => collect($social)->map(fn ($k, $p) => ['platform' => $p, 'status' => $has(...$k) ? 'configured' : 'not_configured'])->values(),
            'googleLogin' => $has('GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET') ? 'configured' : 'not_configured',
            'n8n' => $has('N8N_WEBHOOK_URL', 'N8N_SHARED_SECRET') ? 'configured' : 'not_configured',
            'email' => env('MAIL_MAILER', 'log') === 'log' ? 'demo (emails are written to the Laravel log)' : 'configured',
            'imageGeneration' => 'requires owner-enabled paid provider; otherwise creative briefs only',
        ];
    }
}
