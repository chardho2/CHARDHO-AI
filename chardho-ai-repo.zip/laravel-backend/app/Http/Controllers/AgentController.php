<?php

namespace App\Http\Controllers;

use App\Models\AgentTask;
use App\Models\AiAgent;
use App\Models\Conversation;
use App\Models\Message;
use App\Services\AgentRegistry;
use App\Services\Orchestrator;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AgentController extends Controller
{
    public function __construct(private Orchestrator $orch) {}

    public function index()
    {
        $en = AiAgent::pluck('enabled', 'key');
        return collect(AgentRegistry::all())->map(fn ($a) => ['key' => $a['key'], 'name' => $a['name'], 'description' => $a['description'], 'tools' => $a['tools'], 'enabled' => (bool) ($en[$a['key']] ?? true)])->values();
    }

    public function execute(Request $r)
    {
        $d = $r->validate([
            'businessId' => 'required|string', 'request' => 'required|string|min:3|max:4000', 'agent' => 'nullable|string', 'agents' => 'nullable|array|max:4',
            'language' => 'nullable|string|max:30', 'tone' => 'nullable|string|max:60', 'audience' => 'nullable|string|max:200', 'length' => 'nullable|in:short,medium,long',
        ]);
        $b = $this->biz($r, $d['businessId']);
        $input = array_filter(['request' => $d['request'], 'language' => $d['language'] ?? null, 'tone' => $d['tone'] ?? null, 'audience' => $d['audience'] ?? null, 'length' => $d['length'] ?? null]);
        if (!empty($d['agent'])) {
            $t = $this->orch->runAgent($this->uid($r), $b, $d['agent'], $input);
            return response()->json(['agents' => [$d['agent']], 'tasks' => [$t]], $t->status === 'SUCCEEDED' ? 200 : 502);
        }
        return $this->orch->orchestrate($this->uid($r), $b, $input, $d['agents'] ?? null);
    }

    public function tasks(Request $r)
    {
        $q = AgentTask::where('user_id', $this->uid($r))->latest()->limit(100);
        if ($r->query('businessId')) $q->where('business_id', $r->query('businessId'));
        return $q->get();
    }

    public function task(Request $r, string $id)
    {
        return AgentTask::where('user_id', $this->uid($r))->with('children')->findOrFail($id);
    }
}
