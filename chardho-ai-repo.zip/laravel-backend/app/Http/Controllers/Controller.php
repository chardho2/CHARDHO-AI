<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

abstract class Controller
{
    protected function uid(Request $r): int
    {
        return (int) $r->user()->id;
    }

    protected function biz(Request $r, ?string $id = null): Business
    {
        return Support::ownBusiness($this->uid($r), $id ?? (string) ($r->input('businessId') ?? $r->query('businessId')));
    }

    /** camelCase request keys -> snake_case column names. */
    protected function snake(array $a): array
    {
        $o = [];
        foreach ($a as $k => $v) { $o[Str::snake($k)] = $v; }
        return $o;
    }
}
