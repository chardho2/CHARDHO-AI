<?php

namespace App\Http\Controllers;

use App\Models\AgentTask;
use App\Models\AnalyticsSnapshot;
use App\Models\ContentItem;
use App\Models\Lead;
use App\Models\PublishingJob;
use App\Models\SocialAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;

class AnalyticsController extends Controller
{
    public function summary(Request $r)
    {
        $b = $this->biz($r);
        $u = $this->uid($r);
        $g = fn ($q) => $q->selectRaw('status, count(*) as n')->groupBy('status')->pluck('n', 'status');
        $snaps = AnalyticsSnapshot::where('user_id', $u)->where('business_id', $b->id)->orderByDesc('captured_at')->limit(200)->get();
        return [
            'content' => $g(ContentItem::where('user_id', $u)->where('business_id', $b->id)),
            'publishing' => $g(PublishingJob::whereHas('content', fn ($q) => $q->where('user_id', $u)->where('business_id', $b->id))),
            'leads' => $g(Lead::where('user_id', $u)->where('business_id', $b->id)),
            'agentTasks' => $g(AgentTask::where('user_id', $u)->where('business_id', $b->id)),
            'platformMetrics' => $snaps,
            'note' => $snaps->isEmpty() ? 'No platform analytics collected yet. Connect an account and press "Collect".' : null,
        ];
    }

    /** Account-level follower counts via official APIs. Failures are reported per account, never faked. */
    public function collect(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string']);
        $b = $this->biz($r, $d['businessId']);
        $out = [];
        foreach (SocialAccount::where('user_id', $this->uid($r))->where('business_id', $b->id)->get() as $a) {
            try {
                $t = Crypt::decryptString($a->access_token_enc);
                $get = function (string $url, array $h = []) { $res = Http::timeout(20)->withHeaders($h)->get($url); if (!$res->ok()) throw new \RuntimeException((string) $res->status()); return $res->json(); };
                $auth = ['Authorization' => "Bearer $t"];
                $metric = 'followers';
                $value = match ($a->platform) {
                    'X' => $get('https://api.twitter.com/2/users/me?user.fields=public_metrics', $auth)['data']['public_metrics']['followers_count'] ?? null,
                    'YOUTUBE' => (function () use ($get, $auth, &$metric) { $metric = 'subscribers'; return $get('https://www.googleapis.com/youtube/v3/channels?part=statistics&mine=true', $auth)['items'][0]['statistics']['subscriberCount'] ?? null; })(),
                    'FACEBOOK', 'INSTAGRAM' => $get("https://graph.facebook.com/v19.0/{$a->external_id}?fields=followers_count&access_token=$t")['followers_count'] ?? null,
                    default => throw new \RuntimeException('LinkedIn member analytics are not available via the public API'),
                };
                if ($value === null || !is_numeric($value)) throw new \RuntimeException('metric unavailable');
                AnalyticsSnapshot::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'platform' => $a->platform, 'metric' => $metric, 'value' => (float) $value, 'source' => strtolower($a->platform) . '_api', 'captured_at' => now()]);
                $out[] = ['platform' => $a->platform, 'account' => $a->display_name, 'ok' => true, 'metric' => $metric, 'value' => (float) $value];
            } catch (\Throwable $e) {
                $out[] = ['platform' => $a->platform, 'account' => $a->display_name, 'ok' => false, 'error' => $e->getMessage()];
            }
        }
        return ['results' => $out];
    }
}
