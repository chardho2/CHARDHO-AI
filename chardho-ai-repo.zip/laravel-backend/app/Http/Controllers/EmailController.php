<?php

namespace App\Http\Controllers;

use App\Models\EmailCampaign;
use App\Services\Orchestrator;
use Illuminate\Http\Request;

/** Drafts only; sending is a deliberate human action outside this platform. */
class EmailController extends Controller
{
    public function index(Request $r)
    {
        $b = $this->biz($r);
        return EmailCampaign::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'name' => 'required|string|max:200', 'subject' => 'required|string|max:300', 'body' => 'required|string|max:50000']);
        $this->biz($r, $d['businessId']);
        return response()->json(EmailCampaign::create($this->snake($d) + ['user_id' => $this->uid($r)]), 201);
    }

    public function generate(Request $r, Orchestrator $orch)
    {
        $d = $r->validate(['businessId' => 'required|string', 'brief' => 'required|string|min:3|max:3000']);
        $b = $this->biz($r, $d['businessId']);
        $task = $orch->runAgent($this->uid($r), $b, 'email_marketing', ['request' => $d['brief'], 'priorOutputs' => []]);
        return response()->json($task, $task->status === 'SUCCEEDED' ? 200 : 502);
    }

    public function destroy(Request $r, string $id)
    {
        EmailCampaign::where('user_id', $this->uid($r))->findOrFail($id)->delete();
        return response()->noContent();
    }
}
