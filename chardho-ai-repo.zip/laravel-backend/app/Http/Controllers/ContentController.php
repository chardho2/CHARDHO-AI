<?php

namespace App\Http\Controllers;

use App\Models\ContentItem;
use App\Models\MediaAsset;
use App\Services\ContentService;
use App\Services\Orchestrator;
use App\Support\Logic;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ContentController extends Controller
{
    private const TYPE_AGENT = ['reel_script' => 'video_agent', 'youtube_script' => 'video_agent', 'blog' => 'content_writer', 'seo_article' => 'seo_specialist', 'ad_copy' => 'content_writer', 'product_description' => 'content_writer', 'newsletter' => 'email_marketing', 'whatsapp' => 'content_writer', 'campaign' => 'marketing_manager', 'social_post' => 'social_media_manager'];

    public function __construct(private ContentService $svc, private Orchestrator $orch) {}

    public function index(Request $r)
    {
        $b = $this->biz($r);
        $q = ContentItem::where('user_id', $this->uid($r))->where('business_id', $b->id)->with('versions')->latest('updated_at')->limit(200);
        if ($r->query('status')) $q->where('status', $r->query('status'));
        if ($r->query('type')) $q->where('type', $r->query('type'));
        return $q->get()->map(fn ($c) => ContentService::latestOnly($c));
    }

    public function show(Request $r, string $id)
    {
        return ContentItem::where('user_id', $this->uid($r))->with(['versions' => fn ($q) => $q->orderByDesc('version'), 'approvals', 'jobs'])->findOrFail($id);
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'type' => 'required|string|max:60', 'platform' => ['nullable', Rule::in(Logic::PLATFORMS)], 'title' => 'nullable|string|max:300', 'body' => 'required|string|min:1|max:20000', 'hashtags' => 'array', 'hashtags.*' => 'string', 'language' => 'nullable|string']);
        $b = $this->biz($r, $d['businessId']);
        return response()->json($this->svc->create($this->uid($r), $b->id, $d), 201);
    }

    public function update(Request $r, string $id)
    {
        $d = $r->validate(['body' => 'sometimes|string|min:1|max:20000', 'hashtags' => 'sometimes|array', 'hashtags.*' => 'string', 'title' => 'sometimes|string|max:300', 'mediaAssetIds' => 'sometimes|array|max:10']);
        $c = ContentItem::where('user_id', $this->uid($r))->findOrFail($id);
        if (!empty($d['mediaAssetIds'])) {
            if (MediaAsset::where('user_id', $this->uid($r))->where('business_id', $c->business_id)->whereIn('id', $d['mediaAssetIds'])->count() !== count($d['mediaAssetIds'])) abort(404, 'Media asset not found');
        }
        return $this->svc->edit($c->id, $this->uid($r), $d);
    }

    public function destroy(Request $r, string $id)
    {
        $c = ContentItem::where('user_id', $this->uid($r))->findOrFail($id);
        \App\Models\PublishingJob::where('content_id', $c->id)->where('status', 'PENDING')->update(['status' => 'CANCELLED']);
        $c->update(['status' => $c->status === 'PUBLISHED' ? 'PUBLISHED' : 'CANCELLED']);
        $c->delete();
        return response()->noContent();
    }

    /** Generate (call again with the same prompt to regenerate). */
    public function generate(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'type' => 'nullable|string', 'platform' => ['nullable', Rule::in(Logic::PLATFORMS)], 'prompt' => 'required|string|min:3|max:3000', 'language' => 'nullable|string|max:30', 'tone' => 'nullable|string|max:60', 'audience' => 'nullable|string|max:200', 'length' => 'nullable|in:short,medium,long', 'count' => 'nullable|integer|min:1|max:10']);
        $b = $this->biz($r, $d['businessId']);
        $type = $d['type'] ?? 'social_post';
        $agent = self::TYPE_AGENT[$type] ?? 'content_writer';
        $req = 'Create ' . ($d['count'] ?? 1) . ' ' . str_replace('_', ' ', $type) . ' draft(s)' . (!empty($d['platform']) ? " for {$d['platform']}" : '') . '. ' . $d['prompt'];
        $task = $this->orch->runAgent($this->uid($r), $b, $agent, array_filter(['request' => $req, 'language' => $d['language'] ?? null, 'tone' => $d['tone'] ?? null, 'audience' => $d['audience'] ?? null, 'length' => $d['length'] ?? null]));
        $ids = $task->output['savedContentIds'] ?? [];
        $items = $ids ? ContentItem::where('user_id', $this->uid($r))->whereIn('id', $ids)->with('versions')->get() : [];
        return response()->json(['task' => $task, 'items' => $items], $task->status === 'SUCCEEDED' ? 200 : 502);
    }

    public function batch(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'prompt' => 'required|string|min:3|max:3000', 'platforms' => 'required|array|min:1|max:5', 'platforms.*' => [Rule::in(Logic::PLATFORMS)], 'language' => 'nullable|string', 'tone' => 'nullable|string']);
        $t = $this->orch->runAgent($this->uid($r), $this->biz($r, $d['businessId']), 'social_media_manager', array_filter(['request' => 'Create one platform-native post for EACH of: ' . implode(', ', $d['platforms']) . '. ' . $d['prompt'], 'language' => $d['language'] ?? null, 'tone' => $d['tone'] ?? null]));
        return response()->json($t, $t->status === 'SUCCEEDED' ? 200 : 502);
    }
}
