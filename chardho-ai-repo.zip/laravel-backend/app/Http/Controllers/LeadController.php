<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Services\ProviderManager;
use App\Services\Support;
use App\Support\Logic;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

class LeadController extends Controller
{
    private const STATUSES = 'new,contacted,qualified,won,lost';

    public function index(Request $r)
    {
        $b = $this->biz($r);
        $q = Lead::where('user_id', $this->uid($r))->where('business_id', $b->id)->orderByDesc('score')->limit(500);
        if ($r->query('status')) $q->where('status', $r->query('status'));
        if ($s = $r->query('q')) $q->where(fn ($x) => $x->where('business_name', 'like', "%$s%")->orWhere('contact_name', 'like', "%$s%")->orWhere('email', 'like', "%$s%"));
        return $q->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'source' => 'required|string|max:100', 'businessName' => 'nullable|string|max:200', 'contactName' => 'nullable|string|max:200', 'email' => 'nullable|email', 'phone' => 'nullable|string|max:40',
            'consentBasis' => 'required|string|min:2|max:300', 'industry' => 'nullable|string|max:100', 'status' => 'nullable|in:' . self::STATUSES, 'notes' => 'nullable|string|max:4000']);
        $b = $this->biz($r, $d['businessId']);
        $key = Logic::dedupeKey($d['email'] ?? null, $d['phone'] ?? null, $d['businessName'] ?? null, $d['contactName'] ?? null);
        $dup = Lead::withTrashed()->where('business_id', $b->id)->where('dedupe_key', $key)->first();
        if ($dup && !$dup->trashed()) return response()->json(['error' => 'Duplicate lead', 'details' => ['existingId' => $dup->id]], 409);
        $data = $this->snake($d) + ['user_id' => $this->uid($r), 'dedupe_key' => $key, 'status' => 'new', 'activity' => [['at' => now()->toIso8601String(), 'event' => 'created']]];
        $data['score'] = Logic::scoreLead($d['email'] ?? null, $d['phone'] ?? null, $d['businessName'] ?? null, $d['industry'] ?? null, $data['status']);
        if ($dup) { $dup->restore(); $dup->update($data); return response()->json($dup->fresh(), 201); }
        return response()->json(Lead::create($data), 201);
    }

    public function update(Request $r, string $id)
    {
        $l = Lead::where('user_id', $this->uid($r))->findOrFail($id);
        $d = $r->validate(['source' => 'sometimes|string|max:100', 'businessName' => 'nullable|string|max:200', 'contactName' => 'nullable|string|max:200', 'email' => 'nullable|email', 'phone' => 'nullable|string|max:40',
            'consentBasis' => 'sometimes|string|min:2|max:300', 'industry' => 'nullable|string|max:100', 'status' => 'sometimes|in:' . self::STATUSES, 'notes' => 'nullable|string|max:4000']);
        $activity = $l->activity ?? [];
        if (isset($d['status']) && $d['status'] !== $l->status) $activity[] = ['at' => now()->toIso8601String(), 'event' => "status:{$l->status}->{$d['status']}"];
        if (isset($d['notes']) && $d['notes'] !== $l->notes) $activity[] = ['at' => now()->toIso8601String(), 'event' => 'note_updated'];
        $l->fill($this->snake($d));
        $l->score = Logic::scoreLead($l->email, $l->phone, $l->business_name, $l->industry, $l->status);
        $l->activity = $activity;
        $l->save();
        return $l;
    }

    public function destroy(Request $r, string $id)
    {
        Lead::where('user_id', $this->uid($r))->findOrFail($id)->delete();
        return response()->noContent();
    }

    public function import(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'csv' => 'required|string|max:2000000', 'consentBasis' => 'required|string|min:2|max:300', 'source' => 'nullable|string']);
        $b = $this->biz($r, $d['businessId']);
        $rows = Logic::parseCsv($d['csv']);
        $head = array_shift($rows) ?? throw new HttpException(400, 'Empty CSV');
        $idx = fn (string $n) => array_search($n, array_map(fn ($h) => strtolower(trim($h)), $head), true);
        $col = ['businessName' => $idx('businessname'), 'contactName' => $idx('contactname'), 'email' => $idx('email'), 'phone' => $idx('phone'), 'industry' => $idx('industry')];
        $created = $dups = $invalid = 0;
        foreach (array_slice($rows, 0, 5000) as $row) {
            $g = fn ($k) => $col[$k] !== false ? (trim($row[$col[$k]] ?? '') ?: null) : null;
            [$bn, $cn, $em, $ph, $in] = [$g('businessName'), $g('contactName'), $g('email'), $g('phone'), $g('industry')];
            if (($em && !filter_var($em, FILTER_VALIDATE_EMAIL)) || (!$em && !$ph && !$bn)) { $invalid++; continue; }
            $key = Logic::dedupeKey($em, $ph, $bn, $cn);
            if (Lead::withTrashed()->where('business_id', $b->id)->where('dedupe_key', $key)->exists()) { $dups++; continue; }
            Lead::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'business_name' => $bn, 'contact_name' => $cn, 'email' => $em, 'phone' => $ph, 'industry' => $in, 'source' => $d['source'] ?? 'csv_import', 'consent_basis' => $d['consentBasis'], 'dedupe_key' => $key, 'score' => Logic::scoreLead($em, $ph, $bn, $in), 'activity' => [['at' => now()->toIso8601String(), 'event' => 'imported']]]);
            $created++;
        }
        return ['created' => $created, 'duplicates' => $dups, 'invalid' => $invalid];
    }

    public function export(Request $r)
    {
        $b = $this->biz($r);
        $cols = ['business_name', 'contact_name', 'email', 'phone', 'industry', 'source', 'status', 'score', 'consent_basis', 'notes'];
        $lines = [implode(',', ['businessName', 'contactName', 'email', 'phone', 'industry', 'source', 'status', 'score', 'consentBasis', 'notes'])];
        foreach (Lead::where('user_id', $this->uid($r))->where('business_id', $b->id)->get() as $l) {
            $lines[] = implode(',', array_map(fn ($c) => Logic::csvCell($l->{$c}), $cols));
        }
        return response(implode("\n", $lines), 200, ['Content-Type' => 'text/csv; charset=utf-8', 'Content-Disposition' => 'attachment; filename="leads.csv"']);
    }

    public function outreach(Request $r, string $id, ProviderManager $pm)
    {
        $l = Lead::where('user_id', $this->uid($r))->findOrFail($id);
        $biz = \App\Models\Business::findOrFail($l->business_id);
        if (!$l->consent_basis) throw new HttpException(422, 'Record the consent/lawful basis before generating outreach');
        Support::assertFairUse($this->uid($r));
        $res = $pm->generate('You write a short, honest, one-to-one business outreach email. Include a clear opt-out line. Never fabricate facts about the recipient. Return JSON {"subject":string,"body":string}.',
            json_encode(['sender' => ['name' => $biz->name, 'description' => $biz->description], 'recipient' => ['name' => $l->contact_name, 'company' => $l->business_name, 'industry' => $l->industry], 'basis' => $l->consent_basis]), true, ['text', 'json']);
        Support::recordUsage($this->uid($r), 'ai_request', 'lead_gen', $res['provider'], $res['model'], $res['tokensIn'], $res['tokensOut']);
        return ['draft' => Logic::parseJsonLoose($res['text']), 'note' => 'Draft only. Review and send yourself; CHARDHO AI does not send bulk or unsolicited messages.'];
    }
}
