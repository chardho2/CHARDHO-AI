<?php

namespace App\Http\Controllers;

use App\Models\CalendarEntry;
use App\Models\ContentItem;
use App\Services\Orchestrator;
use App\Support\Logic;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

class CalendarController extends Controller
{
    public function index(Request $r)
    {
        $b = $this->biz($r);
        $q = CalendarEntry::where('user_id', $this->uid($r))->where('business_id', $b->id)->with('content:id,status,title')->orderBy('date')->limit(500);
        if ($f = $r->query('from')) $q->where('date', '>=', $f);
        if ($t = $r->query('to')) $q->where('date', '<=', $t);
        return $q->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'contentId' => 'nullable|string', 'title' => 'required|string|max:200', 'date' => 'required|date', 'platform' => 'nullable|in:' . implode(',', Logic::PLATFORMS), 'note' => 'nullable|string|max:1000']);
        $b = $this->biz($r, $d['businessId']);
        if (!empty($d['contentId'])) ContentItem::where('user_id', $this->uid($r))->findOrFail($d['contentId']);
        return response()->json(CalendarEntry::create($this->snake($d) + ['user_id' => $this->uid($r)]), 201);
    }

    public function destroy(Request $r, string $id)
    {
        CalendarEntry::where('user_id', $this->uid($r))->findOrFail($id)->delete();
        return response()->noContent();
    }

    /** Drafts only. Nothing is scheduled for publishing. */
    public function generate(Request $r, Orchestrator $orch)
    {
        $d = $r->validate(['businessId' => 'required|string', 'days' => 'nullable|integer|min:1|max:30', 'startDate' => 'nullable|date', 'platforms' => 'nullable|array|min:1', 'platforms.*' => 'in:' . implode(',', Logic::PLATFORMS)]);
        $b = $this->biz($r, $d['businessId']);
        $days = $d['days'] ?? 7;
        $plats = $d['platforms'] ?? ['INSTAGRAM'];
        $start = isset($d['startDate']) ? new \DateTimeImmutable($d['startDate']) : new \DateTimeImmutable();
        $task = $orch->runAgent($this->uid($r), $b, 'social_media_manager', ['request' => "Create a $days-day content calendar with one post per day, rotating across " . implode(', ', $plats) . '. Each draft title should be the topic.', 'priorOutputs' => []]);
        if ($task->status !== 'SUCCEEDED') throw new HttpException(502, $task->error ?: 'Generation failed');
        $ids = $task->output['savedContentIds'] ?? [];
        $entries = [];
        foreach (ContentItem::whereIn('id', $ids)->orderBy('created_at')->get() as $i => $c) {
            $entries[] = CalendarEntry::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'content_id' => $c->id, 'title' => $c->title ?: $c->type, 'platform' => $c->platform, 'date' => $start->modify('+' . ($i % $days) . ' days')]);
        }
        return response()->json(['task' => $task, 'entries' => $entries], 201);
    }
}
