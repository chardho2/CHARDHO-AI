<?php

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\Message;
use App\Services\Orchestrator;
use Illuminate\Http\Request;

class ConversationController extends Controller
{
    public function index(Request $r)
    {
        $b = $this->biz($r);
        return Conversation::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->limit(50)->get();
    }

    public function show(Request $r, string $id)
    {
        return Conversation::where('user_id', $this->uid($r))->with(['messages' => fn ($q) => $q->orderBy('created_at')])->findOrFail($id);
    }

    public function message(Request $r, Orchestrator $orch)
    {
        $d = $r->validate(['businessId' => 'required|string', 'conversationId' => 'nullable|string', 'message' => 'required|string|min:1|max:4000']);
        $b = $this->biz($r, $d['businessId']);
        $conv = !empty($d['conversationId'])
            ? Conversation::where('user_id', $this->uid($r))->where('business_id', $b->id)->findOrFail($d['conversationId'])
            : Conversation::create(['user_id' => $this->uid($r), 'business_id' => $b->id, 'title' => mb_substr($d['message'], 0, 60)]);
        Message::create(['conversation_id' => $conv->id, 'role' => 'user', 'content' => $d['message']]);
        ['tasks' => $tasks] = $orch->orchestrate($this->uid($r), $b, ['request' => $d['message']]);
        $ok = collect($tasks)->where('status', 'SUCCEEDED');
        $reply = $ok->isNotEmpty() ? $ok->map(fn ($t) => "**{$t->agent_key}**: " . ($t->output['summary'] ?? ''))->implode("\n\n") : 'I could not complete that: ' . ($tasks[0]->error ?? 'unknown error');
        $m = Message::create(['conversation_id' => $conv->id, 'role' => 'assistant', 'content' => $reply, 'agent_key' => $ok->first()?->agent_key]);
        return ['conversationId' => $conv->id, 'message' => $m, 'tasks' => $tasks];
    }
}
