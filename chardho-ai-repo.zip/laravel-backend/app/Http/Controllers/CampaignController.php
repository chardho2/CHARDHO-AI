<?php

namespace App\Http\Controllers;

use App\Models\Campaign;
use Illuminate\Http\Request;

class CampaignController extends Controller
{
    public function index(Request $r)
    {
        $b = $this->biz($r);
        return Campaign::where('user_id', $this->uid($r))->where('business_id', $b->id)->latest()->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['businessId' => 'required|string', 'name' => 'required|string|max:200', 'kind' => 'nullable|string|max:50', 'objective' => 'nullable|string|max:2000', 'startsAt' => 'nullable|date', 'endsAt' => 'nullable|date']);
        $b = $this->biz($r, $d['businessId']);
        return response()->json(Campaign::create($this->snake($d) + ['user_id' => $this->uid($r), 'kind' => $d['kind'] ?? 'marketing']), 201);
    }

    public function update(Request $r, string $id)
    {
        $d = $r->validate(['name' => 'sometimes|string|max:200', 'status' => 'sometimes|in:planned,active,paused,completed', 'objective' => 'nullable|string|max:2000']);
        $c = Campaign::where('user_id', $this->uid($r))->findOrFail($id);
        $c->update($d);
        return $c->fresh();
    }

    /** Built only from recorded data; no AI-invented numbers. */
    public function report(Request $r, string $id)
    {
        $c = Campaign::where('user_id', $this->uid($r))->with(['content.jobs', 'outreach'])->findOrFail($id);
        $jobs = $c->content->flatMap->jobs;
        $count = fn ($col) => $col->countBy()->all();
        $report = [
            'campaign' => ['id' => $c->id, 'name' => $c->name, 'status' => $c->status],
            'content' => ['total' => $c->content->count(), 'byStatus' => $count($c->content->pluck('status'))],
            'publishing' => ['succeeded' => $jobs->where('status', 'SUCCEEDED')->count(), 'failed' => $jobs->where('status', 'FAILED')->count(), 'pending' => $jobs->where('status', 'PENDING')->count()],
            'influencerOutreach' => ['total' => $c->outreach->count(), 'byStatus' => $count($c->outreach->pluck('status'))],
            'deliverables' => $c->outreach->flatMap(fn ($o) => $o->deliverables ?? [])->values()->all(),
        ];
        $c->update(['report' => $report]);
        return $report;
    }
}
