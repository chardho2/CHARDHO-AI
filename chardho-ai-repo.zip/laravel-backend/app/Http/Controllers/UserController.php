<?php

namespace App\Http\Controllers;

use App\Models\{AgentTask, Business, ContentItem, Influencer, Lead, UsageRecord};
use App\Models\PublishingJob;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function update(Request $r)
    {
        $d = $r->validate(['name' => 'sometimes|string|min:1|max:100', 'locale' => 'sometimes|string|max:10']);
        $r->user()->update($d);
        return ['id' => $r->user()->id, 'email' => $r->user()->email, 'name' => $r->user()->name, 'locale' => $r->user()->locale];
    }

    public function export(Request $r)
    {
        $id = $this->uid($r);
        Support::audit($id, 'user.export', 'User', (string) $id);
        return response()->json([
            'exportedAt' => now()->toIso8601String(),
            'user' => $r->user()->only(['id', 'email', 'name', 'locale', 'created_at']),
            'businesses' => Business::where('user_id', $id)->get(),
            'tasks' => AgentTask::where('user_id', $id)->get(),
            'content' => ContentItem::where('user_id', $id)->with('versions')->get(),
            'leads' => Lead::where('user_id', $id)->get(),
            'influencers' => Influencer::where('user_id', $id)->get(),
            'usage' => UsageRecord::where('user_id', $id)->get(),
        ])->header('Content-Disposition', 'attachment; filename="chardho-export.json"');
    }

    /** Permanent deletion. Everything hangs off users via cascading foreign keys; the audit trail is kept without the user link. */
    public function destroy(Request $r)
    {
        $r->validate(['confirm' => 'required|in:DELETE']);
        $u = $r->user();
        Support::audit($u->id, 'user.delete', 'User', (string) $u->id);
        DB::transaction(function () use ($u) {
            PublishingJob::whereIn('social_account_id', fn ($q) => $q->select('id')->from('social_accounts')->where('user_id', $u->id))->where('status', 'PENDING')->update(['status' => 'CANCELLED']);
            $u->tokens()->delete();
            $u->forceDelete();
        });
        return response()->noContent();
    }
}
