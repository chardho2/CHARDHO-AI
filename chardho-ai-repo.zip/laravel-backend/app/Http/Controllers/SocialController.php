<?php

namespace App\Http\Controllers;

use App\Models\PublishingJob;
use App\Models\SocialAccount;
use App\Services\ApprovalService;
use App\Services\Platforms;
use App\Services\Support;
use App\Support\Logic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\HttpException;

class SocialController extends Controller
{
    private function redirectUri(string $p): string
    {
        return rtrim(config('chardho.api_url'), '/') . '/api/social/callback/' . strtolower($p);
    }

    private function platform(string $p): string
    {
        $p = strtoupper($p);
        if (!in_array($p, Logic::PLATFORMS, true)) throw new HttpException(422, 'Unknown platform');
        return $p;
    }

    /** Public route. Identity comes from the encrypted, expiring `state`, not from a bearer header. */
    public function callback(Request $r, string $platform)
    {
        $p = $this->platform($platform);
        $d = $r->validate(['code' => 'required|string', 'state' => 'required|string']);
        try { $st = json_decode(Crypt::decryptString($d['state']), true, 512, JSON_THROW_ON_ERROR); } catch (\Throwable) { $st = null; }
        if (!$st || ($st['exp'] ?? 0) < time() || ($st['p'] ?? '') !== $p) throw new HttpException(400, 'Invalid or expired OAuth state');
        Support::ownBusiness((int) $st['u'], $st['b']);
        $cfg = Platforms::oauth($p);
        $body = ['grant_type' => 'authorization_code', 'code' => $d['code'], 'redirect_uri' => $this->redirectUri($p), 'client_id' => $cfg['clientId']];
        if (!empty($st['v'])) $body['code_verifier'] = Crypt::decryptString($st['v']);
        $req = Http::asForm();
        if ($cfg['clientSecret']) { if ($p === 'X') $req = $req->withBasicAuth($cfg['clientId'], $cfg['clientSecret']); else $body['client_secret'] = $cfg['clientSecret']; }
        $tr = $req->post($cfg['tokenUrl'], $body);
        if (!$tr->ok() || !$tr->json('access_token')) throw new HttpException(400, 'Token exchange failed');
        $id = Platforms::identity($p, $tr->json('access_token'));
        $access = $id['accessToken'] ?? $tr->json('access_token');
        $exp = $tr->json('expires_in') ? now()->addSeconds((int) $tr->json('expires_in')) : null;
        $acct = SocialAccount::withTrashed()->updateOrCreate(
            ['business_id' => $st['b'], 'platform' => $p, 'external_id' => $id['externalId']],
            ['user_id' => $st['u'], 'display_name' => $id['displayName'], 'access_token_enc' => Crypt::encryptString($access),
             'refresh_token_enc' => $tr->json('refresh_token') ? Crypt::encryptString($tr->json('refresh_token')) : null, 'expires_at' => $exp, 'scopes' => $cfg['scopes'], 'deleted_at' => null]
        );
        Support::audit((int) $st['u'], 'social.connect', 'SocialAccount', $acct->id, ['platform' => $p]);
        return redirect(rtrim(config('chardho.app_url'), '/') . "/social?connected=$p");
    }

    public function accounts(Request $r)
    {
        $b = $this->biz($r);
        return SocialAccount::where('user_id', $this->uid($r))->where('business_id', $b->id)->get(['id', 'platform', 'display_name', 'external_id', 'expires_at', 'scopes', 'created_at']);
    }

    public function destroy(Request $r, string $id)
    {
        $a = SocialAccount::where('user_id', $this->uid($r))->findOrFail($id);
        PublishingJob::where('social_account_id', $a->id)->where('status', 'PENDING')->update(['status' => 'CANCELLED', 'error' => 'Account disconnected']);
        $a->update(['access_token_enc' => '', 'refresh_token_enc' => null]);
        $a->delete();
        return response()->noContent();
    }

    /** Returns the provider authorize URL; PKCE verifier is encrypted inside the state. */
    public function connect(Request $r, string $platform)
    {
        $p = $this->platform($platform);
        $b = $this->biz($r);
        $cfg = Platforms::oauth($p);
        if (!$cfg['clientId'] || !$cfg['clientSecret']) return response()->json(['error' => "$p OAuth is not configured by the platform owner", 'status' => 'not_configured'], 501);
        $verifier = $cfg['pkce'] ? Str::random(64) : null;
        $state = Crypt::encryptString(json_encode(['u' => $this->uid($r), 'b' => $b->id, 'p' => $p, 'v' => $verifier ? Crypt::encryptString($verifier) : null, 'exp' => time() + 600]));
        $q = ['client_id' => $cfg['clientId'], 'redirect_uri' => $this->redirectUri($p), 'response_type' => 'code', 'scope' => implode($cfg['sep'], $cfg['scopes']), 'state' => $state] + $cfg['extra'];
        if ($verifier) { $q['code_challenge'] = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '='); $q['code_challenge_method'] = 'S256'; }
        return ['url' => $cfg['authUrl'] . '?' . http_build_query($q)];
    }

    public function jobs(Request $r)
    {
        $b = $this->biz($r);
        return PublishingJob::whereHas('content', fn ($q) => $q->where('user_id', $this->uid($r))->where('business_id', $b->id))
            ->with(['account:id,platform,display_name', 'content:id,title,type'])->latest()->limit(100)->get();
    }

    /** "Publish now": still requires a valid human approval; it only skips waiting for a schedule. */
    public function publish(Request $r, ApprovalService $svc)
    {
        $d = $r->validate(['contentId' => 'required|string']);
        $job = $svc->schedule($this->uid($r), $d['contentId'], new \DateTimeImmutable());
        $outcome = $svc->runJob($job->id);
        return ['jobId' => $job->id, 'outcome' => $outcome, 'job' => PublishingJob::find($job->id)];
    }
}
