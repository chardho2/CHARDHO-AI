<?php

namespace App\Http\Controllers;

use App\Models\AgentTask;
use App\Models\AiAgent;
use App\Models\Announcement;
use App\Models\ApiProviderCost;
use App\Models\AuditLog;
use App\Models\Business;
use App\Models\ContentItem;
use App\Models\Integration;
use App\Models\ProviderConfig;
use App\Models\PublishingJob;
use App\Models\Setting;
use App\Models\SupportTicket;
use App\Models\User;
use App\Models\WorkflowRun;
use App\Services\AgentRegistry;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\HttpException;

class AdminController extends Controller
{
    public function overview()
    {
        $since = now()->subDay();
        $c = ApiProviderCost::selectRaw('sum(cost_usd) c, sum(tokens_in) i, sum(tokens_out) o')->first();
        return ['users' => User::count(), 'businesses' => Business::count(), 'tasks24' => AgentTask::where('created_at', '>=', $since)->count(),
            'failed24' => AgentTask::where('created_at', '>=', $since)->where('status', 'FAILED')->count(), 'content' => ContentItem::count(),
            'tokens' => ['tokensIn' => (int) $c->i, 'tokensOut' => (int) $c->o, 'costUsd' => (float) $c->c], 'totalCostUsd' => (float) $c->c,
            'failedWorkflowRuns' => WorkflowRun::where('status', 'FAILED')->count(), 'openTickets' => SupportTicket::where('status', 'open')->count(), 'dailyLimit' => Support::dailyLimit()];
    }

    public function server()
    {
        $load = function_exists('sys_getloadavg') ? sys_getloadavg() : [0, 0, 0];
        return ['php' => PHP_VERSION, 'laravel' => app()->version(), 'memoryMb' => (int) round(memory_get_usage(true) / 1048576), 'load' => $load, 'db' => DB::connection()->getDriverName(), 'env' => app()->environment()];
    }

    public function users()
    {
        return User::orderByDesc('id')->limit(500)->get(['id', 'email', 'name', 'role', 'email_verified_at', 'disabled_at', 'created_at'])
            ->map(fn ($u) => ['id' => (string) $u->id, 'email' => $u->email, 'name' => $u->name, 'role' => $u->role, 'emailVerifiedAt' => $u->email_verified_at, 'disabledAt' => $u->disabled_at, 'createdAt' => $u->created_at]);
    }

    /** OWNER manages everyone; SUPER_ADMIN manages ADMIN/USER; ADMIN only USER accounts. */
    public function updateUser(Request $r, string $id)
    {
        $d = $r->validate(['role' => 'sometimes|in:OWNER,SUPER_ADMIN,ADMIN,USER', 'disabled' => 'sometimes|boolean']);
        $actor = $r->user();
        $t = User::findOrFail($id);
        if ($t->id === $actor->id && (!empty($d['disabled']) || isset($d['role']))) throw new HttpException(400, 'You cannot change your own role or disable yourself');
        if ($t->rank() >= $actor->rank() && $actor->role !== 'OWNER') throw new HttpException(403, 'Cannot manage a user of equal or higher role');
        if (isset($d['role'])) {
            if ($actor->rank() < User::RANK['SUPER_ADMIN']) throw new HttpException(403, 'Only Super Admin or Owner can change roles');
            if ((User::RANK[$d['role']]) >= $actor->rank() && $actor->role !== 'OWNER') throw new HttpException(403, 'Cannot grant a role equal or higher than your own');
            if ($d['role'] === 'OWNER') throw new HttpException(403, 'Ownership transfer is not available via the API');
            $t->role = $d['role'];
        }
        if (array_key_exists('disabled', $d)) {
            $t->disabled_at = $d['disabled'] ? now() : null;
            if ($d['disabled']) $t->tokens()->delete();
        }
        $t->save();
        Support::audit($actor->id, 'admin.user_update', 'User', (string) $t->id, $d);
        return ['id' => (string) $t->id, 'role' => $t->role, 'disabled' => (bool) $t->disabled_at];
    }

    public function agents()
    {
        $rows = AiAgent::all()->keyBy('key');
        return collect(AgentRegistry::all())->map(fn ($a, $k) => ['key' => $k, 'name' => $a['name'], 'enabled' => $rows[$k]->enabled ?? true,
            'systemPrompt' => $rows[$k]->system_prompt ?? $a['systemPrompt'], 'customized' => isset($rows[$k]) && $rows[$k]->system_prompt !== $a['systemPrompt']])->values();
    }

    public function updateAgent(Request $r, string $key)
    {
        $d = $r->validate(['enabled' => 'sometimes|boolean', 'systemPrompt' => 'sometimes|string|min:20|max:8000']);
        $def = AgentRegistry::get($key) ?? throw new HttpException(404, 'Agent not found');
        $row = AiAgent::firstOrCreate(['key' => $key], ['name' => $def['name'], 'description' => $def['description'], 'system_prompt' => $def['systemPrompt'], 'tools' => $def['tools'], 'enabled' => true]);
        $row->update($this->snake($d));
        Support::audit($r->user()->id, 'admin.agent_update', 'AiAgent', $key, ['enabled' => $d['enabled'] ?? null, 'promptChanged' => isset($d['systemPrompt'])]);
        return $row->fresh();
    }

    private function safeProvider(ProviderConfig $p): array
    {
        $a = $p->toArray();
        unset($a['apiKeyEnc']);
        return $a + ['hasApiKey' => !empty($p->api_key_enc)];
    }

    /** Secrets are write-only. */
    public function providers()
    {
        $cost = ApiProviderCost::selectRaw('provider, sum(cost_usd) cost, sum(tokens_in) tin, sum(tokens_out) tout, count(*) n')->groupBy('provider')->get()->keyBy('provider');
        return ProviderConfig::orderBy('priority')->get()->map(fn ($p) => $this->safeProvider($p) + ['usage' => $cost[$p->key] ?? null])->values();
    }

    public function updateProvider(Request $r, string $key)
    {
        $d = $r->validate(['enabled' => 'sometimes|boolean', 'model' => 'sometimes|string|min:1|max:100', 'priority' => 'sometimes|integer|min:0|max:1000', 'dailyLimit' => 'sometimes|nullable|integer|min:0',
            'baseUrl' => 'sometimes|nullable|url', 'apiKey' => 'sometimes|string|min:8|max:500', 'paid' => 'sometimes|boolean']);
        if (array_key_exists('paid', $d) && $d['paid'] === false && $r->user()->role !== 'OWNER') throw new HttpException(403, 'Only the Owner can mark a provider as free');
        $p = ProviderConfig::where('key', $key)->firstOrFail();
        $key_ = $d['apiKey'] ?? null; unset($d['apiKey']);
        $data = $this->snake($d);
        if ($key_) $data['api_key_enc'] = Crypt::encryptString($key_);
        $p->update($data);
        Support::audit($r->user()->id, 'admin.provider_update', 'ProviderConfig', $key, $d + ['apiKeyChanged' => (bool) $key_]);
        return $this->safeProvider($p->fresh());
    }

    public function createProvider(Request $r)
    {
        $d = $r->validate(['key' => ['required', 'regex:/^[a-z0-9_-]{2,30}$/', 'unique:provider_configs,key'], 'name' => 'required|string', 'model' => 'required|string', 'baseUrl' => 'required|url', 'apiKey' => 'nullable|string', 'paid' => 'sometimes|boolean']);
        $p = ProviderConfig::create(['key' => $d['key'], 'name' => $d['name'], 'model' => $d['model'], 'base_url' => $d['baseUrl'], 'paid' => $d['paid'] ?? true, 'capabilities' => ['text', 'json'],
            'api_key_enc' => !empty($d['apiKey']) ? Crypt::encryptString($d['apiKey']) : null, 'priority' => 80, 'enabled' => false]);
        Support::audit($r->user()->id, 'admin.provider_create', 'ProviderConfig', $p->key);
        return response()->json(['key' => $p->key, 'note' => 'Registered but disabled. Custom providers are served through the OpenAI-compatible adapter; enable it explicitly (paid providers also need ALLOW_PAID_PROVIDERS=true).'], 201);
    }

    public function settings()
    {
        return Setting::all()->mapWithKeys(fn ($s) => [$s->key => $s->value['v'] ?? null]);
    }

    public function putSetting(Request $r, string $key)
    {
        if (!in_array($key, ['dailyAiRequestLimit', 'registrationOpen', 'maintenanceMode'], true)) throw new HttpException(422, 'Unknown setting');
        $v = $r->input('value');
        $ok = $key === 'dailyAiRequestLimit' ? (is_int($v) && $v >= 0 && $v <= 100000) : is_bool($v);
        if (!$ok) throw new HttpException(422, 'Invalid value');
        Setting::put($key, $v);
        Support::audit($r->user()->id, 'admin.setting', 'Setting', $key, ['value' => $v]);
        return ['key' => $key, 'value' => $v];
    }

    public function tasks(Request $r)
    {
        $q = AgentTask::orderByDesc('created_at')->limit(200)->select('id', 'user_id', 'agent_key', 'status', 'attempts', 'error', 'provider', 'model', 'tokens_in', 'tokens_out', 'created_at', 'finished_at');
        if ($s = $r->query('status')) $q->where('status', $s);
        return $q->get();
    }

    public function failedWorkflows()
    {
        return WorkflowRun::where('status', 'FAILED')->with('workflow:id,name')->latest()->limit(200)->get();
    }

    public function failedPublishing()
    {
        return PublishingJob::where('status', 'FAILED')->with('account:id,platform')->latest()->limit(200)->get(['id', 'error', 'attempts', 'created_at', 'social_account_id']);
    }

    public function audit()
    {
        return AuditLog::latest()->limit(300)->get();
    }

    public function announcements()
    {
        return Announcement::latest()->get();
    }

    public function createAnnouncement(Request $r)
    {
        return response()->json(Announcement::create($r->validate(['title' => 'required|string|max:200', 'body' => 'required|string|max:2000'])), 201);
    }

    public function updateAnnouncement(Request $r, string $id)
    {
        $a = Announcement::findOrFail($id);
        $a->update($r->validate(['active' => 'required|boolean']));
        return $a->fresh();
    }

    public function tickets()
    {
        return SupportTicket::with('user:id,email')->latest()->limit(200)->get();
    }

    public function updateTicket(Request $r, string $id)
    {
        $t = SupportTicket::findOrFail($id);
        $t->update($r->validate(['status' => 'required|in:open,in_progress,closed']));
        return $t->fresh();
    }

    public function integrations()
    {
        return Integration::get(['key', 'name', 'enabled', 'status', 'updated_at']);
    }

    public function analytics()
    {
        $signups = User::selectRaw('date(created_at) as day, count(*) as n')->groupBy('day')->orderByDesc('day')->limit(30)->get()->map(fn ($x) => ['day' => $x->day, 'n' => (int) $x->n]);
        $tasks = AgentTask::selectRaw('agent_key, status, count(*) as n')->groupBy('agent_key', 'status')->get();
        return ['signupsByDay' => $signups, 'tasksByAgent' => $tasks];
    }
}
