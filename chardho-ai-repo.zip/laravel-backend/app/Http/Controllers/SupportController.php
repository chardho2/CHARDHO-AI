<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    public function index(Request $r)
    {
        return SupportTicket::where('user_id', $this->uid($r))->latest()->get();
    }

    public function store(Request $r)
    {
        $d = $r->validate(['subject' => 'required|string|min:3|max:200', 'body' => 'required|string|min:3|max:5000']);
        return response()->json(SupportTicket::create($d + ['user_id' => $this->uid($r)]), 201);
    }
}
