<?php

namespace App\Http\Controllers;

use App\Models\AuthToken;
use App\Models\User;
use App\Services\Support;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\HttpException;

class AuthController extends Controller
{
    private const PW = ['required', 'string', 'min:10', 'max:128', 'regex:/[a-z]/', 'regex:/[A-Z]/', 'regex:/[0-9]/'];

    private function issue(User $u, string $type, int $ttlMinutes): string
    {
        $raw = bin2hex(random_bytes(32));
        AuthToken::create(['user_id' => $u->id, 'type' => $type, 'token_hash' => hash('sha256', $raw), 'expires_at' => now()->addMinutes($ttlMinutes)]);
        return $raw;
    }

    private function consume(string $raw, string $type): int
    {
        $t = AuthToken::where('token_hash', hash('sha256', $raw))->first();
        if (!$t || $t->type !== $type || $t->used_at || $t->expires_at->isPast()) throw new HttpException(400, 'Invalid or expired token');
        $t->update(['used_at' => now()]);
        return $t->user_id;
    }

    private function mail(string $to, string $subject, string $text): void
    {
        Mail::raw($text, fn ($m) => $m->to($to)->subject($subject)); // MAIL_MAILER=log in dev: link appears in storage/logs
    }

    public function register(Request $r)
    {
        $d = $r->validate(['email' => 'required|email|max:255', 'password' => self::PW, 'name' => 'required|string|max:100']);
        $email = Str::lower($d['email']);
        if (User::withTrashed()->where('email', $email)->exists()) throw new HttpException(409, 'Email already registered');
        $u = User::create(['name' => $d['name'], 'email' => $email, 'password' => $d['password'], 'role' => 'USER']);
        $this->mail($email, 'Verify your CHARDHO AI account', 'Verify: ' . config('chardho.app_url') . '/verify-email?token=' . $this->issue($u, 'EMAIL_VERIFY', 1440));
        Support::audit($u->id, 'auth.register', 'User', (string) $u->id);
        return response()->json(['message' => 'Registered. Check your email to verify your account.'], 201);
    }

    public function verifyEmail(Request $r)
    {
        $uid = $this->consume($r->validate(['token' => 'required|string'])['token'], 'EMAIL_VERIFY');
        User::whereKey($uid)->update(['email_verified_at' => now()]);
        return ['message' => 'Email verified'];
    }

    public function login(Request $r)
    {
        $d = $r->validate(['email' => 'required|email', 'password' => 'required|string']);
        $u = User::where('email', Str::lower($d['email']))->first();
        // always spend time hashing so response time does not reveal whether the email exists
        $ok = Hash::check($d['password'], $u?->password ?? '$2y$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
        if (!$u || !$ok || $u->disabled_at) throw new HttpException(401, 'Invalid credentials');
        if (!$u->email_verified_at) throw new HttpException(403, 'Please verify your email first');
        Support::audit($u->id, 'auth.login', 'User', (string) $u->id);
        return ['token' => $u->createToken('web', ['*'], now()->addHours(12))->plainTextToken, 'user' => $u->toPublic()];
    }

    public function forgot(Request $r)
    {
        $email = Str::lower($r->validate(['email' => 'required|email'])['email']);
        if ($u = User::where('email', $email)->first()) {
            $this->mail($email, 'Reset your CHARDHO AI password', 'Reset: ' . config('chardho.app_url') . '/reset-password?token=' . $this->issue($u, 'PASSWORD_RESET', 60));
        }
        return ['message' => 'If that email exists, a reset link has been sent.']; // no user enumeration
    }

    public function reset(Request $r)
    {
        $d = $r->validate(['token' => 'required|string', 'password' => self::PW]);
        $uid = $this->consume($d['token'], 'PASSWORD_RESET');
        $u = User::findOrFail($uid);
        $u->update(['password' => $d['password']]);
        $u->tokens()->delete(); // revoke every existing session
        Support::audit($uid, 'auth.password_reset', 'User', (string) $uid);
        return ['message' => 'Password updated. Please log in.'];
    }

    public function logoutAll(Request $r)
    {
        $r->user()->tokens()->delete();
        return ['message' => 'All sessions revoked'];
    }

    public function me(Request $r)
    {
        return $r->user()->toPublic();
    }

    // ---- Google OAuth (authorization-code flow, encrypted+expiring `state`) ----
    public function google()
    {
        $g = config('chardho.google');
        if (!$g['client_id'] || !$g['client_secret']) return response()->json(['error' => 'Google OAuth is not configured'], 501);
        $state = Crypt::encryptString(json_encode(['n' => Str::random(16), 'exp' => time() + 600]));
        return redirect('https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
            'client_id' => $g['client_id'], 'redirect_uri' => rtrim(config('chardho.api_url'), '/') . '/api/auth/google/callback',
            'response_type' => 'code', 'scope' => 'openid email profile', 'state' => $state, 'prompt' => 'select_account',
        ]));
    }

    public function googleCallback(Request $r)
    {
        $d = $r->validate(['code' => 'required|string', 'state' => 'required|string']);
        try { $st = json_decode(Crypt::decryptString($d['state']), true); } catch (\Throwable) { $st = null; }
        if (!$st || ($st['exp'] ?? 0) < time()) throw new HttpException(400, 'Invalid OAuth state');
        $g = config('chardho.google');
        $tr = Http::asForm()->post('https://oauth2.googleapis.com/token', ['code' => $d['code'], 'client_id' => $g['client_id'], 'client_secret' => $g['client_secret'], 'redirect_uri' => rtrim(config('chardho.api_url'), '/') . '/api/auth/google/callback', 'grant_type' => 'authorization_code']);
        if (!$tr->ok()) throw new HttpException(400, 'Google token exchange failed');
        $info = Http::withToken($tr->json('access_token'))->get('https://www.googleapis.com/oauth2/v3/userinfo')->json();
        if (empty($info['email_verified'])) throw new HttpException(400, 'Google email not verified');
        $email = Str::lower($info['email']);
        $u = User::where('google_id', $info['sub'])->orWhere('email', $email)->first();
        if ($u && $u->disabled_at) throw new HttpException(403, 'Account disabled');
        $u = $u ? tap($u)->update(['google_id' => $info['sub'], 'email_verified_at' => $u->email_verified_at ?? now()])
               : User::create(['email' => $email, 'name' => $info['name'] ?? null, 'google_id' => $info['sub'], 'email_verified_at' => now(), 'role' => 'USER']);
        Support::audit($u->id, 'auth.google_login', 'User', (string) $u->id);
        // token in the URL fragment: never sent to servers or logs
        return redirect(rtrim(config('chardho.app_url'), '/') . '/oauth-complete#token=' . $u->createToken('web', ['*'], now()->addHours(12))->plainTextToken);
    }
}
