<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Rejects tokens of disabled or deleted accounts, even if the token itself is still valid. */
class EnsureActive
{
    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();
        if (!$u || $u->deleted_at || $u->disabled_at) {
            return response()->json(['error' => 'Session invalid'], 401);
        }
        return $next($request);
    }
}
