<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;

class RequireRole
{
    public function handle(Request $request, Closure $next, string $min)
    {
        if (!$request->user() || $request->user()->rank() < (User::RANK[$min] ?? 99)) {
            return response()->json(['error' => 'Insufficient role'], 403);
        }
        return $next($request);
    }
}
