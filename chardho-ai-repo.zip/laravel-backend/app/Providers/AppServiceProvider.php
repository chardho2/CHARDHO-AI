<?php

namespace App\Providers;

use App\Models\AiAgent;
use App\Services\AgentRegistry;
use App\Services\ProviderManager;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // General API limit (auth routes add their own stricter throttle in routes/api.php).
        RateLimiter::for('api', fn (Request $r) => Limit::perMinute(300)->by($r->user()?->id ?: $r->ip()));

        // Make sure agents and provider rows exist; harmless no-op before migrations have run.
        if ($this->app->runningInConsole() && !in_array($_SERVER['argv'][1] ?? '', ['migrate', 'db:seed', 'chardho:tick', 'schedule:run', 'serve'], true)) return;
        try {
            if (!Schema::hasTable('ai_agents') || !Schema::hasTable('provider_configs')) return;
            ProviderManager::ensureDefaults();
            foreach (AgentRegistry::all() as $key => $a) {
                AiAgent::firstOrCreate(['key' => $key], ['name' => $a['name'], 'description' => $a['description'], 'system_prompt' => $a['systemPrompt'], 'tools' => $a['tools'], 'enabled' => true]);
            }
        } catch (\Throwable) {
            // DB not reachable yet (e.g. during build); seeders cover this path.
        }
    }
}
