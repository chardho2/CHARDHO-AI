<?php

namespace App\Console\Commands;

use App\Models\AutomationWorkflow;
use App\Models\WorkflowRun;
use App\Services\ApprovalService;
use App\Services\WorkflowEngine;
use Illuminate\Console\Command;

class Tick extends Command
{
    protected $signature = 'chardho:tick {--loop : keep running (for a Docker/supervisor worker instead of cron)} {--sleep=15}';
    protected $description = 'Process due publishing jobs, queued workflow runs and scheduled workflows';

    public function handle(ApprovalService $approvals, WorkflowEngine $engine): int
    {
        do {
            $this->once($approvals, $engine);
            if ($this->option('loop')) sleep(max(1, (int) $this->option('sleep')));
        } while ($this->option('loop'));
        return self::SUCCESS;
    }

    private function once(ApprovalService $approvals, WorkflowEngine $engine): void
    {
        try { $n = $approvals->runDue(); if ($n) $this->info("publishing jobs run: $n"); } catch (\Throwable $e) { report($e); }

        // Scheduled workflows: graph.schedule.everyHours. lastRunAt is claimed atomically so two workers never double-fire.
        foreach (AutomationWorkflow::where('trigger', 'scheduled')->where('enabled', true)->where('paused', false)->get() as $w) {
            $hours = (int) ($w->graph['schedule']['everyHours'] ?? 0);
            if ($hours < 1) continue;
            $last = $w->last_run_at ?? null;
            if ($last && $last->gt(now()->subHours($hours))) continue;
            $claimed = AutomationWorkflow::where('id', $w->id)
                ->where(fn ($q) => $q->whereNull('last_run_at')->orWhere('last_run_at', '<=', now()->subHours($hours)))
                ->update(['last_run_at' => now()]);
            if ($claimed) WorkflowRun::create(['workflow_id' => $w->id, 'user_id' => $w->user_id, 'trigger_data' => ['scheduled' => true], 'logs' => [], 'status' => 'QUEUED']);
        }

        foreach (WorkflowRun::whereIn('status', ['QUEUED'])->oldest()->limit(10)->pluck('id') as $id) {
            try { $engine->execute($id); } catch (\Throwable $e) { report($e); }
        }
    }
}
