<?php

namespace App\Support;

/**
 * Framework-free business rules. Kept pure so they can be unit-tested without booting Laravel.
 */
final class Logic
{
    public const PLATFORMS = ['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X'];
    private const LIMITS = ['X' => 280, 'INSTAGRAM' => 2200, 'LINKEDIN' => 3000, 'FACEBOOK' => 63206, 'YOUTUBE' => 5000];

    /** Canonical hash of the publishable parts of a content version. */
    public static function contentHash(string $body, array $hashtags, array $mediaIds): string
    {
        sort($hashtags);
        sort($mediaIds);
        return hash('sha256', json_encode(['body' => trim($body), 'hashtags' => array_values($hashtags), 'media' => array_values($mediaIds)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    /** @return array{ok:bool,issues:string[]} */
    public static function quality(string $body, ?string $platform): array
    {
        $issues = [];
        if (trim($body) === '') {
            $issues[] = 'Content is empty';
        }
        if ($platform && isset(self::LIMITS[$platform]) && mb_strlen($body) > self::LIMITS[$platform]) {
            $issues[] = "Exceeds {$platform} limit of " . self::LIMITS[$platform] . ' characters';
        }
        if (preg_match('/(lorem ipsum|\[insert|\bTODO\b)/i', $body)) {
            $issues[] = 'Contains placeholder text';
        }
        return ['ok' => $issues === [], 'issues' => $issues];
    }

    /** Models often wrap JSON in fences or chatter. */
    public static function parseJsonLoose(string $text): array
    {
        $t = trim(preg_replace('/^```(?:json)?|```$/mi', '', trim($text)));
        $d = json_decode($t, true);
        if (is_array($d)) {
            return $d;
        }
        if (preg_match('/\{.*\}/s', $t, $m) && is_array($d = json_decode($m[0], true))) {
            return $d;
        }
        throw new \InvalidArgumentException('Model did not return valid JSON');
    }

    /** Validate and normalise an agent's JSON output. Throws on invalid shape. */
    public static function normalizeAgentOutput(array $o): array
    {
        if (!isset($o['summary']) || !is_string($o['summary']) || trim($o['summary']) === '') {
            throw new \InvalidArgumentException('summary is required');
        }
        $drafts = [];
        foreach (($o['drafts'] ?? []) as $d) {
            if (!is_array($d) || !isset($d['body']) || !is_string($d['body']) || trim($d['body']) === '' || mb_strlen($d['body']) > 20000) {
                throw new \InvalidArgumentException('draft body invalid');
            }
            $p = isset($d['platform']) && is_string($d['platform']) ? strtoupper(str_replace('TWITTER', 'X', strtoupper($d['platform']))) : null;
            $drafts[] = [
                'type' => substr((string)($d['type'] ?? 'social_post'), 0, 60) ?: 'social_post',
                'platform' => in_array($p, self::PLATFORMS, true) ? $p : null,
                'title' => substr((string)($d['title'] ?? ''), 0, 300),
                'body' => $d['body'],
                'hashtags' => array_slice(array_values(array_filter((array)($d['hashtags'] ?? []), 'is_string')), 0, 40),
            ];
        }
        $o['drafts'] = array_slice($drafts, 0, 30);
        $o['notes'] = array_values(array_filter((array)($o['notes'] ?? []), 'is_string'));
        return $o;
    }

    public static function dedupeKey(?string $email, ?string $phone, ?string $businessName, ?string $contactName): string
    {
        if ($email && trim($email) !== '') {
            return strtolower(trim($email));
        }
        if ($phone && ($digits = preg_replace('/\D/', '', $phone)) !== '') {
            return $digits;
        }
        return strtolower(trim((string)$businessName)) . '|' . strtolower(trim((string)$contactName));
    }

    public static function scoreLead(?string $email, ?string $phone, ?string $businessName, ?string $industry, string $status = 'new'): int
    {
        $s = ($email ? 25 : 0) + ($phone ? 15 : 0) + ($businessName ? 10 : 0) + ($industry ? 10 : 0);
        $s += ['new' => 0, 'contacted' => 10, 'qualified' => 30, 'won' => 40, 'lost' => -20][$status] ?? 0;
        return max(0, min(100, $s));
    }

    /** Workflow condition: ctx[path] <op> value */
    public static function condition(array $c, array $ctx): bool
    {
        $v = $ctx;
        foreach (explode('.', (string)$c['path']) as $k) {
            if (!is_array($v) || !array_key_exists($k, $v)) { $v = null; break; }
            $v = $v[$k];
        }
        $want = $c['value'] ?? null;
        return match ($c['op'] ?? '') {
            'eq' => $v === $want,
            'neq' => $v !== $want,
            'gt' => is_numeric($v) && $v > $want,
            'lt' => is_numeric($v) && $v < $want,
            'contains' => is_string($v) ? str_contains($v, (string)$want) : (is_array($v) && in_array($want, $v, true)),
            'exists' => $v !== null,
            default => false,
        };
    }

    /** Replace ${path} placeholders from context. */
    public static function template(mixed $s, array $ctx): mixed
    {
        if (!is_string($s)) {
            return $s;
        }
        return preg_replace_callback('/\$\{([\w.]+)\}/', function ($m) use ($ctx) {
            $v = $ctx;
            foreach (explode('.', $m[1]) as $k) {
                if (!is_array($v) || !array_key_exists($k, $v)) { return ''; }
                $v = $v[$k];
            }
            return is_scalar($v) ? (string)$v : '';
        }, $s);
    }

    /** RFC4180-ish CSV parser. */
    public static function parseCsv(string $text): array
    {
        $rows = []; $row = []; $cur = ''; $q = false; $n = strlen($text);
        for ($i = 0; $i < $n; $i++) {
            $c = $text[$i];
            if ($q) {
                if ($c === '"') { if (($text[$i + 1] ?? '') === '"') { $cur .= '"'; $i++; } else { $q = false; } } else { $cur .= $c; }
            } elseif ($c === '"') { $q = true; }
            elseif ($c === ',') { $row[] = $cur; $cur = ''; }
            elseif ($c === "\n" || $c === "\r") {
                if ($c === "\r" && ($text[$i + 1] ?? '') === "\n") { $i++; }
                $row[] = $cur; $cur = '';
                if (array_filter($row, fn ($x) => trim($x) !== '')) { $rows[] = $row; }
                $row = [];
            } else { $cur .= $c; }
        }
        $row[] = $cur;
        if (array_filter($row, fn ($x) => trim($x) !== '')) { $rows[] = $row; }
        return $rows;
    }

    /** CSV cell with formula-injection guard. */
    public static function csvCell(mixed $v): string
    {
        $s = $v === null ? '' : (string)$v;
        if (preg_match('/^[=+\-@\t\r]/', $s)) { $s = "'" . $s; }
        return preg_match('/[",\n\r]/', $s) ? '"' . str_replace('"', '""', $s) . '"' : $s;
    }

    /** Magic-byte sniff; never trust client mime. @return array{mime:string,ext:string}|null */
    public static function sniffImage(string $bytes): ?array
    {
        if (str_starts_with($bytes, "\x89PNG\r\n\x1a\n")) return ['mime' => 'image/png', 'ext' => 'png'];
        if (str_starts_with($bytes, "\xFF\xD8\xFF")) return ['mime' => 'image/jpeg', 'ext' => 'jpg'];
        if (substr($bytes, 0, 4) === 'RIFF' && substr($bytes, 8, 4) === 'WEBP') return ['mime' => 'image/webp', 'ext' => 'webp'];
        if (substr($bytes, 0, 3) === 'GIF') return ['mime' => 'image/gif', 'ext' => 'gif'];
        return null;
    }
}
