<?php

namespace App\Services;

use App\Models\Approval;
use App\Models\ContentItem;
use App\Models\PublishingJob;
use App\Support\Logic;
use Illuminate\Support\Facades\DB;

class ContentService
{
    public function create(int $userId, string $businessId, array $a): ContentItem
    {
        $tags = $a['hashtags'] ?? [];
        $qc = Logic::quality($a['body'], $a['platform'] ?? null);
        return DB::transaction(function () use ($userId, $businessId, $a, $tags, $qc) {
            $item = ContentItem::create([
                'user_id' => $userId, 'business_id' => $businessId, 'type' => $a['type'], 'platform' => $a['platform'] ?? null, 'title' => $a['title'] ?? null,
                'language' => $a['language'] ?? 'en', 'tone' => $a['tone'] ?? null, 'audience' => $a['audience'] ?? null,
                'created_by_agent' => $a['created_by_agent'] ?? null, 'campaign_id' => $a['campaign_id'] ?? null,
                'status' => $qc['ok'] ? 'QUALITY_CHECKED' : 'DRAFT', 'current_version' => 1,
            ]);
            $item->versions()->create(['version' => 1, 'body' => $a['body'], 'hashtags' => $tags, 'media_asset_ids' => [], 'content_hash' => Logic::contentHash($a['body'], $tags, []), 'created_by' => $a['created_by_agent'] ?? (string) $userId]);
            return $item->load('versions');
        });
    }

    /**
     * Editing creates a new version, invalidates every live approval and cancels pending publish jobs,
     * so an edited post always needs a fresh human approval.
     */
    public function edit(string $contentId, int $userId, array $patch): ContentItem
    {
        return DB::transaction(function () use ($contentId, $userId, $patch) {
            $item = ContentItem::lockForUpdate()->findOrFail($contentId);
            $cur = $item->versions()->orderByDesc('version')->first();
            $body = $patch['body'] ?? $cur->body;
            $tags = $patch['hashtags'] ?? $cur->hashtags;
            $media = $patch['mediaAssetIds'] ?? $cur->media_asset_ids;
            $hash = Logic::contentHash($body, $tags, $media);
            $changed = $hash !== $cur->content_hash;
            if ($changed) {
                $item->versions()->create(['version' => $cur->version + 1, 'body' => $body, 'hashtags' => $tags, 'media_asset_ids' => $media, 'content_hash' => $hash, 'created_by' => (string) $userId]);
                Approval::where('content_id', $item->id)->whereNull('invalidated_at')->update(['invalidated_at' => now(), 'invalid_reason' => 'Content edited after approval']);
                PublishingJob::where('content_id', $item->id)->where('status', 'PENDING')->update(['status' => 'CANCELLED', 'error' => 'Content edited; approval invalidated']);
            }
            $qc = Logic::quality($body, $item->platform);
            $item->fill([
                'title' => $patch['title'] ?? $item->title,
                'current_version' => $changed ? $cur->version + 1 : $cur->version,
                'status' => $item->status === 'PUBLISHED' ? 'PUBLISHED' : ($qc['ok'] ? 'QUALITY_CHECKED' : 'DRAFT'),
            ])->save();
            return $item->load('versions');
        });
    }

    /** Frontend expects `versions[0]` to be the latest. */
    public static function latestOnly(ContentItem $c): ContentItem
    {
        $c->setRelation('versions', $c->versions->sortByDesc('version')->take(1)->values());
        return $c;
    }
}
