<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

/** Official-API OAuth config and publishers. Where an API can't do the job we fail loudly, never fake success. */
final class Platforms
{
    public static function oauth(string $p): array
    {
        $c = config("chardho.social.$p") ?? [];
        $base = match ($p) {
            'X' => ['authUrl' => 'https://twitter.com/i/oauth2/authorize', 'tokenUrl' => 'https://api.twitter.com/2/oauth2/token', 'scopes' => ['tweet.read', 'tweet.write', 'users.read', 'offline.access'], 'pkce' => true],
            'LINKEDIN' => ['authUrl' => 'https://www.linkedin.com/oauth/v2/authorization', 'tokenUrl' => 'https://www.linkedin.com/oauth/v2/accessToken', 'scopes' => ['openid', 'profile', 'w_member_social']],
            'FACEBOOK' => ['authUrl' => 'https://www.facebook.com/v19.0/dialog/oauth', 'tokenUrl' => 'https://graph.facebook.com/v19.0/oauth/access_token', 'scopes' => ['pages_show_list', 'pages_manage_posts', 'pages_read_engagement'], 'sep' => ','],
            'INSTAGRAM' => ['authUrl' => 'https://www.facebook.com/v19.0/dialog/oauth', 'tokenUrl' => 'https://graph.facebook.com/v19.0/oauth/access_token', 'scopes' => ['pages_show_list', 'instagram_basic', 'instagram_content_publish'], 'sep' => ','],
            'YOUTUBE' => ['authUrl' => 'https://accounts.google.com/o/oauth2/v2/auth', 'tokenUrl' => 'https://oauth2.googleapis.com/token', 'scopes' => ['https://www.googleapis.com/auth/youtube.readonly', 'https://www.googleapis.com/auth/youtube.force-ssl'], 'extra' => ['access_type' => 'offline', 'prompt' => 'consent']],
            default => throw new \InvalidArgumentException('Unknown platform'),
        };
        return $base + ['clientId' => $c['id'] ?? null, 'clientSecret' => $c['secret'] ?? null, 'sep' => ' ', 'pkce' => false, 'extra' => []];
    }

    /** @return array{externalId:string,displayName:string,accessToken?:string} */
    public static function identity(string $p, string $token): array
    {
        $h = Http::withToken($token)->timeout(20);
        switch ($p) {
            case 'X':
                $d = $h->get('https://api.twitter.com/2/users/me')->throw()->json('data');
                return ['externalId' => $d['id'], 'displayName' => '@' . $d['username']];
            case 'LINKEDIN':
                $d = $h->get('https://api.linkedin.com/v2/userinfo')->throw()->json();
                return ['externalId' => $d['sub'], 'displayName' => $d['name'] ?? 'LinkedIn member'];
            case 'YOUTUBE':
                $d = $h->get('https://www.googleapis.com/youtube/v3/channels', ['part' => 'snippet', 'mine' => 'true'])->throw()->json('items.0');
                if (!$d) throw new \RuntimeException('No YouTube channel on this account');
                return ['externalId' => $d['id'], 'displayName' => $d['snippet']['title']];
            case 'FACEBOOK':
                $d = Http::get('https://graph.facebook.com/v19.0/me/accounts', ['access_token' => $token])->throw()->json('data.0');
                if (!$d) throw new \RuntimeException('No Facebook Page found');
                return ['externalId' => $d['id'], 'displayName' => $d['name'], 'accessToken' => $d['access_token']];
            case 'INSTAGRAM':
                $pages = Http::get('https://graph.facebook.com/v19.0/me/accounts', ['fields' => 'id,name,access_token,instagram_business_account', 'access_token' => $token])->throw()->json('data') ?? [];
                $page = collect($pages)->first(fn ($x) => !empty($x['instagram_business_account']));
                if (!$page) throw new \RuntimeException('No Instagram Business account linked to a Facebook Page');
                return ['externalId' => $page['instagram_business_account']['id'], 'displayName' => $page['name'], 'accessToken' => $page['access_token']];
        }
        throw new \InvalidArgumentException('Unknown platform');
    }

    private static function text(string $body, array $tags): string
    {
        $t = implode(' ', array_map(fn ($x) => str_starts_with($x, '#') ? $x : "#$x", $tags));
        return trim($body . ($t ? "\n\n$t" : ''));
    }

    /** @return array{postId:string,raw:mixed} */
    public static function publish(string $p, string $body, array $tags, ?string $imageUrl, string $token, string $externalId): array
    {
        $text = self::text($body, $tags);
        switch ($p) {
            case 'X':
                $raw = Http::withToken($token)->post('https://api.twitter.com/2/tweets', ['text' => $text])->throw()->json();
                return ['postId' => $raw['data']['id'], 'raw' => $raw];
            case 'LINKEDIN':
                $raw = Http::withToken($token)->withHeaders(['X-Restli-Protocol-Version' => '2.0.0'])->post('https://api.linkedin.com/v2/ugcPosts', [
                    'author' => "urn:li:person:$externalId", 'lifecycleState' => 'PUBLISHED',
                    'specificContent' => ['com.linkedin.ugc.ShareContent' => ['shareCommentary' => ['text' => $text], 'shareMediaCategory' => 'NONE']],
                    'visibility' => ['com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC'],
                ])->throw()->json();
                return ['postId' => $raw['id'], 'raw' => $raw];
            case 'FACEBOOK':
                $raw = Http::asForm()->post("https://graph.facebook.com/v19.0/$externalId/feed", ['message' => $text, 'access_token' => $token])->throw()->json();
                return ['postId' => $raw['id'], 'raw' => $raw];
            case 'INSTAGRAM':
                if (!$imageUrl) throw new \RuntimeException('Instagram requires an image or video; attach media before publishing');
                $create = Http::asForm()->post("https://graph.facebook.com/v19.0/$externalId/media", ['image_url' => $imageUrl, 'caption' => $text, 'access_token' => $token])->throw()->json();
                $raw = Http::asForm()->post("https://graph.facebook.com/v19.0/$externalId/media_publish", ['creation_id' => $create['id'], 'access_token' => $token])->throw()->json();
                return ['postId' => $raw['id'], 'raw' => ['create' => $create, 'publish' => $raw]];
        }
        throw new \RuntimeException('YouTube publishing requires a video upload, which is not supported yet. Use the generated script/description manually in YouTube Studio.');
    }
}
