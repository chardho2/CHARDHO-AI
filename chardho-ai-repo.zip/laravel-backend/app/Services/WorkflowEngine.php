<?php

namespace App\Services;

use App\Models\AutomationWorkflow;
use App\Models\Business;
use App\Models\EmailCampaign;
use App\Models\Lead;
use App\Models\Notification;
use App\Models\WorkflowRun;
use App\Support\Logic;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WorkflowEngine
{
    public const TRIGGERS = ['new_business', 'content_request', 'new_lead', 'scheduled', 'approved_post', 'customer_enquiry', 'campaign_complete'];
    public const ACTIONS = ['start_agent', 'generate_content', 'create_draft', 'notify', 'schedule_approved', 'prepare_email', 'update_crm', 'generate_report', 'n8n_webhook'];
    public const OPS = ['eq', 'neq', 'gt', 'lt', 'contains', 'exists'];

    public const TEMPLATES = [
        ['name' => 'Welcome strategy on onboarding', 'trigger' => 'new_business', 'graph' => ['steps' => [
            ['id' => 'intel', 'action' => 'start_agent', 'params' => ['agent' => 'marketing_manager', 'request' => 'Create a business intelligence report for this new business.']],
            ['id' => 'plan', 'action' => 'generate_content', 'params' => ['agent' => 'social_media_manager', 'request' => 'Create a 7-day starter content plan with one post per day.']],
            ['id' => 'tell', 'action' => 'notify', 'params' => ['title' => 'Your strategy and starter content are ready for review']]]]],
        ['name' => 'Weekly content drafts', 'trigger' => 'scheduled', 'graph' => ['schedule' => ['everyHours' => 168], 'steps' => [
            ['id' => 'weekly', 'action' => 'generate_content', 'params' => ['agent' => 'social_media_manager', 'request' => "Create this week's posts for all platforms."]],
            ['id' => 'tell', 'action' => 'notify', 'params' => ['title' => 'New weekly drafts are waiting in your approval center']]]]],
        ['name' => 'New lead follow-up draft', 'trigger' => 'new_lead', 'graph' => ['steps' => [
            ['id' => 'draft', 'action' => 'start_agent', 'params' => ['agent' => 'lead_gen', 'request' => 'Draft a permission-based follow-up message for the new lead: ${trigger.businessName}']],
            ['id' => 'crm', 'action' => 'update_crm', 'params' => ['leadId' => '${trigger.leadId}', 'notes' => 'Follow-up draft prepared by AI'], 'condition' => ['path' => 'trigger.leadId', 'op' => 'exists']]]]],
    ];

    public function __construct(private Orchestrator $orch, private ApprovalService $approvals, private ContentService $content) {}

    /** Validate a workflow graph. Unknown actions are rejected (no arbitrary execution). */
    public static function validateGraph(array $g): array
    {
        $steps = $g['steps'] ?? null;
        if (!is_array($steps) || count($steps) < 1 || count($steps) > 30) throw new \InvalidArgumentException('graph.steps must contain 1-30 steps');
        foreach ($steps as $s) {
            if (empty($s['id']) || !in_array($s['action'] ?? '', self::ACTIONS, true)) throw new \InvalidArgumentException('Invalid step action');
            if (isset($s['condition']) && !in_array($s['condition']['op'] ?? '', self::OPS, true)) throw new \InvalidArgumentException('Invalid condition operator');
        }
        return $g;
    }

    private function exec(array $step, array &$ctx, int $userId, string $businessId): void
    {
        $p = array_map(fn ($v) => Logic::template($v, $ctx), $step['params'] ?? []);
        $business = Business::where('user_id', $userId)->findOrFail($businessId);
        switch ($step['action']) {
            case 'start_agent':
            case 'generate_content':
            case 'generate_report':
                $agent = $step['action'] === 'generate_report' ? 'analytics_agent' : ($step['action'] === 'generate_content' ? ($p['agent'] ?? 'social_media_manager') : (string) ($p['agent'] ?? ''));
                $t = $this->orch->runAgent($userId, $business, $agent, ['request' => (string) ($p['request'] ?? 'Run your standard task')]);
                if ($t->status !== 'SUCCEEDED') throw new \RuntimeException($t->error ?: 'agent failed');
                $ctx[$step['id']] = ['taskId' => $t->id, 'summary' => $t->output['summary'] ?? '', 'contentIds' => $t->output['savedContentIds'] ?? []];
                return;
            case 'create_draft':
                $c = $this->content->create($userId, $businessId, ['type' => (string) ($p['type'] ?? 'social_post'), 'platform' => $p['platform'] ?? null, 'title' => $p['title'] ?? null, 'body' => (string) ($p['body'] ?? ''), 'hashtags' => $p['hashtags'] ?? []]);
                $ctx[$step['id']] = ['contentIds' => [$c->id]];
                return;
            case 'notify':
                Notification::create(['user_id' => $userId, 'title' => (string) ($p['title'] ?? 'Workflow notification'), 'body' => $p['body'] ?? null]);
                return;
            case 'schedule_approved':
                // Never approves. Fails visibly if a human has not already approved the content.
                $this->approvals->schedule($userId, (string) $p['contentId'], !empty($p['runAt']) ? new \DateTimeImmutable($p['runAt']) : null);
                return;
            case 'prepare_email':
                $e = EmailCampaign::create(['user_id' => $userId, 'business_id' => $businessId, 'name' => (string) ($p['name'] ?? 'Workflow email'), 'subject' => (string) ($p['subject'] ?? ''), 'body' => (string) ($p['body'] ?? ''), 'status' => 'draft']);
                $ctx[$step['id']] = ['emailCampaignId' => $e->id];
                return;
            case 'update_crm':
                $upd = array_filter(['status' => $p['status'] ?? null, 'notes' => $p['notes'] ?? null]);
                if (!Lead::where('user_id', $userId)->where('id', (string) ($p['leadId'] ?? ''))->update($upd)) throw new \RuntimeException('lead not found');
                return;
            case 'n8n_webhook':
                $url = config('chardho.n8n.webhook_url'); $secret = config('chardho.n8n.secret');
                if (!$url || !$secret) throw new \RuntimeException('n8n is not configured');
                $body = json_encode(['businessId' => $businessId, 'step' => $step['id'], 'data' => $p, 'context' => $ctx]);
                Http::timeout(30)->withHeaders(['x-chardho-signature' => hash_hmac('sha256', $body, $secret), 'content-type' => 'application/json'])->withBody($body, 'application/json')->post($url)->throw();
                return;
        }
    }

    /** Advance a run step by step. Honours pause between steps; retries each step up to 3 times. */
    public function execute(string $runId): void
    {
        $claimed = WorkflowRun::where('id', $runId)->whereIn('status', ['QUEUED', 'RUNNING'])->update(['status' => 'RUNNING', 'started_at' => now()]);
        if (!$claimed) return;
        $run = WorkflowRun::with('workflow')->findOrFail($runId);
        $graph = self::validateGraph($run->workflow->graph);
        $logs = $run->logs ?? [];
        $ctx = ['trigger' => $run->trigger_data ?? []];
        $n = count($graph['steps']);
        for ($i = $run->step_index; $i < $n; $i++) {
            $wf = AutomationWorkflow::withTrashed()->find($run->workflow_id);
            if (!$wf || $wf->trashed() || !$wf->enabled) {
                $run->update(['status' => 'FAILED', 'error' => 'Workflow disabled', 'finished_at' => now(), 'logs' => $logs]);
                return;
            }
            if ($wf->paused) { $run->update(['status' => 'PAUSED', 'step_index' => $i, 'logs' => $logs]); return; }
            $step = $graph['steps'][$i];
            if (!empty($step['condition']) && !Logic::condition($step['condition'], $ctx)) {
                $logs[] = ['at' => now()->toIso8601String(), 'step' => $step['id'], 'status' => 'skipped', 'message' => 'condition false'];
                continue;
            }
            $ok = false; $err = '';
            for ($attempt = 1; $attempt <= 3 && !$ok; $attempt++) {
                try { $this->exec($step, $ctx, $run->user_id, $wf->business_id); $ok = true; $logs[] = ['at' => now()->toIso8601String(), 'step' => $step['id'], 'status' => 'ok']; }
                catch (\Throwable $e) { $err = $e->getMessage(); Log::warning('workflow step failed', ['run' => $runId, 'step' => $step['id'], 'attempt' => $attempt, 'err' => $err]); usleep(500_000 * $attempt); }
            }
            $run->update(['step_index' => $i + 1, 'logs' => $logs]);
            if (!$ok) {
                $logs[] = ['at' => now()->toIso8601String(), 'step' => $step['id'], 'status' => 'error', 'message' => $err];
                $run->update(['status' => 'FAILED', 'error' => "{$step['id']}: $err", 'finished_at' => now(), 'logs' => $logs]);
                Notification::create(['user_id' => $run->user_id, 'title' => "Workflow \"{$wf->name}\" failed", 'body' => mb_substr("{$step['id']}: $err", 0, 300)]);
                return;
            }
        }
        $run->update(['status' => 'SUCCEEDED', 'finished_at' => now(), 'logs' => $logs, 'step_index' => $n]);
    }

    public function fire(int $userId, string $businessId, string $trigger, array $data = []): array
    {
        $runs = [];
        foreach (AutomationWorkflow::where('user_id', $userId)->where('business_id', $businessId)->where('trigger', $trigger)->where('enabled', true)->get() as $w) {
            $runs[] = WorkflowRun::create(['workflow_id' => $w->id, 'user_id' => $userId, 'trigger_data' => $data, 'logs' => [], 'status' => $w->paused ? 'PAUSED' : 'QUEUED']);
        }
        return $runs;
    }
}
