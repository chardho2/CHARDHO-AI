<?php

namespace App\Services;

use App\Models\Approval;
use App\Models\ContentItem;
use App\Models\Notification;
use App\Models\PublishingJob;
use App\Models\SocialAccount;
use App\Support\Logic;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * The mandatory approval engine:
 *   DRAFT -> QUALITY_CHECKED -> PENDING_APPROVAL -> APPROVED -> SCHEDULED -> PUBLISHING -> PUBLISHED
 * Only authenticated humans reach approve(); agents and workflows never do.
 */
class ApprovalService
{
    private const MAX_ATTEMPTS = 3;

    private function owned(int $userId, string $id): ContentItem
    {
        $c = ContentItem::where('user_id', $userId)->find($id);
        if (!$c) throw new ModelNotFoundException('Content not found');
        return $c;
    }

    public function submit(int $userId, string $id): ContentItem
    {
        $c = $this->owned($userId, $id);
        if (!in_array($c->status, ['DRAFT', 'QUALITY_CHECKED'])) throw new HttpException(409, "Cannot submit content in status {$c->status}");
        $v = $c->versions()->orderByDesc('version')->first();
        $qc = Logic::quality($v->body, $c->platform);
        if (!$qc['ok']) throw new HttpException(422, 'Quality check failed: ' . implode('; ', $qc['issues']));
        $c->update(['status' => 'PENDING_APPROVAL']);
        return $c;
    }

    public function approve(int $userId, string $id, string $accountId, ?\DateTimeInterface $scheduledFor = null): Approval
    {
        return DB::transaction(function () use ($userId, $id, $accountId, $scheduledFor) {
            $c = ContentItem::where('user_id', $userId)->lockForUpdate()->find($id) ?? throw new ModelNotFoundException('Content not found');
            if ($c->status !== 'PENDING_APPROVAL') throw new HttpException(409, 'Content must be in review (PENDING_APPROVAL) to approve');
            $acct = SocialAccount::where('user_id', $userId)->where('business_id', $c->business_id)->find($accountId) ?? throw new ModelNotFoundException('Social account not found');
            if ($c->platform && $c->platform !== $acct->platform) throw new HttpException(422, "Content is for {$c->platform} but account is {$acct->platform}");
            $v = $c->versions()->orderByDesc('version')->first();
            if ($v->version !== $c->current_version) throw new HttpException(409, 'Content changed; reload and review the latest version');
            if ($scheduledFor && $scheduledFor->getTimestamp() < time() - 60) throw new HttpException(422, 'scheduledFor is in the past');
            Approval::where('content_id', $id)->whereNull('invalidated_at')->update(['invalidated_at' => now(), 'invalid_reason' => 'Superseded by new approval']);
            $a = Approval::create(['content_id' => $id, 'version' => $v->version, 'content_hash' => $v->content_hash, 'social_account_id' => $accountId, 'approved_by_id' => $userId, 'approved_at' => now(), 'scheduled_for' => $scheduledFor]);
            $c->update(['status' => 'APPROVED']);
            Support::audit($userId, 'content.approve', 'ContentItem', $id, ['version' => $v->version, 'socialAccountId' => $accountId]);
            return $a;
        });
    }

    /** One job per (content, version, account): the unique idempotency key blocks duplicate publishing. */
    public function schedule(int $userId, string $id, ?\DateTimeInterface $runAt = null): PublishingJob
    {
        return DB::transaction(function () use ($userId, $id, $runAt) {
            $c = ContentItem::where('user_id', $userId)->lockForUpdate()->find($id) ?? throw new ModelNotFoundException('Content not found');
            $ap = Approval::where('content_id', $id)->whereNull('invalidated_at')->orderByDesc('approved_at')->first();
            if (!$ap || $c->status !== 'APPROVED') throw new HttpException(409, 'Content has no valid approval. Approve the latest version first.');
            $v = $c->versions()->orderByDesc('version')->first();
            if ($ap->content_hash !== $v->content_hash) throw new HttpException(409, 'Approval does not match current content version');
            $when = $runAt ?? $ap->scheduled_for ?? now();
            $key = "{$id}:{$ap->version}:{$ap->social_account_id}";
            $existing = PublishingJob::where('idempotency_key', $key)->lockForUpdate()->first();
            if ($existing && $existing->status !== 'CANCELLED') {
                throw new HttpException(409, 'Already ' . ($existing->status === 'SUCCEEDED' ? 'published' : 'scheduled') . ' (duplicate publishing prevented)');
            }
            $job = $existing
                ? tap($existing)->update(['status' => 'PENDING', 'run_at' => $when, 'error' => null, 'approval_id' => $ap->id, 'attempts' => 0])
                : PublishingJob::create(['content_id' => $id, 'approval_id' => $ap->id, 'social_account_id' => $ap->social_account_id, 'idempotency_key' => $key, 'run_at' => $when]);
            $c->update(['status' => 'SCHEDULED']);
            Support::audit($userId, 'content.schedule', 'PublishingJob', $job->id, ['runAt' => $when]);
            return $job->fresh();
        });
    }

    public function cancel(int $userId, string $id): void
    {
        $c = $this->owned($userId, $id);
        $n = PublishingJob::where('content_id', $id)->where('status', 'PENDING')->update(['status' => 'CANCELLED', 'error' => 'Cancelled by user']);
        if (!$n && $c->status === 'PUBLISHED') throw new HttpException(409, 'Already published');
        Approval::where('content_id', $id)->whereNull('invalidated_at')->update(['invalidated_at' => now(), 'invalid_reason' => 'Cancelled by user']);
        $c->update(['status' => $c->status === 'PUBLISHED' ? 'PUBLISHED' : 'CANCELLED']);
        Support::audit($userId, 'content.cancel', 'ContentItem', $id);
    }

    private function freshToken(SocialAccount $a): string
    {
        if ($a->expires_at && $a->expires_at->getTimestamp() - time() < 120 && $a->refresh_token_enc) {
            $cfg = Platforms::oauth($a->platform);
            $req = Http::asForm();
            $body = ['grant_type' => 'refresh_token', 'refresh_token' => Crypt::decryptString($a->refresh_token_enc), 'client_id' => $cfg['clientId']];
            if ($cfg['clientSecret']) {
                if ($a->platform === 'X') $req = $req->withBasicAuth($cfg['clientId'], $cfg['clientSecret']); else $body['client_secret'] = $cfg['clientSecret'];
            }
            $r = $req->post($cfg['tokenUrl'], $body);
            if (!$r->ok() || !$r->json('access_token')) throw new \RuntimeException('Token refresh failed: ' . mb_substr($r->body(), 0, 200));
            $a->update(['access_token_enc' => Crypt::encryptString($r->json('access_token')), 'refresh_token_enc' => $r->json('refresh_token') ? Crypt::encryptString($r->json('refresh_token')) : $a->refresh_token_enc, 'expires_at' => $r->json('expires_in') ? now()->addSeconds($r->json('expires_in')) : null]);
            return $r->json('access_token');
        }
        return Crypt::decryptString($a->access_token_enc);
    }

    /**
     * Execute one job. The PENDING->IN_PROGRESS claim is a single atomic UPDATE, and approval + content hash are
     * re-verified at the last moment, so an edit racing the worker can never publish stale or unapproved content.
     */
    public function runJob(string $jobId): string
    {
        $claimed = PublishingJob::where('id', $jobId)->where('status', 'PENDING')->where('run_at', '<=', now())->update(['status' => 'IN_PROGRESS', 'attempts' => DB::raw('attempts + 1')]);
        if (!$claimed) return 'skipped';
        $job = PublishingJob::with(['approval', 'account', 'content'])->findOrFail($jobId);
        $content = $job->content;
        $v = $content->versions()->orderByDesc('version')->first();

        $fail = function (string $error, mixed $raw = null, bool $retryable = false) use ($job, $content) {
            $retry = $retryable && $job->attempts < self::MAX_ATTEMPTS;
            $job->update(['status' => $retry ? 'PENDING' : 'FAILED', 'run_at' => $retry ? now()->addMinutes(2 ** $job->attempts) : $job->run_at, 'error' => $error, 'api_response' => $raw]);
            if (!$retry) {
                $content->update(['status' => 'FAILED']);
                Notification::create(['user_id' => $content->user_id, 'title' => 'Publishing failed', 'body' => mb_substr(($content->title ?? $content->type) . ': ' . $error, 0, 220)]);
            }
            return $retry ? 'retry' : 'failed';
        };

        if ($job->approval->invalidated_at || $job->approval->content_hash !== $v->content_hash || $job->approval->version !== $v->version) {
            $job->update(['status' => 'CANCELLED', 'error' => 'Approval invalid or content changed']);
            return 'skipped';
        }
        try {
            $content->update(['status' => 'PUBLISHING']);
            $token = $this->freshToken($job->account);
            $img = !empty($v->media_asset_ids[0]) ? rtrim(config('chardho.api_url'), '/') . '/media/' . $v->media_asset_ids[0] : null;
            $res = Platforms::publish($job->account->platform, $v->body, $v->hashtags ?? [], $img, $token, $job->account->external_id);
            DB::transaction(function () use ($job, $content, $res) {
                $job->update(['status' => 'SUCCEEDED', 'external_post_id' => $res['postId'], 'api_response' => $res['raw'], 'error' => null]);
                $content->update(['status' => 'PUBLISHED']);
            });
            return 'published';
        } catch (\Throwable $e) {
            Log::warning('publish failed', ['job' => $jobId, 'err' => $e->getMessage()]);
            $raw = method_exists($e, 'response') && $e->response ? ($e->response->json() ?? ['body' => $e->response->body()]) : ['message' => $e->getMessage()];
            // 4xx is not retryable; an ambiguous timeout is NOT retried either, to avoid double posting.
            $status = method_exists($e, 'response') && $e->response ? $e->response->status() : 0;
            return $fail(mb_substr($e->getMessage(), 0, 500), $raw, $status >= 500);
        }
    }

    public function runDue(int $limit = 20): int
    {
        $ids = PublishingJob::where('status', 'PENDING')->where('run_at', '<=', now())->orderBy('run_at')->limit($limit)->pluck('id');
        foreach ($ids as $id) $this->runJob($id);
        return $ids->count();
    }
}
