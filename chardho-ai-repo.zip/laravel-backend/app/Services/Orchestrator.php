<?php

namespace App\Services;

use App\Models\AgentTask;
use App\Models\AiAgent;
use App\Models\AnalyticsSnapshot;
use App\Models\Business;
use App\Models\Influencer;
use App\Models\Lead;
use App\Support\Logic;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Central orchestrator: plans which agents to use, runs them in order (each sees the previous
 * agents' summaries), validates input/output, retries, and records tasks + usage.
 * Agents can only create DRAFT / QUALITY_CHECKED content. They have no path to approve or publish.
 */
class Orchestrator
{
    private const MAX_ATTEMPTS = 3;

    public function __construct(private ProviderManager $providers, private ContentService $content) {}

    public function plan(string $request): array
    {
        $lower = ' ' . mb_strtolower($request) . ' ';
        $byKeyword = [];
        foreach (AgentRegistry::all() as $a) {
            foreach ($a['keywords'] as $k) {
                if (str_contains($lower, $k)) { $byKeyword[] = $a['key']; break; }
            }
        }
        try {
            $list = collect(AgentRegistry::all())->map(fn ($a) => "- {$a['key']}: {$a['description']}")->implode("\n");
            $r = $this->providers->generate('You route marketing requests to specialist agents. Output JSON {"agents": string[]} with 1-4 keys.', "Agents:\n$list\n\nRequest: $request", true, ['text', 'json']);
            $picked = array_values(array_filter(Logic::parseJsonLoose($r['text'])['agents'] ?? [], fn ($k) => is_string($k) && AgentRegistry::get($k)));
            if ($picked) {
                return array_slice(array_values(array_unique($picked)), 0, 4);
            }
        } catch (\Throwable $e) {
            Log::warning('planner failed, using keyword routing', ['err' => $e->getMessage()]);
        }
        return array_slice($byKeyword ?: ['marketing_manager'], 0, 4);
    }

    private function context(array $def, Business $b, int $userId): array
    {
        $ctx = [];
        $tools = $def['tools'];
        if (in_array('read_business', $tools)) {
            $ctx['business'] = $b->only(['name', 'website', 'industry', 'description', 'products_services', 'location', 'target_audience', 'objectives', 'competitors', 'languages']);
        }
        if (in_array('read_influencers', $tools)) {
            $ctx['influencers'] = Influencer::where('business_id', $b->id)->where('user_id', $userId)->limit(50)->get(['name', 'platform', 'handle', 'niche', 'country', 'followers', 'engagement', 'metrics_source'])->toArray();
        }
        if (in_array('read_leads', $tools)) {
            $ctx['leads'] = Lead::where('business_id', $b->id)->where('user_id', $userId)->limit(50)->get(['source', 'industry', 'status', 'score'])->toArray();
        }
        if (in_array('read_analytics', $tools)) {
            $ctx['analytics'] = AnalyticsSnapshot::where('business_id', $b->id)->where('user_id', $userId)->orderByDesc('captured_at')->limit(100)->get(['platform', 'metric', 'value', 'captured_at', 'source'])->toArray();
        }
        return $ctx;
    }

    private function persist(array $def, array $out, string $taskId, Business $b, int $userId, array $input): array
    {
        $saved = [];
        if (in_array('save_drafts', $def['tools']) && !empty($out['drafts'])) {
            foreach ($out['drafts'] as $d) {
                $item = $this->content->create($userId, $b->id, [
                    'type' => $d['type'], 'platform' => $d['platform'], 'title' => $d['title'], 'body' => $d['body'], 'hashtags' => $d['hashtags'],
                    'language' => $input['language'] ?? ($b->languages[0] ?? 'en'), 'tone' => $input['tone'] ?? null, 'audience' => $input['audience'] ?? null, 'created_by_agent' => $def['key'],
                ]);
                $saved[] = $item->id;
            }
        }
        if (in_array('save_intelligence', $def['tools']) && !empty($out['sections'])) {
            $b->update(['intelligence' => ['generatedAt' => now()->toIso8601String(), 'summary' => $out['summary'], 'sections' => $out['sections'], 'notes' => $out['notes'] ?? [], 'taskId' => $taskId]]);
        }
        return $saved;
    }

    public function runAgent(int $userId, Business $business, string $agentKey, array $input, ?string $parentId = null): AgentTask
    {
        $def = AgentRegistry::get($agentKey) ?? throw new HttpException(400, "Unknown agent $agentKey");
        $row = AiAgent::where('key', $agentKey)->first();
        if ($row && !$row->enabled) {
            throw new HttpException(403, "Agent {$def['name']} is currently disabled by the administrator");
        }
        $input += ['priorOutputs' => []];
        Support::assertFairUse($userId);

        $task = AgentTask::create(['user_id' => $userId, 'business_id' => $business->id, 'agent_key' => $agentKey, 'parent_id' => $parentId, 'input' => $input, 'status' => 'RUNNING', 'started_at' => now()]);
        $system = $row?->system_prompt ?? $def['systemPrompt'];
        $lastErr = '';
        for ($attempt = 1; $attempt <= self::MAX_ATTEMPTS; $attempt++) {
            try {
                $task->update(['attempts' => $attempt]);
                $prompt = implode("\n\n", array_filter([
                    'Request: ' . $input['request'],
                    !empty($input['language']) ? 'Language: ' . $input['language'] : null,
                    !empty($input['tone']) ? 'Tone: ' . $input['tone'] : null,
                    !empty($input['audience']) ? 'Audience: ' . $input['audience'] : null,
                    !empty($input['length']) ? 'Length: ' . $input['length'] : null,
                    "Context (authoritative, do not contradict):\n" . json_encode($this->context($def, $business, $userId), JSON_UNESCAPED_UNICODE),
                    $input['priorOutputs'] ? "Outputs from collaborating agents:\n" . json_encode($input['priorOutputs']) : null,
                    $lastErr ? "Your previous answer was rejected: $lastErr. Return valid JSON in the required shape." : null,
                ]));
                $res = $this->providers->generate($system, $prompt, true, ['text', 'json']);
                $out = Logic::normalizeAgentOutput(Logic::parseJsonLoose($res['text']));
                $saved = $this->persist($def, $out, $task->id, $business, $userId, $input);
                Support::recordUsage($userId, 'ai_request', $agentKey, $res['provider'], $res['model'], $res['tokensIn'], $res['tokensOut']);
                $task->update(['status' => 'SUCCEEDED', 'output' => $out + ['savedContentIds' => $saved], 'provider' => $res['provider'], 'model' => $res['model'], 'tokens_in' => $res['tokensIn'], 'tokens_out' => $res['tokensOut'], 'finished_at' => now(), 'error' => null]);
                return $task->fresh();
            } catch (\Throwable $e) {
                $lastErr = mb_substr($e->getMessage(), 0, 300);
                Log::warning('agent attempt failed', ['task' => $task->id, 'attempt' => $attempt, 'err' => $lastErr]);
                if ($e instanceof HttpException && $e->getStatusCode() === 503) { break; } // provider exhaustion: retrying will not help
            }
        }
        $task->update(['status' => 'FAILED', 'error' => $lastErr, 'finished_at' => now()]);
        return $task->fresh();
    }

    /** @return array{agents:string[],tasks:AgentTask[]} */
    public function orchestrate(int $userId, Business $business, array $input, ?array $agents = null): array
    {
        $agents = $agents ?: $this->plan($input['request']);
        Support::assertFairUse($userId, count($agents));
        $prior = []; $tasks = []; $parent = null;
        foreach ($agents as $key) {
            $t = $this->runAgent($userId, $business, $key, $input + ['priorOutputs' => $prior], $parent);
            $parent ??= $t->id;
            $tasks[] = $t;
            if ($t->status === 'SUCCEEDED') {
                $prior[] = ['agent' => $key, 'summary' => mb_substr((string) ($t->output['summary'] ?? ''), 0, 800)];
            }
        }
        return ['agents' => $agents, 'tasks' => $tasks];
    }
}
