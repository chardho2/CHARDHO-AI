<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Business;
use App\Models\Setting;
use App\Models\UsageRecord;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Small helpers shared by controllers and services. */
final class Support
{
    public static function audit(?int $userId, string $action, ?string $entity = null, ?string $entityId = null, array $meta = []): void
    {
        try {
            AuditLog::create(['user_id' => $userId, 'action' => $action, 'entity' => $entity, 'entity_id' => $entityId, 'meta' => $meta ?: null, 'ip' => request()?->ip()]);
        } catch (\Throwable) {
            // auditing must never break a request
        }
    }

    /** Tenant isolation: a business is only ever resolved through its owner. */
    public static function ownBusiness(int $userId, string $businessId): Business
    {
        $b = Business::where('user_id', $userId)->find($businessId);
        if (!$b) {
            throw new ModelNotFoundException('Business not found');
        }
        return $b;
    }

    public static function dailyLimit(): int
    {
        return (int) Setting::get('dailyAiRequestLimit', config('chardho.daily_ai_limit'));
    }

    public static function usageToday(int $userId): array
    {
        $since = now()->startOfDay();
        $used = UsageRecord::where('user_id', $userId)->where('kind', 'ai_request')->where('created_at', '>=', $since)->count();
        $limit = self::dailyLimit();
        return ['used' => $used, 'limit' => $limit, 'remaining' => max(0, $limit - $used), 'resetsAt' => $since->copy()->addDay()->toIso8601String()];
    }

    public static function assertFairUse(int $userId, int $units = 1): void
    {
        $u = self::usageToday($userId);
        if ($u['used'] + $units > $u['limit']) {
            throw new HttpException(429, "Daily fair-use limit reached ({$u['limit']} AI requests/day). Resets at {$u['resetsAt']}.");
        }
    }

    public static function recordUsage(int $userId, string $kind, ?string $agent = null, ?string $provider = null, ?string $model = null, int $in = 0, int $out = 0): void
    {
        UsageRecord::create(['user_id' => $userId, 'kind' => $kind, 'agent_key' => $agent, 'provider' => $provider, 'model' => $model, 'tokens_in' => $in, 'tokens_out' => $out]);
    }
}
