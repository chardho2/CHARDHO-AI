<?php

namespace App\Services;

use App\Models\ApiProviderCost;
use App\Models\ProviderConfig;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Picks an AI provider by priority, capability, daily limit and availability.
 * Paid providers are skipped unless ALLOW_PAID_PROVIDERS=true. Keys live encrypted in the DB (or in .env).
 */
class ProviderManager
{
    /** USD per 1M tokens [in, out] for paid providers. */
    private const PRICING = ['openai' => [0.15, 0.60]];

    public static function ensureDefaults(): void
    {
        $c = config('chardho.providers');
        foreach ([
            ['ollama', 'Ollama (local)', $c['ollama']['model'], false, 10, ['text', 'json']],
            ['gemini', 'Google Gemini', $c['gemini']['model'], false, 20, ['text', 'json']],
            ['openai', 'OpenAI', $c['openai']['model'], true, 90, ['text', 'json', 'image']],
        ] as [$key, $name, $model, $paid, $prio, $caps]) {
            ProviderConfig::firstOrCreate(['key' => $key], ['name' => $name, 'model' => $model, 'paid' => $paid, 'priority' => $prio, 'capabilities' => $caps]);
        }
    }

    /** @return array{text:string,tokensIn:int,tokensOut:int,provider:string,model:string} */
    public function generate(string $system, string $prompt, bool $json = false, array $need = ['text']): array
    {
        $errors = [];
        foreach (ProviderConfig::where('enabled', true)->orderBy('priority')->get() as $cfg) {
            if (($cfg->paid && !config('chardho.allow_paid')) || array_diff($need, $cfg->capabilities ?? [])) {
                continue;
            }
            if ($cfg->daily_limit && ApiProviderCost::where('provider', $cfg->key)->where('created_at', '>=', now()->startOfDay())->count() >= $cfg->daily_limit) {
                $errors[] = "{$cfg->key}: daily limit reached";
                continue;
            }
            $key = $cfg->api_key_enc ? Crypt::decryptString($cfg->api_key_enc) : (config("chardho.providers.{$cfg->key}.api_key"));
            try {
                if (!$this->available($cfg->key, $key, $cfg->base_url)) {
                    $errors[] = "{$cfg->key}: unavailable";
                    continue;
                }
                $out = match ($cfg->key) {
                    'ollama' => $this->ollama($cfg, $system, $prompt, $json),
                    'gemini' => $this->gemini($cfg, $key, $system, $prompt, $json),
                    'openai' => $this->openai($cfg, $key, $system, $prompt, $json),
                    default => throw new \RuntimeException('no adapter'),
                };
                $p = self::PRICING[$cfg->key] ?? [0, 0];
                $cost = $cfg->paid ? ($out['tokensIn'] * $p[0] + $out['tokensOut'] * $p[1]) / 1_000_000 : 0;
                ApiProviderCost::create(['provider' => $cfg->key, 'model' => $cfg->model, 'tokens_in' => $out['tokensIn'], 'tokens_out' => $out['tokensOut'], 'cost_usd' => $cost]);
                return $out;
            } catch (\Throwable $e) {
                Log::warning('provider failed, trying next', ['provider' => $cfg->key, 'err' => $e->getMessage()]);
                $errors[] = "{$cfg->key}: " . $e->getMessage();
            }
        }
        throw new HttpException(503, 'No AI provider is currently available. Free capacity may be exhausted; try again later. ' . implode(' | ', $errors));
    }

    private function available(string $key, ?string $apiKey, ?string $baseUrl): bool
    {
        if ($key === 'ollama') {
            try { return Http::timeout(2)->get(($baseUrl ?: config('chardho.providers.ollama.base_url')) . '/api/tags')->ok(); } catch (\Throwable) { return false; }
        }
        return !empty($apiKey);
    }

    private function ollama(ProviderConfig $cfg, string $system, string $prompt, bool $json): array
    {
        $r = Http::timeout(120)->post(($cfg->base_url ?: config('chardho.providers.ollama.base_url')) . '/api/chat', array_filter([
            'model' => $cfg->model, 'stream' => false, 'format' => $json ? 'json' : null,
            'messages' => [['role' => 'system', 'content' => $system], ['role' => 'user', 'content' => $prompt]],
        ]))->throw()->json();
        return ['text' => $r['message']['content'] ?? '', 'tokensIn' => $r['prompt_eval_count'] ?? 0, 'tokensOut' => $r['eval_count'] ?? 0, 'provider' => 'ollama', 'model' => $cfg->model];
    }

    private function gemini(ProviderConfig $cfg, string $key, string $system, string $prompt, bool $json): array
    {
        $r = Http::timeout(120)->withHeaders(['x-goog-api-key' => $key])->post("https://generativelanguage.googleapis.com/v1beta/models/{$cfg->model}:generateContent", [
            'systemInstruction' => ['parts' => [['text' => $system]]],
            'contents' => [['role' => 'user', 'parts' => [['text' => $prompt]]]],
            'generationConfig' => array_filter(['temperature' => 0.7, 'responseMimeType' => $json ? 'application/json' : null]),
        ])->throw()->json();
        $text = collect($r['candidates'][0]['content']['parts'] ?? [])->pluck('text')->implode('');
        return ['text' => $text, 'tokensIn' => $r['usageMetadata']['promptTokenCount'] ?? 0, 'tokensOut' => $r['usageMetadata']['candidatesTokenCount'] ?? 0, 'provider' => 'gemini', 'model' => $cfg->model];
    }

    /** Also serves any OpenAI-compatible endpoint via base_url. */
    private function openai(ProviderConfig $cfg, string $key, string $system, string $prompt, bool $json): array
    {
        $r = Http::timeout(120)->withToken($key)->post(($cfg->base_url ?: 'https://api.openai.com/v1') . '/chat/completions', array_filter([
            'model' => $cfg->model, 'temperature' => 0.7, 'response_format' => $json ? ['type' => 'json_object'] : null,
            'messages' => [['role' => 'system', 'content' => $system], ['role' => 'user', 'content' => $prompt]],
        ]))->throw()->json();
        return ['text' => $r['choices'][0]['message']['content'] ?? '', 'tokensIn' => $r['usage']['prompt_tokens'] ?? 0, 'tokensOut' => $r['usage']['completion_tokens'] ?? 0, 'provider' => 'openai', 'model' => $cfg->model];
    }
}
