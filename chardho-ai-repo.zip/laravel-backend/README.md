# CHARDHO AI: Laravel backend

Drop-in PHP/Laravel 11 replacement for the Node backend. It keeps the same REST contract (paths, verbs, JSON shapes, `{error, details}` envelope, camelCase fields), so the existing React frontend works unchanged. Point its API base URL at this server.

## Status: read this first
This code was **written and statically checked only**: every file passes `php -l`, and the framework-free rules in `app/Support/Logic.php` pass `php tests/Unit/logic_check.php`. It has **not been booted**: Packagist was unreachable from the build sandbox, so Laravel could not be installed. No migration, route, controller or OAuth flow has been executed against a real database. Expect to fix small integration issues on first run, and run it against a throwaway database first. The Node backend in `../backend` is the tested reference (typechecked, 17 tests passing).

## Install
```bash
./install.sh ../chardho-laravel-app      # create-project + sanctum + overlay
cd ../chardho-laravel-app
# edit .env: DB_*, APP_URL, APP_FRONTEND_URL, OWNER_EMAIL, OWNER_PASSWORD (>=12 chars)
php artisan migrate --force && php artisan db:seed --force
php artisan serve
php artisan chardho:tick --loop          # worker; or use cron: * * * * * php artisan schedule:run
```
Requires PHP >= 8.2 and MySQL/Postgres/SQLite.

## What is in the overlay
| Area | Where |
|---|---|
| Schema (30 tables, ULID keys) | `database/migrations/2026_11_24_000000_create_chardho_tables.php` |
| Approval engine (versioning, hash re-check, idempotent jobs) | `app/Services/ApprovalService.php` |
| 13 agents + orchestrator | `AgentRegistry`, `Orchestrator` |
| AI providers (ollama, gemini; openai only if `ALLOW_PAID_PROVIDERS=true`) | `ProviderManager` |
| Workflows + n8n (HMAC) | `WorkflowEngine`, `AutomationController::n8n` |
| Social OAuth/publishing (official APIs) | `Platforms`, `SocialController` |
| Scheduler | `app/Console/Commands/Tick.php`, `routes/console.php` |
| Rules unit-checked without Laravel | `app/Support/Logic.php` |

## API parity
Same prefixes as Node: `/api/auth, users, businesses, agents, conversations, content, approvals, social, media, marketing, influencers, campaigns, automation, leads, email, seo, analytics, notifications, integrations, support, admin, usage`, plus public `GET /media/{id}` and `GET /health`. Auth is a Sanctum bearer token (12 h); `logout-all` revokes all tokens; disabled/deleted users are rejected on every request.

## Safety rules enforced in code
- Nothing publishes without a human approval bound to the content hash; any edit creates a new version and voids approvals and pending jobs.
- Agents can only create drafts. No path from agent output to publish.
- Paid providers are ignored unless the owner sets `ALLOW_PAID_PROVIDERS=true` and enables them.
- Influencer data is never invented: records need a `metricsSource` when numbers are given. Lead outreach requires a recorded consent basis and is draft-only (no bulk sending).
- Provider API keys are encrypted and write-only. Tenant isolation: every query is scoped by `user_id`.

## Known limits
- YouTube upload and video generation are not supported; Instagram posts need an image.
- Image generation only works with an owner-enabled paid OpenAI key; otherwise a creative brief is returned (`provider_unavailable`).
- Emails are drafts only; nothing is sent.
- Feature tests are not included, since they could not be run here.
