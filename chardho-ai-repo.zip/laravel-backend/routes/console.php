<?php

use Illuminate\Support\Facades\Schedule;

// Runs due publishing jobs, queued workflow runs and scheduled workflows. Needs the standard cron entry:
//   * * * * * cd /path/to/app && php artisan schedule:run >> /dev/null 2>&1
Schedule::command('chardho:tick')->everyMinute()->withoutOverlapping(10)->runInBackground();
