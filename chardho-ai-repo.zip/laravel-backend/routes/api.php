<?php

use App\Http\Controllers as C;
use Illuminate\Support\Facades\Route;

/*
 * Mirrors the Node API contract (same paths, verbs, JSON shapes) so the React frontend works unchanged.
 * Static segments are registered before {id} routes on purpose.
 */

Route::get('/health', fn () => ['status' => 'ok', 'time' => now()->toIso8601String()]);

// ---- Public ----
Route::prefix('auth')->group(function () {
    Route::middleware('throttle:10,1')->group(function () {
        Route::post('/register', [C\AuthController::class, 'register']);
        Route::post('/verify-email', [C\AuthController::class, 'verifyEmail']);
        Route::post('/login', [C\AuthController::class, 'login']);
        Route::post('/forgot-password', [C\AuthController::class, 'forgot']);
        Route::post('/reset-password', [C\AuthController::class, 'reset']);
    });
    Route::get('/google', [C\AuthController::class, 'google']);
    Route::get('/google/callback', [C\AuthController::class, 'googleCallback']);
});
Route::get('/social/callback/{platform}', [C\SocialController::class, 'callback']);   // identity from encrypted state
Route::post('/automation/webhook/n8n', [C\AutomationController::class, 'n8n']);        // HMAC-verified

// ---- Authenticated ----
Route::middleware(['auth:sanctum', 'active'])->group(function () {
    Route::post('/auth/logout-all', [C\AuthController::class, 'logoutAll']);
    Route::get('/auth/me', [C\AuthController::class, 'me']);

    Route::patch('/users/me', [C\UserController::class, 'update']);
    Route::get('/users/me/export', [C\UserController::class, 'export']);
    Route::delete('/users/me', [C\UserController::class, 'destroy']);

    Route::get('/businesses', [C\BusinessController::class, 'index']);
    Route::post('/businesses', [C\BusinessController::class, 'store']);
    Route::get('/businesses/{id}', [C\BusinessController::class, 'show']);
    Route::patch('/businesses/{id}', [C\BusinessController::class, 'update']);
    Route::delete('/businesses/{id}', [C\BusinessController::class, 'destroy']);

    Route::get('/agents', [C\AgentController::class, 'index']);
    Route::post('/agents/execute', [C\AgentController::class, 'execute']);
    Route::get('/agents/tasks', [C\AgentController::class, 'tasks']);
    Route::get('/agents/tasks/{id}', [C\AgentController::class, 'task']);

    Route::get('/conversations', [C\ConversationController::class, 'index']);
    Route::post('/conversations/message', [C\ConversationController::class, 'message']);
    Route::get('/conversations/{id}', [C\ConversationController::class, 'show']);

    Route::post('/marketing/intelligence', [C\MarketingController::class, 'intelligence']);
    Route::get('/marketing/intelligence/{businessId}', [C\MarketingController::class, 'showIntelligence']);
    Route::post('/seo/analyze', [C\MarketingController::class, 'seo']);
    Route::get('/usage', [C\MarketingController::class, 'usage']);

    Route::post('/content/generate/batch', [C\ContentController::class, 'batch']);
    Route::post('/content/generate', [C\ContentController::class, 'generate']);
    Route::get('/content', [C\ContentController::class, 'index']);
    Route::post('/content', [C\ContentController::class, 'store']);
    Route::get('/content/{id}', [C\ContentController::class, 'show']);
    Route::patch('/content/{id}', [C\ContentController::class, 'update']);
    Route::delete('/content/{id}', [C\ContentController::class, 'destroy']);

    Route::get('/approvals', [C\ApprovalController::class, 'index']);
    Route::post('/approvals/{id}/submit', [C\ApprovalController::class, 'submit']);
    Route::post('/approvals/{id}/approve', [C\ApprovalController::class, 'approve']);
    Route::post('/approvals/{id}/schedule', [C\ApprovalController::class, 'schedule']);
    Route::post('/approvals/{id}/cancel', [C\ApprovalController::class, 'cancel']);

    Route::get('/social/accounts', [C\SocialController::class, 'accounts']);
    Route::delete('/social/accounts/{id}', [C\SocialController::class, 'destroy']);
    Route::get('/social/connect/{platform}', [C\SocialController::class, 'connect']);
    Route::get('/social/publish', [C\SocialController::class, 'jobs']);
    Route::post('/social/publish', [C\SocialController::class, 'publish']);

    Route::get('/media', [C\MediaController::class, 'index']);
    Route::post('/media/upload', [C\MediaController::class, 'upload']);
    Route::post('/media/generate', [C\MediaController::class, 'generate']);
    Route::delete('/media/{id}', [C\MediaController::class, 'destroy']);

    Route::get('/leads/export', [C\LeadController::class, 'export']);
    Route::post('/leads/import', [C\LeadController::class, 'import']);
    Route::get('/leads', [C\LeadController::class, 'index']);
    Route::post('/leads', [C\LeadController::class, 'store']);
    Route::patch('/leads/{id}', [C\LeadController::class, 'update']);
    Route::delete('/leads/{id}', [C\LeadController::class, 'destroy']);
    Route::post('/leads/{id}/outreach', [C\LeadController::class, 'outreach']);

    Route::get('/influencers/outreach/list', [C\InfluencerController::class, 'outreachList']);
    Route::patch('/influencers/outreach/{id}', [C\InfluencerController::class, 'updateOutreach']);
    Route::get('/influencers', [C\InfluencerController::class, 'index']);
    Route::post('/influencers', [C\InfluencerController::class, 'store']);
    Route::delete('/influencers/{id}', [C\InfluencerController::class, 'destroy']);
    Route::post('/influencers/{id}/analyze', [C\InfluencerController::class, 'analyze']);
    Route::post('/influencers/{id}/outreach', [C\InfluencerController::class, 'outreach']);

    Route::get('/campaigns', [C\CampaignController::class, 'index']);
    Route::post('/campaigns', [C\CampaignController::class, 'store']);
    Route::patch('/campaigns/{id}', [C\CampaignController::class, 'update']);
    Route::get('/campaigns/{id}/report', [C\CampaignController::class, 'report']);

    Route::get('/automation/meta', [C\AutomationController::class, 'meta']);
    Route::get('/automation/runs', [C\AutomationController::class, 'runs']);
    Route::post('/automation/runs/{id}/resume', [C\AutomationController::class, 'resume']);
    Route::post('/automation/runs/{id}/retry', [C\AutomationController::class, 'retry']);
    Route::post('/automation/from-template', [C\AutomationController::class, 'fromTemplate']);
    Route::get('/automation', [C\AutomationController::class, 'index']);
    Route::post('/automation', [C\AutomationController::class, 'store']);
    Route::patch('/automation/{id}', [C\AutomationController::class, 'update']);
    Route::delete('/automation/{id}', [C\AutomationController::class, 'destroy']);
    Route::post('/automation/{id}/run', [C\AutomationController::class, 'run']);

    Route::get('/calendar', [C\CalendarController::class, 'index']);
    Route::post('/calendar/generate', [C\CalendarController::class, 'generate']);
    Route::post('/calendar', [C\CalendarController::class, 'store']);
    Route::delete('/calendar/{id}', [C\CalendarController::class, 'destroy']);

    Route::get('/email', [C\EmailController::class, 'index']);
    Route::post('/email/generate', [C\EmailController::class, 'generate']);
    Route::post('/email', [C\EmailController::class, 'store']);
    Route::delete('/email/{id}', [C\EmailController::class, 'destroy']);

    Route::get('/analytics', [C\AnalyticsController::class, 'summary']);
    Route::post('/analytics/collect', [C\AnalyticsController::class, 'collect']);

    Route::get('/notifications', [C\NotificationController::class, 'index']);
    Route::post('/notifications/read', [C\NotificationController::class, 'read']);
    Route::get('/integrations', [C\IntegrationController::class, 'index']);
    Route::get('/support', [C\SupportController::class, 'index']);
    Route::post('/support', [C\SupportController::class, 'store']);

    // ---- Admin (role matrix enforced per route + inside controller) ----
    Route::prefix('admin')->middleware('role:ADMIN')->group(function () {
        Route::get('/overview', [C\AdminController::class, 'overview']);
        Route::get('/server', [C\AdminController::class, 'server']);
        Route::get('/users', [C\AdminController::class, 'users']);
        Route::patch('/users/{id}', [C\AdminController::class, 'updateUser']);
        Route::get('/agents', [C\AdminController::class, 'agents']);
        Route::patch('/agents/{key}', [C\AdminController::class, 'updateAgent'])->middleware('role:SUPER_ADMIN');
        Route::get('/providers', [C\AdminController::class, 'providers']);
        Route::patch('/providers/{key}', [C\AdminController::class, 'updateProvider'])->middleware('role:SUPER_ADMIN');
        Route::post('/providers', [C\AdminController::class, 'createProvider'])->middleware('role:OWNER');
        Route::get('/settings', [C\AdminController::class, 'settings']);
        Route::put('/settings/{key}', [C\AdminController::class, 'putSetting'])->middleware('role:SUPER_ADMIN');
        Route::get('/tasks', [C\AdminController::class, 'tasks']);
        Route::get('/workflows/failed', [C\AdminController::class, 'failedWorkflows']);
        Route::get('/publishing/failed', [C\AdminController::class, 'failedPublishing']);
        Route::get('/audit', [C\AdminController::class, 'audit'])->middleware('role:SUPER_ADMIN');
        Route::get('/announcements', [C\AdminController::class, 'announcements']);
        Route::post('/announcements', [C\AdminController::class, 'createAnnouncement']);
        Route::patch('/announcements/{id}', [C\AdminController::class, 'updateAnnouncement']);
        Route::get('/tickets', [C\AdminController::class, 'tickets']);
        Route::patch('/tickets/{id}', [C\AdminController::class, 'updateTicket']);
        Route::get('/integrations', [C\AdminController::class, 'integrations']);
        Route::get('/analytics', [C\AdminController::class, 'analytics']);
    });
});
