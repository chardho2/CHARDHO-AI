#!/bin/sh
set -e
cd /var/www/html
[ -n "$APP_KEY" ] || { echo "APP_KEY is required (php artisan key:generate --show)"; exit 1; }
if [ "$RUN_MIGRATIONS" = "true" ]; then
  php artisan migrate --force
  php artisan db:seed --force
fi
php artisan config:cache
php artisan route:cache
exec "$@"
