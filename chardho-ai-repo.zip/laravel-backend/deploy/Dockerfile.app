# Build context: repo root (chardho-ai/). Builds Laravel 11 + the CHARDHO overlay into one PHP-FPM image.
FROM composer:2 AS build
WORKDIR /src
RUN composer create-project laravel/laravel app "^11.0" --prefer-dist --no-interaction --no-scripts \
 && cd app && composer require laravel/sanctum --no-interaction --no-scripts
COPY laravel-backend/app/ app/app/
COPY laravel-backend/bootstrap/ app/bootstrap/
COPY laravel-backend/config/ app/config/
COPY laravel-backend/database/ app/database/
COPY laravel-backend/routes/ app/routes/
RUN cd app && composer dump-autoload --optimize --no-scripts

FROM php:8.3-fpm-alpine
RUN apk add --no-cache icu-libs libzip-dev oniguruma-dev \
 && docker-php-ext-install pdo_mysql bcmath opcache mbstring zip
WORKDIR /var/www/html
COPY --from=build /src/app/ ./
COPY laravel-backend/deploy/entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh && mkdir -p storage/app/media storage/framework/{cache,sessions,views} storage/logs bootstrap/cache \
 && chown -R www-data:www-data storage bootstrap/cache
ENTRYPOINT ["/entrypoint.sh"]
CMD ["php-fpm"]
