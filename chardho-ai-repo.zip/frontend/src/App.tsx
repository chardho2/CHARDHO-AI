import { Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { useApp } from './ctx';
import { Login, OAuthComplete, Register, ResetPassword, VerifyEmail, Forgot } from './pages/Auth';
import { Dashboard, Businesses, Settings } from './pages/Core';
import { Studio, Approvals, Social, Calendar } from './pages/Content';
import { Influencers, Leads, Automation, Analytics, Email } from './pages/Work';
import { Admin } from './pages/Admin';

const NAV: [string, string][] = [
  ['/', 'Dashboard'], ['/businesses', 'Businesses'], ['/studio', 'Content Studio'], ['/approvals', 'Approval Center'], ['/calendar', 'Calendar'], ['/social', 'Social Accounts'],
  ['/influencers', 'Influencers'], ['/leads', 'Leads & CRM'], ['/email', 'Email'], ['/automation', 'Automation'], ['/analytics', 'Analytics'], ['/settings', 'Settings & Usage'],
];

export function App() {
  const { user, loading, logout, theme, toggleTheme, businesses, business, setBusinessId } = useApp();
  const loc = useLocation();
  if (loading) return <div className="center"><p>Loading…</p></div>;
  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} /><Route path="/forgot" element={<Forgot />} />
        <Route path="/verify-email" element={<VerifyEmail />} /><Route path="/reset-password" element={<ResetPassword />} /><Route path="/oauth-complete" element={<OAuthComplete />} />
        <Route path="*" element={<Navigate to="/login" state={{ from: loc.pathname }} replace />} />
      </Routes>
    );
  }
  const isAdmin = user.role !== 'USER';
  return (
    <div className="shell">
      <nav className="side" aria-label="Main">
        <div className="brand">CHARDHO <span>AI</span></div>
        <div className="tag">CREATE. AUTOMATE. PROMOTE. GROW.</div>
        {NAV.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>)}
        {isAdmin && <NavLink to="/admin">Admin</NavLink>}
        <div style={{ flex: 1 }} />
        <button className="secondary" onClick={toggleTheme} style={{ color: '#fff' }}>{theme === 'dark' ? 'Light theme' : 'Dark theme'}</button>
        <button className="secondary" onClick={logout} style={{ color: '#fff' }}>Log out</button>
      </nav>
      <main className="main">
        {businesses.length > 0 && (
          <div className="row" style={{ marginBottom: '1rem' }}>
            <label htmlFor="bizsel" style={{ margin: 0 }}>Business</label>
            <select id="bizsel" style={{ width: 'auto' }} value={business?.id} onChange={(e) => setBusinessId(e.target.value)}>
              {businesses.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
        )}
        <Routes>
          <Route path="/" element={<Dashboard />} /><Route path="/businesses" element={<Businesses />} />
          <Route path="/studio" element={<Studio />} /><Route path="/approvals" element={<Approvals />} /><Route path="/calendar" element={<Calendar />} />
          <Route path="/social" element={<Social />} /><Route path="/influencers" element={<Influencers />} /><Route path="/leads" element={<Leads />} />
          <Route path="/email" element={<Email />} /><Route path="/automation" element={<Automation />} /><Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
          {isAdmin && <Route path="/admin" element={<Admin />} />}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
