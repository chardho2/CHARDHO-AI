import { ReactNode, useEffect, useState } from 'react';

export const Badge = ({ s }: { s: string }) => <span className={`badge ${s}`}>{s.replace(/_/g, ' ')}</span>;
export const Alert = ({ kind = 'error', children }: { kind?: 'error' | 'ok' | 'warn'; children: ReactNode }) => <div role={kind === 'error' ? 'alert' : 'status'} className={`alert ${kind}`}>{children}</div>;
export const Card = ({ title, children, right }: { title?: string; children: ReactNode; right?: ReactNode }) => (
  <section className="card">{(title || right) && <div className="row" style={{ justifyContent: 'space-between' }}>{title && <h2>{title}</h2>}{right}</div>}{children}</section>
);
export const Field = ({ label, children }: { label: string; children: ReactNode }) => <div><label>{label}{children}</label></div>;

/** Tiny async-state helper: run an action, track busy/error/ok. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const run = async <T,>(fn: () => Promise<T>, okMsg = ''): Promise<T | undefined> => {
    setBusy(true); setError(''); setOk('');
    try { const r = await fn(); setOk(okMsg); return r; }
    catch (e) { setError((e as Error).message + ((e as any).details ? ` — ${JSON.stringify((e as any).details).slice(0, 200)}` : '')); }
    finally { setBusy(false); }
  };
  const msg = <>{error && <Alert>{error}</Alert>}{ok && <Alert kind="ok">{ok}</Alert>}</>;
  return { busy, run, msg, setError };
}

export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [tick, setTick] = useState(0);
  useEffect(() => { let live = true; setError(''); fn().then((d) => live && setData(d)).catch((e) => live && setError(e.message)); return () => { live = false; }; }, [...deps, tick]); // eslint-disable-line react-hooks/exhaustive-deps
  return { data, error, reload: () => setTick((t) => t + 1) };
}
