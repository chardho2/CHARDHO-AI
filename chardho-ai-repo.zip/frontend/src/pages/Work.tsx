import { FormEvent, useState } from 'react';
import { api, download } from '../api';
import { useApp } from '../ctx';
import { Badge, Card, useAction, useLoad } from '../ui';
import { NeedBusiness } from './Core';

const PLATFORMS = ['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X'];

export function Influencers() {
  const { business } = useApp(); const a = useAction(); const [q, setQ] = useState({ niche: '', country: '', platform: '', audience: '' }); const [out, setOut] = useState<any>(null);
  const qs = new URLSearchParams(Object.entries(q).filter(([, v]) => v) as [string, string][]).toString();
  const list = useLoad(() => (business ? api(`/influencers?businessId=${business.id}&${qs}`) : Promise.resolve(null)), [business?.id, qs]);
  const outreach = useLoad(() => api('/influencers/outreach/list'), []);
  if (!business) return <NeedBusiness />;
  const add = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const g = (k: string) => (f.get(k) as string) || undefined; const n = (k: string) => (f.get(k) ? Number(f.get(k)) : undefined);
    a.run(async () => { await api('/influencers', { body: { businessId: business.id, name: g('name'), platform: g('platform'), handle: g('handle'), profileUrl: g('profileUrl'), niche: g('niche'), country: g('country'), audience: g('audience'), followers: n('followers'), engagement: n('engagement'), metricsSource: g('metricsSource'), contactEmail: g('contactEmail') } }); list.reload(); (e.target as HTMLFormElement).reset(); }, 'Saved');
  };
  return (
    <>
      <h1>Influencer marketing</h1>
      <Card><p className="muted">CHARDHO AI never invents influencers, metrics or contact details. Add creators you found yourself (or via an authorised source) and record where the numbers came from; the AI then analyses fit and drafts outreach.</p></Card>
      <Card title="Search your influencer list">
        <div className="grid">
          {(['niche', 'country', 'audience'] as const).map((k) => <label key={k}>{k}<input value={q[k]} onChange={(e) => setQ({ ...q, [k]: e.target.value })} /></label>)}
          <label>platform<select value={q.platform} onChange={(e) => setQ({ ...q, platform: e.target.value })}><option value="">Any</option>{PLATFORMS.map((p) => <option key={p}>{p}</option>)}</select></label>
        </div>
      </Card>
      <Card title="Add influencer">
        <form onSubmit={add}><div className="grid">
          <label>Name<input name="name" required /></label><label>Platform<select name="platform">{PLATFORMS.map((p) => <option key={p}>{p}</option>)}</select></label>
          <label>Handle<input name="handle" required /></label><label>Profile URL<input name="profileUrl" type="url" /></label>
          <label>Niche<input name="niche" /></label><label>Country<input name="country" /></label><label>Audience category<input name="audience" /></label>
          <label>Followers (verified)<input name="followers" type="number" min={0} /></label><label>Engagement % (verified)<input name="engagement" type="number" step="0.01" min={0} max={100} /></label>
          <label>Metrics source (required with numbers)<input name="metricsSource" placeholder="e.g. creator media kit 2026-11" /></label><label>Contact email (authorised)<input name="contactEmail" type="email" /></label>
        </div>{a.msg}<button disabled={a.busy}>Add</button></form>
      </Card>
      {list.data?.results.map((i: any) => (
        <Card key={i.id} title={`${i.name} · ${i.platform} @${i.handle}`} right={<div className="row">
          <button className="secondary" onClick={() => a.run(async () => setOut(await api(`/influencers/${i.id}/analyze`, { method: 'POST', body: {} })))}>Analyse fit</button>
          <button className="secondary" onClick={() => a.run(async () => { await api(`/influencers/${i.id}/outreach`, { body: {} }); outreach.reload(); }, 'Outreach draft created below')}>Draft outreach</button>
          <button className="danger" onClick={() => a.run(async () => { await api(`/influencers/${i.id}`, { method: 'DELETE' }); list.reload(); })}>Remove</button></div>}>
          <p className="muted">{[i.niche, i.country, i.audience].filter(Boolean).join(' · ')} {i.followers != null && `· ${i.followers.toLocaleString()} followers`} {i.engagement != null && `· ${i.engagement}% eng.`} {i.metricsSource && `(source: ${i.metricsSource})`}</p>
        </Card>
      ))}
      {out && <Card title="Fit analysis"><p>Score: <b>{out.fitScore}</b>/100</p><ul>{out.reasons?.map((r: string) => <li key={r}>{r}</li>)}</ul>{out.risks?.length > 0 && <p className="muted">Risks: {out.risks.join('; ')}</p>}{out.missingData?.length > 0 && <p className="muted">Missing data: {out.missingData.join('; ')}</p>}</Card>}
      <Card title="Outreach & deliverables">{outreach.data?.map((o: any) => (
        <div key={o.id}><b>{o.influencer.name}</b> <Badge s={o.status} /><pre className="out">{o.subject && `Subject: ${o.subject}\n\n`}{o.message}</pre>
          <div className="row">{['sent', 'replied', 'accepted', 'declined', 'completed'].map((s) => <button key={s} className="secondary" onClick={() => a.run(async () => { await api(`/influencers/outreach/${o.id}`, { method: 'PATCH', body: { status: s } }); outreach.reload(); })}>{s}</button>)}</div></div>
      ))}{outreach.data && !outreach.data.length && <p className="muted">No outreach yet.</p>}</Card>
    </>
  );
}

export function Leads() {
  const { business } = useApp(); const a = useAction(); const [status, setStatus] = useState(''); const [draft, setDraft] = useState<any>(null);
  const list = useLoad(() => (business ? api(`/leads?businessId=${business.id}${status ? `&status=${status}` : ''}`) : Promise.resolve([])), [business?.id, status]);
  if (!business) return <NeedBusiness />;
  const add = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); const g = (k: string) => (f.get(k) as string) || undefined; a.run(async () => { await api('/leads', { body: { businessId: business.id, source: g('source'), businessName: g('businessName'), contactName: g('contactName'), email: g('email'), phone: g('phone'), industry: g('industry'), consentBasis: g('consentBasis') } }); list.reload(); (e.target as HTMLFormElement).reset(); }, 'Lead added'); };
  const imp = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); const file = f.get('file') as File; a.run(async () => { const r = await api('/leads/import', { body: { businessId: business.id, csv: await file.text(), consentBasis: f.get('consentBasis') } }); list.reload(); alert(`Imported ${r.created}, duplicates ${r.duplicates}, invalid ${r.invalid}`); }); };
  return (
    <>
      <h1>Leads & CRM</h1>
      <Card><p className="muted">Only add contacts you are allowed to contact; record the basis. CHARDHO AI drafts one-to-one messages and never sends bulk or unsolicited messages.</p></Card>
      <Card title="Add lead"><form onSubmit={add}><div className="grid">
        <label>Contact name<input name="contactName" /></label><label>Company<input name="businessName" /></label><label>Email<input name="email" type="email" /></label><label>Phone<input name="phone" /></label>
        <label>Industry<input name="industry" /></label><label>Source<input name="source" required defaultValue="website enquiry" /></label><label>Consent / lawful basis<input name="consentBasis" required placeholder="e.g. filled our contact form" /></label>
      </div>{a.msg}<button disabled={a.busy}>Add lead</button></form></Card>
      <Card title="CSV import / export">
        <form className="row" onSubmit={imp}><input name="file" type="file" accept=".csv" required aria-label="CSV file" style={{ width: 'auto' }} /><input name="consentBasis" required placeholder="Consent basis for this list" aria-label="Consent basis" style={{ width: 'auto' }} /><button disabled={a.busy}>Import</button>
          <button type="button" className="secondary" onClick={() => a.run(async () => download('leads.csv', await api(`/leads/export?businessId=${business.id}`, { raw: true })))}>Export CSV</button></form>
        <p className="muted">Columns: businessName, contactName, email, phone, industry. Duplicates are skipped by email/phone/name.</p>
      </Card>
      <Card title="Pipeline" right={<select aria-label="Filter status" style={{ width: 'auto' }} value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All</option>{['new', 'contacted', 'qualified', 'won', 'lost'].map((s) => <option key={s}>{s}</option>)}</select>}>
        <table><thead><tr><th>Lead</th><th>Source</th><th>Score</th><th>Status</th><th /></tr></thead><tbody>{list.data?.map((l: any) => (
          <tr key={l.id}><td>{l.contactName} {l.businessName && `(${l.businessName})`}<br /><span className="muted">{l.email}</span></td><td>{l.source}</td><td>{l.score}</td>
            <td><select aria-label="Status" value={l.status} onChange={(e) => a.run(async () => { await api(`/leads/${l.id}`, { method: 'PATCH', body: { status: e.target.value } }); list.reload(); })}>{['new', 'contacted', 'qualified', 'won', 'lost'].map((s) => <option key={s}>{s}</option>)}</select></td>
            <td><button className="secondary" onClick={() => a.run(async () => setDraft(await api(`/leads/${l.id}/outreach`, { method: 'POST', body: {} })))}>Draft message</button> <button className="danger" onClick={() => a.run(async () => { await api(`/leads/${l.id}`, { method: 'DELETE' }); list.reload(); })}>×</button></td></tr>))}</tbody></table>
      </Card>
      {draft && <Card title="Drafted message"><p><b>{draft.draft.subject}</b></p><pre className="out">{draft.draft.body}</pre><p className="muted">{draft.note}</p></Card>}
    </>
  );
}

export function Email() {
  const { business } = useApp(); const a = useAction();
  const list = useLoad(() => (business ? api(`/email?businessId=${business.id}`) : Promise.resolve([])), [business?.id]); const [gen, setGen] = useState<any>(null);
  if (!business) return <NeedBusiness />;
  return (
    <>
      <h1>Email marketing</h1><Card><p className="muted">Drafts only. Copy them into your own email tool and send to subscribers who have opted in.</p></Card>
      <Card title="Generate"><form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => setGen(await api('/email/generate', { body: { businessId: business.id, brief: f.get('brief') } }))); }}><textarea name="brief" required placeholder="e.g. 3-email welcome sequence for new subscribers" />{a.msg}<button disabled={a.busy}>Generate</button></form>
        {gen?.output?.drafts?.map((d: any, i: number) => <div key={i}><h2>{d.title}</h2><pre className="out">{d.body}</pre><button className="secondary" onClick={() => a.run(async () => { await api('/email', { body: { businessId: business.id, name: d.title || 'Email', subject: d.title || 'Subject', body: d.body } }); list.reload(); }, 'Saved')}>Save as campaign</button></div>)}</Card>
      <Card title="Saved campaigns">{list.data?.map((c: any) => <div key={c.id}><b>{c.subject}</b> <Badge s={c.status} /><pre className="out">{c.body}</pre></div>)}</Card>
    </>
  );
}

export function Automation() {
  const { business } = useApp(); const a = useAction();
  const meta = useLoad(() => api('/automation/meta'), []); const wfs = useLoad(() => (business ? api(`/automation?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  const runs = useLoad(() => api('/automation/runs'), []);
  const [steps, setSteps] = useState<{ id: string; action: string; request: string }[]>([{ id: 's1', action: 'generate_content', request: '' }]);
  if (!business) return <NeedBusiness />;
  const create = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const graph = { steps: steps.map((s) => ({ id: s.id, action: s.action, params: s.action === 'notify' ? { title: s.request } : s.action === 'start_agent' ? { agent: 'marketing_manager', request: s.request } : { request: s.request } })) };
    a.run(async () => { await api('/automation', { body: { businessId: business.id, name: f.get('name'), trigger: f.get('trigger'), graph } }); wfs.reload(); }, 'Workflow created');
  };
  const patch = (id: string, body: object) => a.run(async () => { await api(`/automation/${id}`, { method: 'PATCH', body }); wfs.reload(); });
  return (
    <>
      <h1>Marketing automation</h1>{a.msg}
      <Card title="Templates">{meta.data?.templates.map((t: any, i: number) => <div key={i} className="row" style={{ justifyContent: 'space-between' }}><span>{t.name} <span className="muted">({t.trigger})</span></span><button className="secondary" onClick={() => a.run(async () => { await api('/automation/from-template', { body: { businessId: business.id, index: i } }); wfs.reload(); }, 'Added')}>Use</button></div>)}</Card>
      <Card title="Visual builder">
        <form onSubmit={create}>
          <div className="grid"><label>Name<input name="name" required /></label><label>Trigger<select name="trigger">{meta.data?.triggers.map((t: string) => <option key={t}>{t}</option>)}</select></label></div>
          <div role="list" aria-label="Workflow steps">{steps.map((s, i) => (
            <div role="listitem" key={s.id} className="card" style={{ marginBottom: '.5rem' }}>
              <div className="row"><b>Step {i + 1}</b><select aria-label="Action" style={{ width: 'auto' }} value={s.action} onChange={(e) => setSteps(steps.map((x) => (x.id === s.id ? { ...x, action: e.target.value } : x)))}>{['start_agent', 'generate_content', 'notify', 'generate_report', 'prepare_email'].map((x) => <option key={x}>{x}</option>)}</select>
                <div className="grow"><input aria-label="Instruction" placeholder={s.action === 'notify' ? 'Notification title' : 'Instruction for the agent'} value={s.request} onChange={(e) => setSteps(steps.map((x) => (x.id === s.id ? { ...x, request: e.target.value } : x)))} /></div>
                {steps.length > 1 && <button type="button" className="secondary" onClick={() => setSteps(steps.filter((x) => x.id !== s.id))}>Remove</button>}</div>
            </div>))}</div>
          <div className="row"><button type="button" className="secondary" onClick={() => setSteps([...steps, { id: 's' + (steps.length + 1) + Date.now() % 1000, action: 'notify', request: '' }])}>+ Add step</button><button disabled={a.busy}>Save workflow</button></div>
          <p className="muted">Steps run in order. Agents create drafts; publishing still needs your approval.</p>
        </form>
      </Card>
      <Card title="Your workflows">{wfs.data?.map((w: any) => (
        <div key={w.id} className="row" style={{ justifyContent: 'space-between', marginBottom: '.5rem' }}>
          <span><b>{w.name}</b> <span className="muted">on {w.trigger} · {w.graph.steps.length} steps</span> {w.paused && <Badge s="demo" />}</span>
          <span className="row"><button className="secondary" onClick={() => a.run(async () => { await api(`/automation/${w.id}/run`, { method: 'POST', body: {} }); runs.reload(); }, 'Queued — the worker will run it shortly')}>Run now</button>
            <button className="secondary" onClick={() => patch(w.id, { paused: !w.paused })}>{w.paused ? 'Resume' : 'Pause'}</button>
            <button className="secondary" onClick={() => patch(w.id, { enabled: !w.enabled })}>{w.enabled ? 'Disable' : 'Enable'}</button>
            <button className="danger" onClick={() => a.run(async () => { await api(`/automation/${w.id}`, { method: 'DELETE' }); wfs.reload(); })}>Delete</button></span></div>))}</Card>
      <Card title="Execution history" right={<button className="secondary" onClick={runs.reload}>Refresh</button>}><table><thead><tr><th>Workflow</th><th>Status</th><th>Started</th><th>Log</th><th /></tr></thead><tbody>{runs.data?.map((r: any) => (
        <tr key={r.id}><td>{r.workflow.name}</td><td><Badge s={r.status} /></td><td>{new Date(r.createdAt).toLocaleString()}</td><td className="muted">{r.error ?? (r.logs as any[]).map((l) => `${l.step}:${l.status}`).join(' → ')}</td>
          <td>{r.status === 'FAILED' && <button className="secondary" onClick={() => a.run(async () => { await api(`/automation/runs/${r.id}/retry`, { method: 'POST', body: {} }); runs.reload(); })}>Retry</button>}{r.status === 'PAUSED' && <button className="secondary" onClick={() => a.run(async () => { await api(`/automation/runs/${r.id}/resume`, { method: 'POST', body: {} }); runs.reload(); })}>Resume</button>}</td></tr>))}</tbody></table></Card>
    </>
  );
}

export function Analytics() {
  const { business } = useApp(); const a = useAction();
  const d = useLoad(() => (business ? api(`/analytics?businessId=${business.id}`) : Promise.resolve(null)), [business?.id]);
  const [res, setRes] = useState<any[]>([]);
  if (!business) return <NeedBusiness />;
  const Group = ({ title, data }: { title: string; data?: Record<string, number> }) => <Card title={title}>{data && Object.keys(data).length ? Object.entries(data).map(([k, v]) => <div key={k} className="row" style={{ justifyContent: 'space-between' }}><Badge s={k} /><b>{v}</b></div>) : <p className="muted">No data</p>}</Card>;
  return (
    <>
      <h1>Analytics</h1>{a.msg}
      <div className="grid"><Group title="Content" data={d.data?.content} /><Group title="Publishing" data={d.data?.publishing} /><Group title="Leads" data={d.data?.leads} /><Group title="AI tasks" data={d.data?.agentTasks} /></div>
      <Card title="Platform metrics" right={<button disabled={a.busy} onClick={() => a.run(async () => { setRes((await api('/analytics/collect', { body: { businessId: business.id } })).results); d.reload(); })}>Collect from connected accounts</button>}>
        {d.data?.note && <p className="muted">{d.data.note}</p>}
        <table><tbody>{d.data?.platformMetrics.slice(0, 20).map((m: any) => <tr key={m.id}><td>{m.platform}</td><td>{m.metric}</td><td><b>{m.value}</b></td><td className="muted">{new Date(m.capturedAt).toLocaleString()} · {m.source}</td></tr>)}</tbody></table>
        {res.filter((r) => !r.ok).map((r, i) => <p key={i} className="muted">{r.platform} {r.account}: {r.error}</p>)}
      </Card>
    </>
  );
}
