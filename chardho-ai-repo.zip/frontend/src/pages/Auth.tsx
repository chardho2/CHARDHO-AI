import { FormEvent, useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../ctx';
import { Alert, Card, useAction } from '../ui';

const Shell = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="center"><div className="auth"><h1>CHARDHO <span style={{ color: 'var(--green)' }}>AI</span></h1><p className="hero">Create. Automate. Promote. Grow. Free AI marketing workforce.</p><Card title={title}>{children}</Card></div></div>
);

export function Login() {
  const { login } = useApp(); const nav = useNavigate(); const a = useAction();
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    await a.run(async () => { const r = await api('/auth/login', { body: { email: f.get('email'), password: f.get('password') } }); await login(r.token); nav('/'); });
  };
  return (
    <Shell title="Log in">
      <form onSubmit={submit}>
        <label>Email<input name="email" type="email" required autoComplete="email" /></label>
        <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
        {a.msg}
        <div className="row" style={{ marginTop: '.8rem' }}><button disabled={a.busy}>Log in</button><a className="btn secondary" style={{ background: 'transparent', color: 'var(--fg)', border: '1px solid var(--border)', textDecoration: 'none' }} href="/api/auth/google">Continue with Google</a></div>
      </form>
      <p className="muted"><Link to="/forgot">Forgot password?</Link> · <Link to="/register">Create free account</Link></p>
    </Shell>
  );
}

export function Register() {
  const a = useAction(); const [done, setDone] = useState('');
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const r = await a.run(() => api('/auth/register', { body: { name: f.get('name'), email: f.get('email'), password: f.get('password') } }));
    if (r) setDone(r.message);
  };
  return (
    <Shell title="Create your free account">
      {done ? <Alert kind="ok">{done}</Alert> : (
        <form onSubmit={submit}>
          <label>Name<input name="name" required /></label>
          <label>Email<input name="email" type="email" required autoComplete="email" /></label>
          <label>Password<input name="password" type="password" required minLength={10} autoComplete="new-password" /></label>
          <p className="muted">10+ characters with upper-case, lower-case and a number.</p>
          {a.msg}<button disabled={a.busy}>Sign up free</button>
        </form>
      )}
      <p className="muted"><Link to="/login">Already have an account?</Link></p>
    </Shell>
  );
}

export function VerifyEmail() {
  const [sp] = useSearchParams(); const a = useAction(); const [ok, setOk] = useState(false);
  useEffect(() => { a.run(() => api('/auth/verify-email', { body: { token: sp.get('token') } }), 'Email verified. You can log in now.').then(() => setOk(true)); }, []); // eslint-disable-line
  return <Shell title="Verifying email">{a.msg}{ok && <Link to="/login">Go to login</Link>}</Shell>;
}

export function Forgot() {
  const a = useAction();
  return (
    <Shell title="Forgot password">
      <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(() => api('/auth/forgot-password', { body: { email: f.get('email') } }), 'If that email exists, a reset link has been sent.'); }}>
        <label>Email<input name="email" type="email" required /></label>{a.msg}<button disabled={a.busy}>Send reset link</button>
      </form>
      <p className="muted"><Link to="/login">Back to login</Link></p>
    </Shell>
  );
}

export function ResetPassword() {
  const [sp] = useSearchParams(); const a = useAction();
  return (
    <Shell title="Choose a new password">
      <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(() => api('/auth/reset-password', { body: { token: sp.get('token'), password: f.get('password') } }), 'Password updated. Please log in.'); }}>
        <label>New password<input name="password" type="password" required minLength={10} autoComplete="new-password" /></label>{a.msg}<button disabled={a.busy}>Update password</button>
      </form>
      <p className="muted"><Link to="/login">Back to login</Link></p>
    </Shell>
  );
}

// Google OAuth returns the token in the URL fragment (never sent to a server).
export function OAuthComplete() {
  const { login } = useApp(); const nav = useNavigate(); const [err, setErr] = useState('');
  useEffect(() => {
    const t = new URLSearchParams(location.hash.slice(1)).get('token');
    history.replaceState(null, '', location.pathname);
    if (!t) { setErr('Sign-in failed'); return; }
    login(t).then(() => nav('/')).catch((e) => setErr(e.message));
  }, []); // eslint-disable-line
  return <Shell title="Signing you in">{err ? <Alert>{err}</Alert> : <p>One moment…</p>}</Shell>;
}
