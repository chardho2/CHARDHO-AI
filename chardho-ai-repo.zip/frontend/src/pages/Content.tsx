import { FormEvent, useState } from 'react';
import { api, download } from '../api';
import { useApp } from '../ctx';
import { Alert, Badge, Card, useAction, useLoad } from '../ui';
import { NeedBusiness, Report } from './Core';

const PLATFORMS = ['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X'];
const TYPES: [string, string][] = [['social_post', 'Social post'], ['reel_script', 'Reels script'], ['youtube_script', 'YouTube script'], ['blog', 'Blog article'], ['seo_article', 'SEO article'], ['product_description', 'Product description'], ['ad_copy', 'Advertisement copy'], ['campaign', 'Promotional campaign'], ['newsletter', 'Email newsletter'], ['whatsapp', 'WhatsApp promotional draft']];

function ContentCard({ c, onChange }: { c: any; onChange: () => void }) {
  const v = c.versions?.[0]; const [body, setBody] = useState(v?.body ?? ''); const [edit, setEdit] = useState(false); const a = useAction();
  const save = () => a.run(async () => { await api(`/content/${c.id}`, { method: 'PATCH', body: { body } }); setEdit(false); onChange(); }, 'Saved as a new version. Any previous approval was invalidated.');
  return (
    <Card title={c.title || c.type} right={<Badge s={c.status} />}>
      <p className="muted">{c.type} {c.platform && `· ${c.platform}`} · v{c.currentVersion} {c.createdByAgent && `· by ${c.createdByAgent}`}</p>
      {edit ? <textarea aria-label="Edit content" value={body} onChange={(e) => setBody(e.target.value)} /> : <pre className="out">{v?.body}{v?.hashtags?.length ? `\n\n${v.hashtags.map((h: string) => (h.startsWith('#') ? h : '#' + h)).join(' ')}` : ''}</pre>}
      {a.msg}
      <div className="row">
        {edit ? <><button disabled={a.busy} onClick={save}>Save</button><button className="secondary" onClick={() => setEdit(false)}>Cancel</button></> : <button className="secondary" onClick={() => setEdit(true)}>Edit</button>}
        <button className="secondary" onClick={() => navigator.clipboard.writeText(v?.body ?? '')}>Copy</button>
        <button className="secondary" onClick={() => download(`${c.type}-${c.id}.txt`, new Blob([v?.body ?? ''], { type: 'text/plain' }))}>Download</button>
        {c.platform && ['DRAFT', 'QUALITY_CHECKED'].includes(c.status) && <button className="green" disabled={a.busy} onClick={() => a.run(async () => { await api(`/approvals/${c.id}/submit`, { method: 'POST', body: {} }); onChange(); }, 'Sent to Approval Center')}>Submit for review</button>}
        {!c.platform && <span className="muted">No platform set — this content is for download/copy.</span>}
      </div>
    </Card>
  );
}

export function Studio() {
  const { business } = useApp(); const a = useAction();
  const list = useLoad(() => (business ? api(`/content?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  const [ask, setAsk] = useState<any>(null);
  if (!business) return <NeedBusiness />;
  const gen = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const g = (k: string) => (f.get(k) as string) || undefined;
    a.run(async () => { await api('/content/generate', { body: { businessId: business.id, type: g('type'), platform: g('platform'), prompt: g('prompt'), language: g('language'), tone: g('tone'), audience: g('audience'), length: g('length'), count: Number(f.get('count') || 1) } }); list.reload(); }, 'Generated. Review the drafts below.');
  };
  const orchestrate = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    a.run(async () => { setAsk(await api('/agents/execute', { body: { businessId: business.id, request: f.get('request') } })); list.reload(); });
  };
  return (
    <>
      <h1>Content Studio</h1>
      <Card title="Generate content">
        <form onSubmit={gen}>
          <div className="grid">
            <label>Type<select name="type">{TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
            <label>Platform<select name="platform"><option value="">None (copy/download only)</option>{PLATFORMS.map((p) => <option key={p}>{p}</option>)}</select></label>
            <label>Language<input name="language" defaultValue={business.languages?.[0] ?? 'English'} /></label>
            <label>Tone<select name="tone">{['professional', 'friendly', 'bold', 'playful', 'luxury', 'inspirational'].map((t) => <option key={t}>{t}</option>)}</select></label>
            <label>Audience<input name="audience" defaultValue={business.targetAudience?.slice(0, 80)} /></label>
            <label>Length<select name="length"><option value="short">Short</option><option value="medium" selected>Medium</option><option value="long">Long</option></select></label>
            <label>How many<input name="count" type="number" min={1} max={10} defaultValue={1} /></label>
          </div>
          <label>What should it be about?<textarea name="prompt" required minLength={3} placeholder="e.g. Announce our monsoon offer on organic tea" /></label>
          {a.msg}<button disabled={a.busy}>{a.busy ? 'Generating…' : 'Generate'}</button>
        </form>
      </Card>
      <Card title="Ask the AI team" >
        <p className="muted">The orchestrator picks the right agents (marketing, SEO, social, …). Agents only create drafts; nothing is published without your approval.</p>
        <form onSubmit={orchestrate}><textarea name="request" required minLength={3} placeholder="e.g. Plan a launch campaign and write the first three posts" /><button disabled={a.busy}>Run agents</button></form>
        {ask?.tasks?.map((t: any) => <div key={t.id}><h2>{t.agentKey} <Badge s={t.status} /></h2>{t.error && <Alert>{t.error}</Alert>}{t.output && <Report r={t.output} />}</div>)}
      </Card>
      <h2>Your content</h2>
      {list.data?.map((c: any) => <ContentCard key={c.id + c.currentVersion + c.status} c={c} onChange={list.reload} />)}
      {list.data && !list.data.length && <p className="muted">Nothing yet.</p>}
    </>
  );
}

export function Approvals() {
  const { business } = useApp(); const a = useAction();
  const items = useLoad(() => (business ? api(`/approvals?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  const accts = useLoad(() => (business ? api(`/social/accounts?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  const [acct, setAcct] = useState<Record<string, string>>({}); const [when, setWhen] = useState<Record<string, string>>({});
  if (!business) return <NeedBusiness />;
  const act = (path: string, body: unknown, ok: string) => a.run(async () => { await api(path, { method: 'POST', body }); items.reload(); }, ok);
  return (
    <>
      <h1>Approval Center</h1>
      <p className="hero">AI generation → quality check → <b>your review</b> → <b>your approval</b> → schedule → publish. Editing content cancels its approval.</p>
      {a.msg}
      {items.data?.map((c: any) => {
        const v = c.versions[0]; const ap = c.approvals[0]; const job = c.jobs[0];
        const matching = accts.data?.filter((x: any) => x.platform === c.platform) ?? [];
        return (
          <Card key={c.id} title={`${c.platform} · ${c.title || c.type}`} right={<Badge s={c.status} />}>
            <pre className="out">{v.body}{v.hashtags?.length ? `\n\n${v.hashtags.join(' ')}` : ''}</pre>
            <p className="muted">Version {v.version}{ap && !ap.invalidatedAt && ` · approved ${new Date(ap.approvedAt).toLocaleString()} (v${ap.version})`}{ap?.invalidatedAt && ` · approval invalidated: ${ap.invalidReason}`}</p>
            {job && <p className="muted">Publishing: <Badge s={job.status} /> {job.externalPostId && `post ${job.externalPostId}`} {job.error && <span style={{ color: 'var(--danger)' }}>{job.error}</span>}</p>}
            <div className="row">
              {['QUALITY_CHECKED', 'DRAFT'].includes(c.status) && <button onClick={() => act(`/approvals/${c.id}/submit`, {}, 'Submitted for review')}>Submit for review</button>}
              {c.status === 'PENDING_APPROVAL' && <>
                <select aria-label="Destination account" style={{ width: 'auto' }} value={acct[c.id] ?? ''} onChange={(e) => setAcct({ ...acct, [c.id]: e.target.value })}><option value="">Choose account…</option>{matching.map((x: any) => <option key={x.id} value={x.id}>{x.displayName}</option>)}</select>
                <input aria-label="Schedule time (optional)" type="datetime-local" style={{ width: 'auto' }} value={when[c.id] ?? ''} onChange={(e) => setWhen({ ...when, [c.id]: e.target.value })} />
                <button className="green" disabled={!acct[c.id]} onClick={() => act(`/approvals/${c.id}/approve`, { socialAccountId: acct[c.id], scheduledFor: when[c.id] ? new Date(when[c.id]).toISOString() : undefined }, 'Approved this version')}>Approve</button>
                {!matching.length && <span className="muted">Connect a {c.platform} account first (Social Accounts).</span>}
              </>}
              {c.status === 'APPROVED' && <><button onClick={() => act(`/approvals/${c.id}/schedule`, {}, 'Scheduled')}>Schedule</button><button className="green" onClick={() => act('/social/publish', { contentId: c.id }, 'Publish attempted; see status')}>Publish now</button></>}
              {['APPROVED', 'SCHEDULED', 'PENDING_APPROVAL'].includes(c.status) && <button className="secondary" onClick={() => act(`/approvals/${c.id}/cancel`, {}, 'Cancelled')}>Cancel</button>}
            </div>
          </Card>
        );
      })}
      {items.data && !items.data.length && <Card><p className="muted">No platform content to review yet. Generate a post with a platform selected in the Content Studio.</p></Card>}
    </>
  );
}

export function Social() {
  const { business } = useApp(); const a = useAction();
  const accts = useLoad(() => (business ? api(`/social/accounts?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  const jobs = useLoad(() => (business ? api(`/social/publish?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  if (!business) return <NeedBusiness />;
  const connect = (p: string) => a.run(async () => { const r = await api(`/social/connect/${p.toLowerCase()}?businessId=${business.id}`); location.href = r.url; });
  return (
    <>
      <h1>Social accounts</h1>
      <p className="muted">Accounts connect through each platform's official OAuth. Tokens are encrypted server-side and never sent back to the browser.</p>
      {a.msg}
      <Card title="Connect">{<div className="row">{PLATFORMS.map((p) => <button key={p} className="secondary" onClick={() => connect(p)}>{p}</button>)}</div>}</Card>
      <Card title="Connected">{accts.data?.map((x: any) => <div key={x.id} className="row" style={{ justifyContent: 'space-between' }}><span>{x.platform} · {x.displayName}</span><button className="secondary" onClick={() => a.run(async () => { await api(`/social/accounts/${x.id}`, { method: 'DELETE' }); accts.reload(); })}>Disconnect</button></div>)}{accts.data && !accts.data.length && <p className="muted">None yet.</p>}</Card>
      <Card title="Publishing history"><table><thead><tr><th>Content</th><th>Account</th><th>Status</th><th>Detail</th></tr></thead><tbody>{jobs.data?.map((j: any) => <tr key={j.id}><td>{j.content.title ?? j.content.type}</td><td>{j.account.platform}</td><td><Badge s={j.status} /></td><td>{j.error ?? j.externalPostId ?? ''}</td></tr>)}</tbody></table></Card>
    </>
  );
}

export function Calendar() {
  const { business } = useApp(); const a = useAction();
  const entries = useLoad(() => (business ? api(`/calendar?businessId=${business.id}`) : Promise.resolve([])), [business?.id]);
  if (!business) return <NeedBusiness />;
  const gen = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => { await api('/calendar/generate', { body: { businessId: business.id, days: Number(f.get('days')), platforms: [f.get('platform')] } }); entries.reload(); }, 'Calendar drafted. Review each post in the Approval Center.'); };
  const add = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => { await api('/calendar', { body: { businessId: business.id, title: f.get('title'), date: new Date(String(f.get('date'))).toISOString() } }); entries.reload(); }); (e.target as HTMLFormElement).reset(); };
  return (
    <>
      <h1>Content calendar</h1>{a.msg}
      <Card title="Generate with AI"><form className="row" onSubmit={gen}><label>Days<input name="days" type="number" min={1} max={30} defaultValue={7} /></label><label>Platform<select name="platform">{PLATFORMS.map((p) => <option key={p}>{p}</option>)}</select></label><button disabled={a.busy}>Generate calendar</button></form></Card>
      <Card title="Add an entry"><form className="row" onSubmit={add}><div className="grow"><input name="title" required placeholder="Title" aria-label="Title" /></div><input name="date" type="date" required aria-label="Date" style={{ width: 'auto' }} /><button>Add</button></form></Card>
      <Card><table><thead><tr><th>Date</th><th>Title</th><th>Platform</th><th>Status</th><th /></tr></thead><tbody>{entries.data?.map((x: any) => <tr key={x.id}><td>{new Date(x.date).toLocaleDateString()}</td><td>{x.title}</td><td>{x.platform ?? '—'}</td><td>{x.content ? <Badge s={x.content.status} /> : '—'}</td><td><button className="secondary" onClick={() => a.run(async () => { await api(`/calendar/${x.id}`, { method: 'DELETE' }); entries.reload(); })}>Remove</button></td></tr>)}</tbody></table></Card>
    </>
  );
}
