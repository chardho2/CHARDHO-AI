import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, download, setToken } from '../api';
import { Business, useApp } from '../ctx';
import { Alert, Badge, Card, useAction, useLoad } from '../ui';

const NeedBusiness = () => <Card title="Start here"><p>Create a business profile first so the AI agents know what to work on.</p><Link className="btn" to="/businesses">Add your business</Link></Card>;
export const useBiz = () => useApp().business;
export { NeedBusiness };

export function Dashboard() {
  const b = useBiz(); const { user } = useApp();
  const stats = useLoad(() => (b ? api('/analytics?businessId=' + b.id) : Promise.resolve(null)), [b?.id]);
  const usage = useLoad(() => api('/usage'), []);
  const tasks = useLoad(() => (b ? api('/agents/tasks?businessId=' + b.id) : Promise.resolve([])), [b?.id]);
  const notes = useLoad(() => api('/notifications'), []);
  if (!b) return <><h1>Welcome{user?.name ? `, ${user.name}` : ''}</h1><NeedBusiness /></>;
  const s = stats.data;
  const u = usage.data?.today;
  return (
    <>
      <h1>Dashboard</h1><p className="muted">{b.name}</p>
      {notes.data?.announcements?.map((a: any) => <Alert key={a.id} kind="warn"><b>{a.title}</b> {a.body}</Alert>)}
      <div className="grid">
        <Card title="Content">{s ? Object.entries(s.content).map(([k, v]) => <div key={k} className="row" style={{ justifyContent: 'space-between' }}><Badge s={k} /><b>{String(v)}</b></div>) : '…'}{s && !Object.keys(s.content).length && <p className="muted">No content yet. Open the Content Studio.</p>}</Card>
        <Card title="Today's free AI usage">{u ? <><p>{u.used} of {u.limit} requests used</p><div className="meter"><div style={{ width: `${Math.min(100, (u.used / u.limit) * 100)}%` }} /></div><p className="muted">Fair-use limit; resets {new Date(u.resetsAt).toLocaleTimeString()}.</p></> : '…'}</Card>
        <Card title="Notifications">{notes.data?.items?.slice(0, 5).map((n: any) => <p key={n.id}><b>{n.title}</b><br /><span className="muted">{n.body}</span></p>)}{!notes.data?.items?.length && <p className="muted">Nothing new.</p>}</Card>
      </div>
      <Card title="Business intelligence" right={<Link to="/businesses">Manage</Link>}>{b.intelligence ? <p>{b.intelligence.summary}</p> : <p className="muted">Not generated yet. Open Businesses → Generate report.</p>}</Card>
      <Card title="Recent agent tasks"><table><thead><tr><th>Agent</th><th>Status</th><th>Provider</th><th>When</th></tr></thead><tbody>{tasks.data?.slice(0, 8).map((t: any) => <tr key={t.id}><td>{t.agentKey}</td><td><Badge s={t.status} /></td><td>{t.provider ?? '—'}</td><td>{new Date(t.createdAt).toLocaleString()}</td></tr>)}</tbody></table></Card>
    </>
  );
}

const csv = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean);

export function Businesses() {
  const { businesses, business, reloadBusinesses, setBusinessId } = useApp(); const a = useAction(); const [editing, setEditing] = useState<Business | null>(null);
  const [report, setReport] = useState<any>(null);
  const save = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const g = (k: string) => (f.get(k) as string) || undefined;
    const body = { name: g('name'), website: g('website') ?? '', industry: g('industry'), description: g('description'), productsServices: g('productsServices'), location: g('location'), targetAudience: g('targetAudience'), objectives: g('objectives'), competitors: csv(String(f.get('competitors') ?? '')), languages: csv(String(f.get('languages') ?? 'en')) };
    a.run(async () => { const r = editing ? await api(`/businesses/${editing.id}`, { method: 'PATCH', body }) : await api('/businesses', { body }); await reloadBusinesses(); setBusinessId(r.id); setEditing(null); (e.target as HTMLFormElement).reset(); }, 'Saved');
  };
  const gen = () => a.run(async () => { const t = await api('/marketing/intelligence', { body: { businessId: business!.id } }); setReport(t.output); await reloadBusinesses(); }, 'Report generated');
  const del = (id: string) => confirm('Delete this business profile?') && a.run(async () => { await api(`/businesses/${id}`, { method: 'DELETE' }); await reloadBusinesses(); });
  const v = editing;
  return (
    <>
      <h1>Business profiles</h1>
      <Card title={v ? `Edit ${v.name}` : 'Add a business'}>
        <form key={v?.id ?? 'new'} onSubmit={save}>
          <div className="grid">
            <label>Business name<input name="name" required defaultValue={v?.name} /></label>
            <label>Website<input name="website" type="url" defaultValue={v?.website ?? ''} /></label>
            <label>Industry<input name="industry" defaultValue={v?.industry} /></label>
            <label>Location<input name="location" defaultValue={v?.location} /></label>
            <label>Preferred languages (comma separated)<input name="languages" defaultValue={v?.languages?.join(', ') ?? 'en'} /></label>
            <label>Competitors (comma separated)<input name="competitors" defaultValue={v?.competitors?.join(', ')} /></label>
          </div>
          <label>Description<textarea name="description" defaultValue={v?.description} /></label>
          <label>Products and services<textarea name="productsServices" defaultValue={v?.productsServices} /></label>
          <label>Target audience<textarea name="targetAudience" defaultValue={v?.targetAudience} /></label>
          <label>Marketing objectives<textarea name="objectives" defaultValue={v?.objectives} /></label>
          {a.msg}<div className="row"><button disabled={a.busy}>{v ? 'Update' : 'Create business'}</button>{v && <button type="button" className="secondary" onClick={() => setEditing(null)}>Cancel</button>}</div>
        </form>
      </Card>
      {businesses.map((b) => (
        <Card key={b.id} title={b.name} right={<div className="row"><button className="secondary" onClick={() => setEditing(b)}>Edit</button><button className="danger" onClick={() => del(b.id)}>Delete</button></div>}>
          <p className="muted">{b.industry} {b.location && `· ${b.location}`}</p>
        </Card>
      ))}
      {business && <Card title={`Marketing intelligence: ${business.name}`} right={<button disabled={a.busy} onClick={gen}>{business.intelligence ? 'Regenerate report' : 'Generate report'}</button>}>
        {(report ?? business.intelligence) ? <Report r={report ?? business.intelligence} /> : <p className="muted">The Marketing Manager agent builds a report from your profile only. Update your details and regenerate any time.</p>}
      </Card>}
    </>
  );
}
export const Report = ({ r }: { r: any }) => (
  <><p><b>{r.summary}</b></p>{r.sections?.map((s: any, i: number) => <div key={i}><h2>{s.heading}</h2><ul>{s.points.map((p: string, j: number) => <li key={j}>{p}</li>)}</ul></div>)}{r.notes?.length > 0 && <p className="muted">Notes: {r.notes.join(' · ')}</p>}</>
);

export function Settings() {
  const { user, logout } = useApp(); const a = useAction(); const usage = useLoad(() => api('/usage'), []); const integ = useLoad(() => api('/integrations'), []);
  const support = useLoad(() => api('/support'), []);
  return (
    <>
      <h1>Settings & usage</h1>
      <Card title="Fair-use limits">{usage.data && <><p>{usage.data.today.used}/{usage.data.today.limit} AI requests today.</p><p className="muted">{usage.data.note}</p><table><thead><tr><th>Agent</th><th>Requests</th><th>Tokens in/out</th></tr></thead><tbody>{usage.data.byAgent.map((r: any) => <tr key={r.agentKey ?? 'x'}><td>{r.agentKey}</td><td>{r._count}</td><td>{r._sum.tokensIn ?? 0} / {r._sum.tokensOut ?? 0}</td></tr>)}</tbody></table></>}</Card>
      <Card title="Integration status">{integ.data && <><p className="muted">Everything shown here is real status, not a demo unless labelled.</p>
        <table><tbody>
          {integ.data.ai.map((p: any) => <tr key={p.key}><td>AI: {p.name} ({p.model})</td><td><Badge s={p.status === 'enabled' ? 'live' : 'not_configured'} /> {p.status}</td></tr>)}
          {integ.data.social.map((p: any) => <tr key={p.platform}><td>{p.platform}</td><td><Badge s={p.status === 'configured' ? 'live' : 'not_configured'} /> {p.note}</td></tr>)}
          <tr><td>Google login</td><td><Badge s={integ.data.googleLogin === 'configured' ? 'live' : 'not_configured'} /></td></tr>
          <tr><td>n8n</td><td><Badge s={integ.data.n8n === 'configured' ? 'live' : 'not_configured'} /></td></tr>
          <tr><td>Email</td><td><Badge s={integ.data.email === 'configured' ? 'live' : 'demo'} /> {integ.data.email}</td></tr>
        </tbody></table></>}</Card>
      <Card title="Account"><p>{user?.email} · {user?.role}</p>{a.msg}
        <div className="row">
          <button className="secondary" onClick={() => a.run(async () => download('chardho-export.json', await api('/users/me/export', { raw: true })))}>Export my data</button>
          <button className="secondary" onClick={() => a.run(async () => { await api('/auth/logout-all', { method: 'POST', body: {} }); logout(); })}>Log out everywhere</button>
          <button className="danger" onClick={() => { if (prompt('This permanently deletes your account and all data. Type DELETE to confirm.') === 'DELETE') a.run(async () => { await api('/users/me', { method: 'DELETE', body: { confirm: 'DELETE' } }); setToken(null); location.href = '/'; }); }}>Delete account</button>
        </div>
      </Card>
      <Card title="Support">
        <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => { await api('/support', { body: { subject: f.get('subject'), body: f.get('body') } }); support.reload(); }, 'Ticket sent'); (e.target as HTMLFormElement).reset(); }}>
          <label>Subject<input name="subject" required minLength={3} /></label><label>Message<textarea name="body" required /></label><button disabled={a.busy}>Send</button>
        </form>
        {support.data?.map((t: any) => <p key={t.id}><Badge s={t.status} /> {t.subject}</p>)}
      </Card>
    </>
  );
}
