import { useState } from 'react';
import { api } from '../api';
import { useApp } from '../ctx';
import { Badge, Card, useAction, useLoad } from '../ui';

export function Admin() {
  const { user } = useApp(); const a = useAction();
  const ov = useLoad(() => api('/admin/overview'), []); const srv = useLoad(() => api('/admin/server'), []);
  const users = useLoad(() => api('/admin/users'), []); const provs = useLoad(() => api('/admin/providers'), []);
  const agents = useLoad(() => api('/admin/agents'), []); const tasks = useLoad(() => api('/admin/tasks?status=FAILED'), []);
  const wf = useLoad(() => api('/admin/workflows/failed'), []); const tickets = useLoad(() => api('/admin/tickets'), []);
  const ann = useLoad(() => api('/admin/announcements'), []); const settings = useLoad(() => api('/admin/settings'), []);
  const [keys, setKeys] = useState<Record<string, string>>({});
  const isSuper = user?.role === 'OWNER' || user?.role === 'SUPER_ADMIN';
  const o = ov.data;
  return (
    <>
      <h1>Admin portal</h1>{a.msg}
      {o && <div className="grid">
        <Card title="Users"><b>{o.users}</b> · {o.businesses} businesses</Card>
        <Card title="AI tasks (24h)"><b>{o.tasks24}</b> · {o.failed24} failed</Card>
        <Card title="Provider cost">${Number(o.totalCostUsd).toFixed(4)} · {(o.tokens.tokensIn ?? 0) + (o.tokens.tokensOut ?? 0)} tokens</Card>
        <Card title="Open tickets"><b>{o.openTickets}</b> · {o.failedWorkflowRuns} failed workflow runs</Card>
      </div>}
      {srv.data && <Card title="Server">Uptime {srv.data.uptimeSec}s · RSS {srv.data.memoryMb} MB · free {srv.data.freeMemMb}/{srv.data.totalMemMb} MB · load {srv.data.load.map((x: number) => x.toFixed(2)).join(' ')}</Card>}
      <Card title="AI providers">
        <p className="muted">Paid providers stay blocked until ALLOW_PAID_PROVIDERS=true is set by the owner. Keys are encrypted and write-only.</p>
        <table><thead><tr><th>Provider</th><th>Model</th><th>Enabled</th><th>Daily limit</th><th>Usage</th><th>API key</th></tr></thead><tbody>{provs.data?.map((p: any) => (
          <tr key={p.key}><td>{p.name} {p.paid && <Badge s="demo" />}</td><td>{p.model}</td>
            <td><input type="checkbox" aria-label={`Enable ${p.name}`} style={{ width: 'auto' }} disabled={!isSuper} checked={p.enabled} onChange={(e) => a.run(async () => { await api(`/admin/providers/${p.key}`, { method: 'PATCH', body: { enabled: e.target.checked } }); provs.reload(); })} /></td>
            <td>{p.dailyLimit ?? '∞'}</td><td className="muted">{p.usage ? `${p.usage._count} calls · $${Number(p.usage._sum.costUsd ?? 0).toFixed(4)}` : '—'}</td>
            <td>{p.hasApiKey ? 'set ' : 'not set '}{isSuper && <><input type="password" aria-label={`${p.name} API key`} placeholder="new key" value={keys[p.key] ?? ''} onChange={(e) => setKeys({ ...keys, [p.key]: e.target.value })} style={{ width: 140 }} /><button className="secondary" disabled={(keys[p.key] ?? '').length < 8} onClick={() => a.run(async () => { await api(`/admin/providers/${p.key}`, { method: 'PATCH', body: { apiKey: keys[p.key] } }); setKeys({ ...keys, [p.key]: '' }); provs.reload(); }, 'Key stored (encrypted)')}>Save</button></>}</td></tr>))}</tbody></table>
      </Card>
      <Card title="Usage limits">{isSuper ? <form className="row" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => { await api('/admin/settings/dailyAiRequestLimit', { method: 'PUT', body: { value: Number(f.get('v')) } }); settings.reload(); ov.reload(); }, 'Updated'); }}><label>AI requests per user per day<input name="v" type="number" min={0} defaultValue={settings.data?.dailyAiRequestLimit ?? o?.dailyLimit} /></label><button>Save</button></form> : <p className="muted">Super Admin required.</p>}</Card>
      <Card title="Users"><table><thead><tr><th>Email</th><th>Role</th><th>Status</th><th /></tr></thead><tbody>{users.data?.map((u: any) => (
        <tr key={u.id}><td>{u.email}</td><td>{isSuper && u.role !== 'OWNER' && u.id !== user?.id ? <select aria-label="Role" value={u.role} onChange={(e) => a.run(async () => { await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { role: e.target.value } }); users.reload(); })}>{['USER', 'ADMIN', ...(user?.role === 'OWNER' ? ['SUPER_ADMIN'] : [])].map((r) => <option key={r}>{r}</option>)}</select> : u.role}</td>
          <td>{u.disabledAt ? <Badge s="FAILED" /> : <Badge s="live" />}</td><td>{u.id !== user?.id && u.role !== 'OWNER' && <button className="secondary" onClick={() => a.run(async () => { await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { disabled: !u.disabledAt } }); users.reload(); })}>{u.disabledAt ? 'Enable' : 'Disable'}</button>}</td></tr>))}</tbody></table></Card>
      <Card title="Agents"><table><tbody>{agents.data?.map((g: any) => <tr key={g.key}><td>{g.name}{g.customized && ' (custom prompt)'}</td><td>{isSuper ? <button className="secondary" onClick={() => a.run(async () => { await api(`/admin/agents/${g.key}`, { method: 'PATCH', body: { enabled: !g.enabled } }); agents.reload(); })}>{g.enabled ? 'Disable' : 'Enable'}</button> : g.enabled ? 'on' : 'off'}</td></tr>)}</tbody></table></Card>
      <Card title="Failed agent tasks">{tasks.data?.slice(0, 15).map((t: any) => <p key={t.id}><b>{t.agentKey}</b> <span className="muted">{new Date(t.createdAt).toLocaleString()}</span><br />{t.error}</p>)}{tasks.data && !tasks.data.length && <p className="muted">None</p>}</Card>
      <Card title="Failed workflow runs">{wf.data?.slice(0, 15).map((r: any) => <p key={r.id}><b>{r.workflow.name}</b> <span className="muted">{r.error}</span></p>)}{wf.data && !wf.data.length && <p className="muted">None</p>}</Card>
      <Card title="Announcements"><form className="row" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); a.run(async () => { await api('/admin/announcements', { body: { title: f.get('title'), body: f.get('body') } }); ann.reload(); }); (e.target as HTMLFormElement).reset(); }}><input name="title" placeholder="Title" required aria-label="Title" style={{ width: 'auto' }} /><div className="grow"><input name="body" placeholder="Message" required aria-label="Message" /></div><button>Publish</button></form>
        {ann.data?.map((n: any) => <div key={n.id} className="row" style={{ justifyContent: 'space-between' }}><span><b>{n.title}</b> {n.body}</span><button className="secondary" onClick={() => a.run(async () => { await api(`/admin/announcements/${n.id}`, { method: 'PATCH', body: { active: !n.active } }); ann.reload(); })}>{n.active ? 'Hide' : 'Show'}</button></div>)}</Card>
      <Card title="Support tickets">{tickets.data?.map((t: any) => <div key={t.id} className="row" style={{ justifyContent: 'space-between' }}><span><Badge s={t.status} /> <b>{t.subject}</b> <span className="muted">{t.user.email}</span></span><select aria-label="Ticket status" value={t.status} onChange={(e) => a.run(async () => { await api(`/admin/tickets/${t.id}`, { method: 'PATCH', body: { status: e.target.value } }); tickets.reload(); })}>{['open', 'in_progress', 'closed'].map((s) => <option key={s}>{s}</option>)}</select></div>)}</Card>
    </>
  );
}
