import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react';
import { api, getToken, setToken } from './api';

export interface User { id: string; email: string; name: string | null; role: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'USER'; emailVerified: boolean }
export interface Business { id: string; name: string; website?: string; industry?: string; description?: string; productsServices?: string; location?: string; targetAudience?: string; objectives?: string; competitors: string[]; languages: string[]; intelligence?: any }

interface Ctx {
  user: User | null; loading: boolean; login: (token: string) => Promise<void>; logout: () => void;
  businesses: Business[]; business: Business | null; setBusinessId: (id: string) => void; reloadBusinesses: () => Promise<void>;
  theme: 'light' | 'dark'; toggleTheme: () => void;
}
const C = createContext<Ctx>(null as never);
export const useApp = () => useContext(C);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(!!getToken());
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [bid, setBid] = useState<string | null>(() => { try { return localStorage.getItem('chardho_biz'); } catch { return null; } });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => { try { return (localStorage.getItem('chardho_theme') as any) || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); } catch { return 'light'; } });

  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('chardho_theme', theme); } catch { /* ignore */ } }, [theme]);

  const reloadBusinesses = useCallback(async () => { setBusinesses(await api<Business[]>('/businesses')); }, []);
  const login = useCallback(async (token: string) => {
    setToken(token);
    setUser(await api<User>('/auth/me'));
    await reloadBusinesses();
  }, [reloadBusinesses]);
  const logout = useCallback(() => { setToken(null); setUser(null); setBusinesses([]); }, []);

  useEffect(() => {
    if (!getToken()) return;
    login(getToken()!).catch(() => logout()).finally(() => setLoading(false));
    const h = () => logout();
    window.addEventListener('chardho:logout', h);
    return () => window.removeEventListener('chardho:logout', h);
  }, [login, logout]);

  const business = businesses.find((b) => b.id === bid) ?? businesses[0] ?? null;
  const setBusinessId = (id: string) => { setBid(id); try { localStorage.setItem('chardho_biz', id); } catch { /* ignore */ } };

  return <C.Provider value={{ user, loading, login, logout, businesses, business, setBusinessId, reloadBusinesses, theme, toggleTheme: () => setTheme((t) => (t === 'dark' ? 'light' : 'dark')) }}>{children}</C.Provider>;
}
