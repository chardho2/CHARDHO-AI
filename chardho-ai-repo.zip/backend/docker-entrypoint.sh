#!/bin/sh
set -e
# Only the API container migrates; the worker waits for the schema to exist.
if [ "$RUN_MIGRATIONS" = "true" ]; then
  if [ -d prisma/migrations ]; then npx prisma migrate deploy; else echo "No migrations dir; using db push (first deploy only)"; npx prisma db push --skip-generate; fi
fi
exec "$@"
