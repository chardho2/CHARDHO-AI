import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const email = process.env.OWNER_EMAIL, pw = process.env.OWNER_PASSWORD;
  if (!email || !pw) throw new Error('Set OWNER_EMAIL and OWNER_PASSWORD');
  if (pw.length < 12) throw new Error('OWNER_PASSWORD must be at least 12 characters');
  const u = await prisma.user.upsert({
    where: { email: email.toLowerCase() },
    create: { email: email.toLowerCase(), name: 'Owner', role: 'OWNER', passwordHash: await bcrypt.hash(pw, 12), emailVerifiedAt: new Date() },
    update: { role: 'OWNER' },
  });
  console.log(`Owner ready: ${u.email}`);
}
main().finally(() => prisma.$disconnect());
