import { describe, expect, it } from 'vitest';
process.env.DATABASE_URL ??= 'postgresql://x:x@localhost:5432/x';
process.env.JWT_SECRET ??= 'x'.repeat(40);
process.env.ENCRYPTION_KEY ??= 'ab'.repeat(32);

describe('content hash (approval invalidation basis)', async () => {
  const { contentHash } = await import('../src/lib/hash');
  it('changes when body changes', () => expect(contentHash('a', [], [])).not.toBe(contentHash('b', [], [])));
  it('changes when hashtags change', () => expect(contentHash('a', ['x'], [])).not.toBe(contentHash('a', ['y'], [])));
  it('is stable for same content, ignoring tag order and outer whitespace', () => expect(contentHash(' a ', ['x', 'y'], [])).toBe(contentHash('a', ['y', 'x'], [])));
});

describe('quality check', async () => {
  const { qualityCheck } = await import('../src/services/content');
  it('rejects empty', () => expect(qualityCheck('  ', 'X').ok).toBe(false));
  it('rejects X posts over 280', () => expect(qualityCheck('a'.repeat(281), 'X').ok).toBe(false));
  it('accepts normal post', () => expect(qualityCheck('Hello world', 'INSTAGRAM').ok).toBe(true));
  it('flags placeholders', () => expect(qualityCheck('Buy now [insert link]', null).ok).toBe(false));
});

describe('crypto', async () => {
  const c = await import('../src/lib/crypto');
  it('round-trips AES-GCM', () => expect(c.decrypt(c.encrypt('secret-token'))).toBe('secret-token'));
  it('detects tampering', () => { const e = c.encrypt('x'); const [iv, tag, ct] = e.split('.'); expect(() => c.decrypt([iv, tag, Buffer.from('zz').toString('base64')].join('.'))).toThrow(); void ct; });
  it('verifies HMAC and rejects wrong signature', () => { const s = c.hmacSign('body', 'k'); expect(c.hmacVerify('body', s, 'k')).toBe(true); expect(c.hmacVerify('body2', s, 'k')).toBe(false); expect(c.hmacVerify('body', '', 'k')).toBe(false); });
});

describe('workflow conditions', async () => {
  const { evalCondition, graphSchema } = await import('../src/services/workflows');
  it('eq / exists / contains / gt', () => {
    const ctx = { trigger: { score: 80, tags: ['vip'], name: 'Acme Ltd' } };
    expect(evalCondition({ path: 'trigger.score', op: 'gt', value: 50 }, ctx)).toBe(true);
    expect(evalCondition({ path: 'trigger.tags', op: 'contains', value: 'vip' }, ctx)).toBe(true);
    expect(evalCondition({ path: 'trigger.name', op: 'contains', value: 'Acme' }, ctx)).toBe(true);
    expect(evalCondition({ path: 'trigger.missing', op: 'exists' }, ctx)).toBe(false);
  });
  it('rejects unknown actions (no arbitrary execution)', () => {
    expect(graphSchema.safeParse({ steps: [{ id: 'a', action: 'run_shell', params: {} }] }).success).toBe(false);
  });
});

describe('leads', async () => {
  const { dedupeKey, scoreLead } = await import('../src/routes/crm');
  it('dedupes by normalised email, then phone', () => {
    expect(dedupeKey({ email: ' A@B.com ' })).toBe('a@b.com');
    expect(dedupeKey({ phone: '+1 (555) 123-4567' })).toBe('15551234567');
  });
  it('scores within 0..100', () => { expect(scoreLead({ email: 'a@b.c', phone: '1', businessName: 'x', industry: 'y', status: 'won' })).toBe(100); expect(scoreLead({ status: 'lost' })).toBe(0); });
});

describe('agent output parsing', async () => {
  const { parseJsonLoose, outputSchema } = await import('../src/services/orchestrator');
  it('strips code fences', () => expect((parseJsonLoose('```json\n{"summary":"ok"}\n```') as any).summary).toBe('ok'));
  it('extracts JSON from chatter', () => expect((parseJsonLoose('Sure! {"summary":"ok"} done') as any).summary).toBe('ok'));
  it('normalises platform and rejects empty body', () => {
    const r = outputSchema.parse({ summary: 's', drafts: [{ type: 'social_post', platform: 'twitter', body: 'hi' }] });
    expect(r.drafts![0].platform).toBe('X');
    expect(outputSchema.safeParse({ summary: 's', drafts: [{ type: 't', body: '' }] }).success).toBe(false);
  });
});
