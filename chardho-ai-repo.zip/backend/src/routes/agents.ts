import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { AGENTS } from '../agents/definitions';
import { inputSchema, orchestrate, runAgent } from '../services/orchestrator';
import { usageToday } from '../services/usage';
import { notFound } from '../lib/errors';
import { generateText } from '../providers/manager';

export const agentsRouter = Router();
agentsRouter.use(requireAuth);

agentsRouter.get('/', ah(async (_req, res) => {
  const rows = await prisma.aiAgent.findMany();
  const en = new Map(rows.map((r) => [r.key, r.enabled]));
  res.json(AGENTS.map((a) => ({ key: a.key, name: a.name, description: a.description, tools: a.tools, enabled: en.get(a.key) ?? true })));
}));

const execSchema = z.object({
  businessId: z.string(),
  agent: z.string().optional(),       // omit => orchestrator chooses
  agents: z.array(z.string()).max(4).optional(),
}).merge(inputSchema.omit({ priorOutputs: true }));

agentsRouter.post('/execute', ah(async (req, res) => {
  const b = execSchema.parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  const input = { request: b.request, language: b.language, tone: b.tone, audience: b.audience, length: b.length };
  if (b.agent) {
    const task = await runAgent({ userId: req.user!.id, business, agentKey: b.agent, input: { ...input, priorOutputs: [] } });
    return res.status(task.status === 'SUCCEEDED' ? 200 : 502).json({ agents: [b.agent], tasks: [task] });
  }
  res.json(await orchestrate({ userId: req.user!.id, business, input, agents: b.agents }));
}));

agentsRouter.get('/tasks', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string().optional() }).parse(req.query);
  res.json(await prisma.agentTask.findMany({ where: { userId: req.user!.id, ...(businessId && { businessId }) }, orderBy: { createdAt: 'desc' }, take: 100 }));
}));
agentsRouter.get('/tasks/:id', ah(async (req, res) => {
  const t = await prisma.agentTask.findFirst({ where: { id: req.params.id, userId: req.user!.id }, include: { children: true } });
  if (!t) throw notFound('Task');
  res.json(t);
}));

export const conversationsRouter = Router();
conversationsRouter.use(requireAuth);
conversationsRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.conversation.findMany({ where: { userId: req.user!.id, businessId }, orderBy: { createdAt: 'desc' }, take: 50 }));
}));
conversationsRouter.get('/:id', ah(async (req, res) => {
  const c = await prisma.conversation.findFirst({ where: { id: req.params.id, userId: req.user!.id }, include: { messages: { orderBy: { createdAt: 'asc' } } } });
  if (!c) throw notFound('Conversation');
  res.json(c);
}));
// Chatbot: orchestrated reply (agents may create drafts, never publish)
conversationsRouter.post('/message', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), conversationId: z.string().optional(), message: z.string().min(1).max(4000) }).parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  const conv = b.conversationId
    ? await prisma.conversation.findFirst({ where: { id: b.conversationId, userId: req.user!.id, businessId: b.businessId } })
    : await prisma.conversation.create({ data: { userId: req.user!.id, businessId: b.businessId, title: b.message.slice(0, 60) } });
  if (!conv) throw notFound('Conversation');
  await prisma.message.create({ data: { conversationId: conv.id, role: 'user', content: b.message } });
  const { tasks } = await orchestrate({ userId: req.user!.id, business, input: { request: b.message } });
  const ok = tasks.filter((t) => t.status === 'SUCCEEDED');
  const reply = ok.length
    ? ok.map((t) => `**${t.agentKey}**: ${(t.output as any)?.summary}`).join('\n\n')
    : `I could not complete that: ${tasks[0]?.error ?? 'unknown error'}`;
  const m = await prisma.message.create({ data: { conversationId: conv.id, role: 'assistant', content: reply, agentKey: ok[0]?.agentKey } });
  res.json({ conversationId: conv.id, message: m, tasks });
}));

export const marketingRouter = Router();
marketingRouter.use(requireAuth);
marketingRouter.post('/intelligence', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.body);
  const business = await ownBusiness(req.user!.id, businessId);
  const task = await runAgent({ userId: req.user!.id, business, agentKey: 'marketing_manager', input: { request: 'Create a business intelligence report and suggest prioritised marketing opportunities.', priorOutputs: [] } });
  res.status(task.status === 'SUCCEEDED' ? 200 : 502).json(task);
}));
marketingRouter.get('/intelligence/:businessId', ah(async (req, res) => {
  const b = await ownBusiness(req.user!.id, req.params.businessId);
  res.json(b.intelligence ?? null);
}));

export const seoRouter = Router();
seoRouter.use(requireAuth);
seoRouter.post('/analyze', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), topic: z.string().min(2).max(300) }).parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  const task = await runAgent({ userId: req.user!.id, business, agentKey: 'seo_specialist', input: { request: `SEO keyword ideas, on-page recommendations and a draft SEO article for: ${b.topic}`, priorOutputs: [] } });
  res.status(task.status === 'SUCCEEDED' ? 200 : 502).json(task);
}));
void generateText;

export const usageRouter = Router();
usageRouter.use(requireAuth);
usageRouter.get('/', ah(async (req, res) => {
  const today = await usageToday(req.user!.id);
  const byAgent = await prisma.usageRecord.groupBy({ by: ['agentKey'], where: { userId: req.user!.id }, _count: true, _sum: { tokensIn: true, tokensOut: true } });
  res.json({ today, byAgent, note: 'Free access is subject to fair-use limits and provider capacity; generation is not unlimited.' });
}));
