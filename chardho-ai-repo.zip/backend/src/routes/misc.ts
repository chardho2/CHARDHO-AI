import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { HttpError, notFound } from '../lib/errors';
import { decrypt } from '../lib/crypto';
import { runAgent } from '../services/orchestrator';

// ----- Calendar -----
export const calendarRouter = Router();
calendarRouter.use(requireAuth);
calendarRouter.get('/', ah(async (req, res) => {
  const q = z.object({ businessId: z.string(), from: z.coerce.date().optional(), to: z.coerce.date().optional() }).parse(req.query);
  await ownBusiness(req.user!.id, q.businessId);
  res.json(await prisma.calendarEntry.findMany({ where: { userId: req.user!.id, businessId: q.businessId, ...((q.from || q.to) && { date: { gte: q.from, lte: q.to } }) }, include: { content: { select: { status: true, title: true } } }, orderBy: { date: 'asc' }, take: 500 }));
}));
calendarRouter.post('/', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), contentId: z.string().optional(), title: z.string().min(1).max(200), date: z.coerce.date(), platform: z.enum(['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X']).optional(), note: z.string().max(1000).optional() }).parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  if (d.contentId && !(await prisma.contentItem.findFirst({ where: { id: d.contentId, userId: req.user!.id } }))) throw notFound('Content');
  res.status(201).json(await prisma.calendarEntry.create({ data: { ...d, userId: req.user!.id } }));
}));
calendarRouter.delete('/:id', ah(async (req, res) => {
  const r = await prisma.calendarEntry.deleteMany({ where: { id: req.params.id, userId: req.user!.id } });
  if (!r.count) throw notFound('Entry');
  res.status(204).end();
}));
// AI content calendar: agent drafts + one calendar slot per draft (still drafts; nothing is scheduled for publishing)
calendarRouter.post('/generate', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), days: z.number().int().min(1).max(30).default(7), startDate: z.coerce.date().default(() => new Date()), platforms: z.array(z.enum(['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X'])).min(1).default(['INSTAGRAM']) }).parse(req.body);
  const business = await ownBusiness(req.user!.id, d.businessId);
  const task = await runAgent({ userId: req.user!.id, business, agentKey: 'social_media_manager', input: { request: `Create a ${d.days}-day content calendar with one post per day, rotating across ${d.platforms.join(', ')}. Each draft title should be the topic.`, priorOutputs: [] } });
  if (task.status !== 'SUCCEEDED') throw new HttpError(502, task.error ?? 'Generation failed');
  const ids = ((task.output as any).savedContentIds ?? []) as string[];
  const items = await prisma.contentItem.findMany({ where: { id: { in: ids } }, orderBy: { createdAt: 'asc' } });
  const entries = await prisma.$transaction(items.map((c, i) => prisma.calendarEntry.create({ data: { userId: req.user!.id, businessId: d.businessId, contentId: c.id, title: c.title || c.type, platform: c.platform, date: new Date(d.startDate.getTime() + (i % d.days) * 86_400_000) } })));
  res.status(201).json({ task, entries });
}));

// ----- Email campaigns (drafts only; sending is a deliberate human action outside this platform) -----
export const emailRouter = Router();
emailRouter.use(requireAuth);
emailRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.emailCampaign.findMany({ where: { userId: req.user!.id, businessId }, orderBy: { createdAt: 'desc' } }));
}));
emailRouter.post('/', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), name: z.string().min(1).max(200), subject: z.string().min(1).max(300), body: z.string().min(1).max(50000) }).parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  res.status(201).json(await prisma.emailCampaign.create({ data: { ...d, userId: req.user!.id } }));
}));
emailRouter.post('/generate', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), brief: z.string().min(3).max(3000) }).parse(req.body);
  const business = await ownBusiness(req.user!.id, d.businessId);
  const task = await runAgent({ userId: req.user!.id, business, agentKey: 'email_marketing', input: { request: d.brief, priorOutputs: [] } });
  res.status(task.status === 'SUCCEEDED' ? 200 : 502).json(task);
}));
emailRouter.delete('/:id', ah(async (req, res) => {
  const r = await prisma.emailCampaign.deleteMany({ where: { id: req.params.id, userId: req.user!.id } });
  if (!r.count) throw notFound('Email campaign');
  res.status(204).end();
}));

// ----- Notifications -----
export const notificationsRouter = Router();
notificationsRouter.use(requireAuth);
notificationsRouter.get('/', ah(async (req, res) => {
  const [items, announcements] = await Promise.all([
    prisma.notification.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    prisma.announcement.findMany({ where: { active: true }, orderBy: { createdAt: 'desc' }, take: 5 }),
  ]);
  res.json({ items, unread: items.filter((i) => !i.readAt).length, announcements });
}));
notificationsRouter.post('/read', ah(async (req, res) => {
  await prisma.notification.updateMany({ where: { userId: req.user!.id, readAt: null }, data: { readAt: new Date() } });
  res.json({ ok: true });
}));

// ----- Support tickets -----
export const supportRouter = Router();
supportRouter.use(requireAuth);
supportRouter.get('/', ah(async (req, res) => res.json(await prisma.supportTicket.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' } }))));
supportRouter.post('/', ah(async (req, res) => {
  const d = z.object({ subject: z.string().min(3).max(200), body: z.string().min(3).max(5000) }).parse(req.body);
  res.status(201).json(await prisma.supportTicket.create({ data: { ...d, userId: req.user!.id } }));
}));

// ----- Integrations: honest status (real / not_configured / demo) -----
export const integrationsRouter = Router();
integrationsRouter.use(requireAuth);
integrationsRouter.get('/', ah(async (_req, res) => {
  const e = process.env;
  const has = (...k: string[]) => k.every((x) => !!e[x]);
  const providers = await prisma.providerConfig.findMany({ select: { key: true, name: true, enabled: true, paid: true, model: true } });
  res.json({
    ai: providers.map((p) => ({ ...p, status: p.enabled ? (p.paid && e.ALLOW_PAID_PROVIDERS !== 'true' ? 'blocked_paid' : 'enabled') : 'disabled' })),
    social: (['X', 'LINKEDIN', 'FACEBOOK', 'INSTAGRAM', 'YOUTUBE'] as const).map((p) => ({ platform: p, status: has(...({ X: ['X_CLIENT_ID', 'X_CLIENT_SECRET'], LINKEDIN: ['LINKEDIN_CLIENT_ID', 'LINKEDIN_CLIENT_SECRET'], FACEBOOK: ['META_APP_ID', 'META_APP_SECRET'], INSTAGRAM: ['META_APP_ID', 'META_APP_SECRET'], YOUTUBE: ['YOUTUBE_CLIENT_ID', 'YOUTUBE_CLIENT_SECRET'] }[p])) ? 'configured' : 'not_configured', note: p === 'YOUTUBE' ? 'Text/description workflow only; video upload not supported' : p === 'INSTAGRAM' ? 'Requires an image and a Business account' : undefined })),
    googleLogin: has('GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET') ? 'configured' : 'not_configured',
    n8n: has('N8N_WEBHOOK_URL', 'N8N_SHARED_SECRET') ? 'configured' : 'not_configured',
    email: has('SMTP_HOST') ? 'configured' : 'demo (emails are logged to server console)',
    imageGeneration: 'requires owner-enabled paid provider; otherwise creative briefs only',
  });
}));
void decrypt;
