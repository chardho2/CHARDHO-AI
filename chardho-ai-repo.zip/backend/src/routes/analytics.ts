import { Router } from 'express';
import { z } from 'zod';
import { Platform } from '@prisma/client';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { decrypt } from '../lib/crypto';

export const analyticsRouter = Router();
analyticsRouter.use(requireAuth);

analyticsRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  const [content, jobs, snaps, leads, tasks] = await Promise.all([
    prisma.contentItem.groupBy({ by: ['status'], where: { userId: req.user!.id, businessId, deletedAt: null }, _count: true }),
    prisma.publishingJob.groupBy({ by: ['status'], where: { content: { userId: req.user!.id, businessId } }, _count: true }),
    prisma.analyticsSnapshot.findMany({ where: { userId: req.user!.id, businessId }, orderBy: { capturedAt: 'desc' }, take: 200 }),
    prisma.lead.groupBy({ by: ['status'], where: { userId: req.user!.id, businessId, deletedAt: null }, _count: true }),
    prisma.agentTask.groupBy({ by: ['status'], where: { userId: req.user!.id, businessId }, _count: true }),
  ]);
  res.json({
    content: Object.fromEntries(content.map((c) => [c.status, c._count])),
    publishing: Object.fromEntries(jobs.map((c) => [c.status, c._count])),
    leads: Object.fromEntries(leads.map((c) => [c.status, c._count])),
    agentTasks: Object.fromEntries(tasks.map((c) => [c.status, c._count])),
    platformMetrics: snaps,
    note: snaps.length ? undefined : 'No platform analytics collected yet. Connect an account and press "Collect".',
  });
}));

// Collect what each official API exposes (account-level follower counts). Failures are reported per account, never faked.
analyticsRouter.post('/collect', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.body);
  await ownBusiness(req.user!.id, businessId);
  const accts = await prisma.socialAccount.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null } });
  const results: { platform: Platform; account: string | null; ok: boolean; metric?: string; value?: number; error?: string }[] = [];
  for (const a of accts) {
    try {
      const t = decrypt(a.accessTokenEnc);
      const h = { authorization: `Bearer ${t}` };
      let metric = 'followers', value: number | undefined;
      const j = async (u: string, headers?: Record<string, string>) => { const r = await fetch(u, { headers }); if (!r.ok) throw new Error(`${r.status}`); return r.json() as Promise<any>; };
      if (a.platform === 'X') value = (await j('https://api.twitter.com/2/users/me?user.fields=public_metrics', h)).data.public_metrics.followers_count;
      else if (a.platform === 'YOUTUBE') { metric = 'subscribers'; value = Number((await j('https://www.googleapis.com/youtube/v3/channels?part=statistics&mine=true', h)).items?.[0]?.statistics?.subscriberCount); }
      else if (a.platform === 'FACEBOOK') value = (await j(`https://graph.facebook.com/v19.0/${a.externalId}?fields=followers_count&access_token=${t}`)).followers_count;
      else if (a.platform === 'INSTAGRAM') value = (await j(`https://graph.facebook.com/v19.0/${a.externalId}?fields=followers_count&access_token=${t}`)).followers_count;
      else throw new Error('LinkedIn member analytics are not available via the public API');
      if (value == null || Number.isNaN(value)) throw new Error('metric unavailable');
      await prisma.analyticsSnapshot.create({ data: { userId: req.user!.id, businessId, platform: a.platform, metric, value, source: `${a.platform.toLowerCase()}_api` } });
      results.push({ platform: a.platform, account: a.displayName, ok: true, metric, value });
    } catch (e) { results.push({ platform: a.platform, account: a.displayName, ok: false, error: (e as Error).message }); }
  }
  res.json({ results });
}));
