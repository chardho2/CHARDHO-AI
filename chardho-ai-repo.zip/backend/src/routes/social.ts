import { Router } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { z } from 'zod';
import { Platform } from '@prisma/client';
import { prisma } from '../lib/db';
import { env } from '../lib/env';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { HttpError, notFound } from '../lib/errors';
import { decrypt, encrypt } from '../lib/crypto';
import { OAUTH, fetchIdentity } from '../services/platforms';
import { audit } from '../lib/audit';

const platformEnum = z.enum(['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X']);
const redirectUri = (p: string) => `${env.API_URL}/api/social/callback/${p.toLowerCase()}`;

export const socialRouter = Router();

// OAuth callback is hit by the browser from the provider: identity comes from the signed state, not a bearer header.
socialRouter.get('/callback/:platform', ah(async (req, res) => {
  const platform = platformEnum.parse(req.params.platform.toUpperCase()) as Platform;
  const q = z.object({ code: z.string(), state: z.string() }).parse(req.query);
  let st: { u: string; b: string; p: string; v?: string };
  try { st = jwt.verify(q.state, env.JWT_SECRET) as typeof st; } catch { throw new HttpError(400, 'Invalid or expired OAuth state'); }
  if (st.p !== platform) throw new HttpError(400, 'OAuth state mismatch');
  await ownBusiness(st.u, st.b);
  const cfg = OAUTH[platform];
  const body = new URLSearchParams({ grant_type: 'authorization_code', code: q.code, redirect_uri: redirectUri(platform), client_id: cfg.clientId ?? '' });
  const headers: Record<string, string> = { 'content-type': 'application/x-www-form-urlencoded' };
  if (st.v) body.set('code_verifier', decrypt(st.v));
  if (cfg.clientSecret) { if (platform === 'X') headers.authorization = `Basic ${Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString('base64')}`; else body.set('client_secret', cfg.clientSecret); }
  const tr = await fetch(cfg.tokenUrl, { method: 'POST', headers, body });
  const tok = (await tr.json()) as any;
  if (!tr.ok || !tok.access_token) throw new HttpError(400, 'Token exchange failed');
  const id = await fetchIdentity(platform, tok.access_token);
  const accessToken = id.accessToken ?? tok.access_token;
  const acct = await prisma.socialAccount.upsert({
    where: { businessId_platform_externalId: { businessId: st.b, platform, externalId: id.externalId } },
    create: { userId: st.u, businessId: st.b, platform, externalId: id.externalId, displayName: id.displayName, accessTokenEnc: encrypt(accessToken), refreshTokenEnc: tok.refresh_token ? encrypt(tok.refresh_token) : null, expiresAt: tok.expires_in ? new Date(Date.now() + tok.expires_in * 1000) : null, scopes: cfg.scopes },
    update: { displayName: id.displayName, accessTokenEnc: encrypt(accessToken), refreshTokenEnc: tok.refresh_token ? encrypt(tok.refresh_token) : undefined, expiresAt: tok.expires_in ? new Date(Date.now() + tok.expires_in * 1000) : null, deletedAt: null },
  });
  await audit(st.u, 'social.connect', 'SocialAccount', acct.id, { platform });
  res.redirect(`${env.APP_URL}/social?connected=${platform}`);
}));

socialRouter.use(requireAuth);

socialRouter.get('/accounts', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  // never return tokens
  res.json(await prisma.socialAccount.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null }, select: { id: true, platform: true, displayName: true, externalId: true, expiresAt: true, scopes: true, createdAt: true } }));
}));
socialRouter.delete('/accounts/:id', ah(async (req, res) => {
  const a = await prisma.socialAccount.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!a) throw notFound('Account');
  await prisma.publishingJob.updateMany({ where: { socialAccountId: a.id, status: 'PENDING' }, data: { status: 'CANCELLED', error: 'Account disconnected' } });
  await prisma.socialAccount.update({ where: { id: a.id }, data: { deletedAt: new Date(), accessTokenEnc: '', refreshTokenEnc: null } });
  res.status(204).end();
}));

// Returns the provider authorize URL (SPA navigates to it). State is signed; PKCE verifier is encrypted inside it.
socialRouter.get('/connect/:platform', ah(async (req, res) => {
  const platform = platformEnum.parse(req.params.platform.toUpperCase()) as Platform;
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  const cfg = OAUTH[platform];
  if (!cfg.clientId || !cfg.clientSecret) return res.status(501).json({ error: `${platform} OAuth is not configured by the platform owner`, status: 'not_configured' });
  const verifier = cfg.pkce ? crypto.randomBytes(32).toString('base64url') : undefined;
  const state = jwt.sign({ u: req.user!.id, b: businessId, p: platform, v: verifier && encrypt(verifier) }, env.JWT_SECRET, { expiresIn: '10m' });
  const p = new URLSearchParams({ client_id: cfg.clientId, redirect_uri: redirectUri(platform), response_type: 'code', scope: cfg.scopes.join(cfg.scopeSep ?? ' '), state, ...(cfg.extraAuth ?? {}) });
  if (verifier) { p.set('code_challenge', crypto.createHash('sha256').update(verifier).digest('base64url')); p.set('code_challenge_method', 'S256'); }
  res.json({ url: `${cfg.authUrl}?${p}` });
}));

// Publishing jobs status (publishing itself only happens via the approval engine)
socialRouter.get('/publish', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.publishingJob.findMany({ where: { content: { userId: req.user!.id, businessId } }, include: { account: { select: { platform: true, displayName: true } }, content: { select: { title: true, type: true } } }, orderBy: { createdAt: 'desc' }, take: 100 }));
}));

// "Publish now": still requires a valid human approval; it only skips waiting for a schedule.
import { runPublishingJob, schedule } from '../services/approvals';
socialRouter.post('/publish', ah(async (req, res) => {
  const { contentId } = z.object({ contentId: z.string() }).parse(req.body);
  const job = await schedule(req.user!.id, contentId, new Date());
  const outcome = await runPublishingJob(job.id);
  res.json({ jobId: job.id, outcome, job: await prisma.publishingJob.findUnique({ where: { id: job.id } }) });
}));
