import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { env } from '../lib/env';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { HttpError, notFound } from '../lib/errors';
import { hmacVerify } from '../lib/crypto';
import { TEMPLATES, TRIGGERS, executeRun, fireTrigger, graphSchema } from '../services/workflows';

// Inbound n8n webhook: HMAC-signed over the raw body (see app.ts for raw-body capture).
export const n8nWebhookRouter = Router();
n8nWebhookRouter.post('/n8n', ah(async (req, res) => {
  if (!env.N8N_SHARED_SECRET) throw new HttpError(501, 'n8n not configured');
  const raw = (req as any).rawBody as string | undefined;
  if (!raw || !hmacVerify(raw, String(req.headers['x-chardho-signature'] ?? ''), env.N8N_SHARED_SECRET)) throw new HttpError(401, 'Bad signature');
  const b = z.object({ userId: z.string(), businessId: z.string(), trigger: z.enum(TRIGGERS), data: z.record(z.any()).default({}) }).parse(req.body);
  await ownBusiness(b.userId, b.businessId);
  res.json({ runs: (await fireTrigger(b.userId, b.businessId, b.trigger, b.data)).map((r) => r.id) });
}));

export const automationRouter = Router();
automationRouter.use(requireAuth);

automationRouter.get('/meta', (_req, res) => res.json({ triggers: TRIGGERS, templates: TEMPLATES }));
automationRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.automationWorkflow.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null }, orderBy: { createdAt: 'desc' } }));
}));
automationRouter.post('/', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), name: z.string().min(1).max(150), trigger: z.enum(TRIGGERS), graph: graphSchema }).parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  res.status(201).json(await prisma.automationWorkflow.create({ data: { ...d, userId: req.user!.id } }));
}));
automationRouter.post('/from-template', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), index: z.number().int().min(0) }).parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  const t = TEMPLATES[d.index]; if (!t) throw notFound('Template');
  res.status(201).json(await prisma.automationWorkflow.create({ data: { userId: req.user!.id, businessId: d.businessId, name: t.name, trigger: t.trigger, graph: t.graph } }));
}));
automationRouter.patch('/:id', ah(async (req, res) => {
  const d = z.object({ name: z.string().optional(), enabled: z.boolean().optional(), paused: z.boolean().optional(), graph: graphSchema.optional() }).parse(req.body);
  const w = await prisma.automationWorkflow.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null } });
  if (!w) throw notFound('Workflow');
  res.json(await prisma.automationWorkflow.update({ where: { id: w.id }, data: d }));
}));
automationRouter.delete('/:id', ah(async (req, res) => {
  const r = await prisma.automationWorkflow.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: { deletedAt: new Date(), enabled: false } });
  if (!r.count) throw notFound('Workflow');
  res.status(204).end();
}));
// Manual run / test
automationRouter.post('/:id/run', ah(async (req, res) => {
  const w = await prisma.automationWorkflow.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null } });
  if (!w) throw notFound('Workflow');
  res.status(202).json(await prisma.workflowRun.create({ data: { workflowId: w.id, userId: req.user!.id, triggerData: req.body?.data ?? {}, status: 'QUEUED' } }));
}));
automationRouter.get('/runs', ah(async (req, res) => {
  const { workflowId } = z.object({ workflowId: z.string().optional() }).parse(req.query);
  res.json(await prisma.workflowRun.findMany({ where: { userId: req.user!.id, ...(workflowId && { workflowId }) }, include: { workflow: { select: { name: true } } }, orderBy: { createdAt: 'desc' }, take: 100 }));
}));
automationRouter.post('/runs/:id/resume', ah(async (req, res) => {
  const run = await prisma.workflowRun.findFirst({ where: { id: req.params.id, userId: req.user!.id }, include: { workflow: true } });
  if (!run) throw notFound('Run');
  if (run.status !== 'PAUSED') throw new HttpError(409, 'Run is not paused');
  if (run.workflow.paused) throw new HttpError(409, 'Workflow is paused; resume the workflow first');
  res.json(await prisma.workflowRun.update({ where: { id: run.id }, data: { status: 'QUEUED' } }));
}));
automationRouter.post('/runs/:id/retry', ah(async (req, res) => {
  const run = await prisma.workflowRun.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!run || run.status !== 'FAILED') throw new HttpError(409, 'Only failed runs can be retried');
  res.json(await prisma.workflowRun.update({ where: { id: run.id }, data: { status: 'QUEUED', error: null, attempts: { increment: 1 } } }));
}));
void executeRun;
