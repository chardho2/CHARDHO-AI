import { Router } from 'express';
import { z } from 'zod';
import { Platform } from '@prisma/client';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { notFound } from '../lib/errors';
import { createContent, editContent } from '../services/content';
import { runAgent } from '../services/orchestrator';
import { AGENTS } from '../agents/definitions';

export const contentRouter = Router();
contentRouter.use(requireAuth);

const platformEnum = z.enum(['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X']);
const TYPE_AGENT: Record<string, string> = { reel_script: 'video_agent', youtube_script: 'video_agent', blog: 'content_writer', seo_article: 'seo_specialist', ad_copy: 'content_writer', product_description: 'content_writer', newsletter: 'email_marketing', whatsapp: 'content_writer', campaign: 'marketing_manager', social_post: 'social_media_manager' };

contentRouter.get('/', ah(async (req, res) => {
  const q = z.object({ businessId: z.string(), status: z.string().optional(), type: z.string().optional() }).parse(req.query);
  await ownBusiness(req.user!.id, q.businessId);
  res.json(await prisma.contentItem.findMany({ where: { userId: req.user!.id, businessId: q.businessId, deletedAt: null, ...(q.status && { status: q.status as any }), ...(q.type && { type: q.type }) }, include: { versions: { orderBy: { version: 'desc' }, take: 1 } }, orderBy: { updatedAt: 'desc' }, take: 200 }));
}));
contentRouter.get('/:id', ah(async (req, res) => {
  const c = await prisma.contentItem.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null }, include: { versions: { orderBy: { version: 'desc' } }, approvals: true, jobs: true } });
  if (!c) throw notFound('Content');
  res.json(c);
}));

// Manual create
contentRouter.post('/', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), type: z.string().max(60), platform: platformEnum.optional(), title: z.string().max(300).optional(), body: z.string().min(1).max(20000), hashtags: z.array(z.string()).default([]), language: z.string().optional() }).parse(req.body);
  await ownBusiness(req.user!.id, b.businessId);
  res.status(201).json(await createContent({ ...b, userId: req.user!.id, platform: b.platform as Platform | undefined }));
}));

// Edit => new version, approvals invalidated
contentRouter.patch('/:id', ah(async (req, res) => {
  const b = z.object({ body: z.string().min(1).max(20000).optional(), hashtags: z.array(z.string()).optional(), title: z.string().max(300).optional(), mediaAssetIds: z.array(z.string()).max(10).optional() }).parse(req.body);
  const c = await prisma.contentItem.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null } });
  if (!c) throw notFound('Content');
  if (b.mediaAssetIds?.length) {
    const n = await prisma.mediaAsset.count({ where: { id: { in: b.mediaAssetIds }, userId: req.user!.id, businessId: c.businessId, deletedAt: null } });
    if (n !== b.mediaAssetIds.length) throw notFound('Media asset');
  }
  res.json(await editContent(c.id, req.user!.id, b));
}));
contentRouter.delete('/:id', ah(async (req, res) => {
  const c = await prisma.contentItem.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!c) throw notFound('Content');
  await prisma.publishingJob.updateMany({ where: { contentId: c.id, status: 'PENDING' }, data: { status: 'CANCELLED' } });
  await prisma.contentItem.update({ where: { id: c.id }, data: { deletedAt: new Date(), status: c.status === 'PUBLISHED' ? 'PUBLISHED' : 'CANCELLED' } });
  res.status(204).end();
}));

const genSchema = z.object({
  businessId: z.string(), type: z.string().default('social_post'), platform: platformEnum.optional(),
  prompt: z.string().min(3).max(3000), language: z.string().max(30).optional(), tone: z.string().max(60).optional(),
  audience: z.string().max(200).optional(), length: z.enum(['short', 'medium', 'long']).optional(), count: z.number().int().min(1).max(10).default(1),
});
// Generate (also covers regenerate: call again with same prompt)
contentRouter.post('/generate', ah(async (req, res) => {
  const b = genSchema.parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  const agentKey = TYPE_AGENT[b.type] ?? 'content_writer';
  if (!AGENTS.find((a) => a.key === agentKey)) throw notFound('Agent');
  const request = `Create ${b.count} ${b.type.replace(/_/g, ' ')} draft(s)${b.platform ? ` for ${b.platform}` : ''}. ${b.prompt}`;
  const task = await runAgent({ userId: req.user!.id, business, agentKey, input: { request, language: b.language, tone: b.tone, audience: b.audience, length: b.length, priorOutputs: [] } });
  const ids = ((task.output as any)?.savedContentIds ?? []) as string[];
  const items = ids.length ? await prisma.contentItem.findMany({ where: { id: { in: ids }, userId: req.user!.id }, include: { versions: true } }) : [];
  res.status(task.status === 'SUCCEEDED' ? 200 : 502).json({ task, items });
}));
// Batch generation across platforms
contentRouter.post('/generate/batch', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), prompt: z.string().min(3).max(3000), platforms: z.array(platformEnum).min(1).max(5), language: z.string().optional(), tone: z.string().optional() }).parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  const task = await runAgent({ userId: req.user!.id, business, agentKey: 'social_media_manager', input: { request: `Create one platform-native post for EACH of: ${b.platforms.join(', ')}. ${b.prompt}`, language: b.language, tone: b.tone, priorOutputs: [] } });
  res.status(task.status === 'SUCCEEDED' ? 200 : 502).json(task);
}));
