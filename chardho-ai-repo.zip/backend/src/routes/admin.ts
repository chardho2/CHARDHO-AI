import { Router } from 'express';
import os from 'os';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth, requireRole, roleRank } from '../middleware/auth';
import { HttpError, notFound } from '../lib/errors';
import { encrypt } from '../lib/crypto';
import { audit } from '../lib/audit';
import { AGENTS } from '../agents/definitions';
import { dailyLimit } from '../services/usage';

export const adminRouter = Router();
adminRouter.use(requireAuth, requireRole('ADMIN'));

adminRouter.get('/overview', ah(async (_req, res) => {
  const since = new Date(Date.now() - 86_400_000);
  const [users, businesses, tasks24, failed24, content, costs, wfFailed, openTickets] = await Promise.all([
    prisma.user.count({ where: { deletedAt: null } }), prisma.business.count({ where: { deletedAt: null } }),
    prisma.agentTask.count({ where: { createdAt: { gte: since } } }), prisma.agentTask.count({ where: { createdAt: { gte: since }, status: 'FAILED' } }),
    prisma.contentItem.count(), prisma.apiProviderCost.aggregate({ _sum: { costUsd: true, tokensIn: true, tokensOut: true } }),
    prisma.workflowRun.count({ where: { status: 'FAILED' } }), prisma.supportTicket.count({ where: { status: 'open' } }),
  ]);
  res.json({ users, businesses, tasks24, failed24, content, tokens: costs._sum, totalCostUsd: costs._sum.costUsd ?? 0, failedWorkflowRuns: wfFailed, openTickets, dailyLimit: await dailyLimit() });
}));
adminRouter.get('/server', ah(async (_req, res) => {
  res.json({ uptimeSec: Math.round(process.uptime()), node: process.version, memoryMb: Math.round(process.memoryUsage().rss / 1048576), load: os.loadavg(), totalMemMb: Math.round(os.totalmem() / 1048576), freeMemMb: Math.round(os.freemem() / 1048576), cpus: os.cpus().length });
}));

// Users. Role matrix: OWNER manages everyone; SUPER_ADMIN manages ADMIN/USER; ADMIN can only disable/enable USER accounts.
adminRouter.get('/users', ah(async (_req, res) => {
  res.json(await prisma.user.findMany({ where: { deletedAt: null }, select: { id: true, email: true, name: true, role: true, emailVerifiedAt: true, disabledAt: true, createdAt: true }, orderBy: { createdAt: 'desc' }, take: 500 }));
}));
adminRouter.patch('/users/:id', ah(async (req, res) => {
  const d = z.object({ role: z.enum(['OWNER', 'SUPER_ADMIN', 'ADMIN', 'USER']).optional(), disabled: z.boolean().optional() }).parse(req.body);
  const actor = req.user!;
  const target = await prisma.user.findFirst({ where: { id: req.params.id, deletedAt: null } });
  if (!target) throw notFound('User');
  if (target.id === actor.id && (d.disabled || d.role)) throw new HttpError(400, 'You cannot change your own role or disable yourself');
  if (roleRank(target.role) >= roleRank(actor.role) && actor.role !== 'OWNER') throw new HttpError(403, 'Cannot manage a user of equal or higher role');
  if (d.role) {
    if (roleRank(actor.role) < roleRank('SUPER_ADMIN')) throw new HttpError(403, 'Only Super Admin or Owner can change roles');
    if (roleRank(d.role) >= roleRank(actor.role) && actor.role !== 'OWNER') throw new HttpError(403, 'Cannot grant a role equal or higher than your own');
    if (d.role === 'OWNER') throw new HttpError(403, 'Ownership transfer is not available via the API');
  }
  const u = await prisma.user.update({ where: { id: target.id }, data: { ...(d.role && { role: d.role }), ...(d.disabled !== undefined && { disabledAt: d.disabled ? new Date() : null, tokenVersion: { increment: 1 } }) } });
  await audit(actor.id, 'admin.user_update', 'User', u.id, d);
  res.json({ id: u.id, role: u.role, disabled: !!u.disabledAt });
}));

// Agents
adminRouter.get('/agents', ah(async (_req, res) => {
  const rows = await prisma.aiAgent.findMany();
  res.json(AGENTS.map((a) => { const r = rows.find((x) => x.key === a.key); return { key: a.key, name: a.name, enabled: r?.enabled ?? true, systemPrompt: r?.systemPrompt ?? a.systemPrompt, customized: !!r && r.systemPrompt !== a.systemPrompt }; }));
}));
adminRouter.patch('/agents/:key', requireRole('SUPER_ADMIN'), ah(async (req, res) => {
  const d = z.object({ enabled: z.boolean().optional(), systemPrompt: z.string().min(20).max(8000).optional() }).parse(req.body);
  if (!AGENTS.find((a) => a.key === req.params.key)) throw notFound('Agent');
  const r = await prisma.aiAgent.update({ where: { key: req.params.key }, data: d });
  await audit(req.user!.id, 'admin.agent_update', 'AiAgent', r.key, { enabled: d.enabled, promptChanged: !!d.systemPrompt });
  res.json(r);
}));

// Providers (secrets are write-only)
adminRouter.get('/providers', ah(async (_req, res) => {
  const [rows, cost] = await Promise.all([prisma.providerConfig.findMany({ orderBy: { priority: 'asc' } }), prisma.apiProviderCost.groupBy({ by: ['provider'], _sum: { costUsd: true, tokensIn: true, tokensOut: true }, _count: true })]);
  res.json(rows.map(({ apiKeyEnc, ...r }) => ({ ...r, hasApiKey: !!apiKeyEnc, usage: cost.find((c) => c.provider === r.key) ?? null })));
}));
adminRouter.patch('/providers/:key', requireRole('SUPER_ADMIN'), ah(async (req, res) => {
  const d = z.object({ enabled: z.boolean().optional(), model: z.string().min(1).max(100).optional(), priority: z.number().int().min(0).max(1000).optional(), dailyLimit: z.number().int().min(0).nullable().optional(), baseUrl: z.string().url().nullable().optional(), apiKey: z.string().min(8).max(500).optional(), paid: z.boolean().optional() }).parse(req.body);
  const { apiKey, ...rest } = d;
  if (d.paid === false && req.user!.role !== 'OWNER') throw new HttpError(403, 'Only the Owner can mark a provider as free');
  const r = await prisma.providerConfig.update({ where: { key: req.params.key }, data: { ...rest, ...(apiKey && { apiKeyEnc: encrypt(apiKey) }) } });
  await audit(req.user!.id, 'admin.provider_update', 'ProviderConfig', r.key, { ...rest, apiKeyChanged: !!apiKey });
  const { apiKeyEnc, ...safe } = r; res.json({ ...safe, hasApiKey: !!apiKeyEnc });
}));
adminRouter.post('/providers', requireRole('OWNER'), ah(async (req, res) => {
  // register an additional OpenAI-compatible provider (Groq, OpenRouter, vLLM...)
  const d = z.object({ key: z.string().regex(/^[a-z0-9_-]{2,30}$/), name: z.string(), model: z.string(), baseUrl: z.string().url(), apiKey: z.string().optional(), paid: z.boolean().default(true) }).parse(req.body);
  const { apiKey, ...rest } = d;
  res.status(201).json({ key: (await prisma.providerConfig.create({ data: { ...rest, capabilities: ['text', 'json'], apiKeyEnc: apiKey ? encrypt(apiKey) : null, priority: 80 } })).key, note: 'Custom providers are served through the OpenAI-compatible adapter once registered in providers/impl.ts' });
}));

// Settings: fair-use limits & security
adminRouter.get('/settings', ah(async (_req, res) => res.json(Object.fromEntries((await prisma.setting.findMany()).map((s) => [s.key, s.value])))));
adminRouter.put('/settings/:key', requireRole('SUPER_ADMIN'), ah(async (req, res) => {
  const key = z.enum(['dailyAiRequestLimit', 'registrationOpen', 'maintenanceMode']).parse(req.params.key);
  const value = z.object({ value: z.union([z.number().int().min(0).max(100000), z.boolean()]) }).parse(req.body).value;
  await prisma.setting.upsert({ where: { key }, create: { key, value }, update: { value } });
  await audit(req.user!.id, 'admin.setting', 'Setting', key, { value });
  res.json({ key, value });
}));

// Logs
adminRouter.get('/tasks', ah(async (req, res) => {
  const { status } = z.object({ status: z.string().optional() }).parse(req.query);
  res.json(await prisma.agentTask.findMany({ where: status ? { status: status as any } : {}, orderBy: { createdAt: 'desc' }, take: 200, select: { id: true, userId: true, agentKey: true, status: true, attempts: true, error: true, provider: true, model: true, tokensIn: true, tokensOut: true, createdAt: true, finishedAt: true } }));
}));
adminRouter.get('/workflows/failed', ah(async (_req, res) => res.json(await prisma.workflowRun.findMany({ where: { status: 'FAILED' }, include: { workflow: { select: { name: true } } }, orderBy: { createdAt: 'desc' }, take: 200 }))));
adminRouter.get('/publishing/failed', ah(async (_req, res) => res.json(await prisma.publishingJob.findMany({ where: { status: 'FAILED' }, orderBy: { createdAt: 'desc' }, take: 200, select: { id: true, error: true, attempts: true, createdAt: true, account: { select: { platform: true } } } }))));
adminRouter.get('/audit', requireRole('SUPER_ADMIN'), ah(async (_req, res) => res.json(await prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 300 }))));

// Announcements
adminRouter.get('/announcements', ah(async (_req, res) => res.json(await prisma.announcement.findMany({ orderBy: { createdAt: 'desc' } }))));
adminRouter.post('/announcements', ah(async (req, res) => {
  const d = z.object({ title: z.string().min(1).max(200), body: z.string().min(1).max(2000) }).parse(req.body);
  res.status(201).json(await prisma.announcement.create({ data: d }));
}));
adminRouter.patch('/announcements/:id', ah(async (req, res) => res.json(await prisma.announcement.update({ where: { id: req.params.id }, data: z.object({ active: z.boolean() }).parse(req.body) }))));

// Support
adminRouter.get('/tickets', ah(async (_req, res) => res.json(await prisma.supportTicket.findMany({ include: { user: { select: { email: true } } }, orderBy: { createdAt: 'desc' }, take: 200 }))));
adminRouter.patch('/tickets/:id', ah(async (req, res) => res.json(await prisma.supportTicket.update({ where: { id: req.params.id }, data: z.object({ status: z.enum(['open', 'in_progress', 'closed']) }).parse(req.body) }))));

// Integrations registry
adminRouter.get('/integrations', ah(async (_req, res) => res.json(await prisma.integration.findMany({ select: { key: true, name: true, enabled: true, status: true, updatedAt: true } }))));

// Platform analytics
adminRouter.get('/analytics', ah(async (_req, res) => {
  const [usersByDay, tasksByAgent] = await Promise.all([
    prisma.$queryRaw<{ day: Date; n: bigint }[]>`SELECT date_trunc('day', "createdAt") AS day, count(*)::bigint AS n FROM "User" GROUP BY 1 ORDER BY 1 DESC LIMIT 30`,
    prisma.agentTask.groupBy({ by: ['agentKey', 'status'], _count: true }),
  ]);
  res.json({ signupsByDay: usersByDay.map((r) => ({ day: r.day, n: Number(r.n) })), tasksByAgent });
}));
