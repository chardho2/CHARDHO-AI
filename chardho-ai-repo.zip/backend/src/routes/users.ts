import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { audit } from '../lib/audit';

export const usersRouter = Router();
usersRouter.use(requireAuth);

usersRouter.patch('/me', ah(async (req, res) => {
  const d = z.object({ name: z.string().min(1).max(100).optional(), locale: z.string().max(10).optional() }).parse(req.body);
  const u = await prisma.user.update({ where: { id: req.user!.id }, data: d });
  res.json({ id: u.id, email: u.email, name: u.name, locale: u.locale });
}));

// GDPR-style data export
usersRouter.get('/me/export', ah(async (req, res) => {
  const id = req.user!.id;
  const [user, businesses, tasks, content, leads, influencers, usage] = await Promise.all([
    prisma.user.findUnique({ where: { id }, select: { id: true, email: true, name: true, createdAt: true, locale: true } }),
    prisma.business.findMany({ where: { userId: id } }),
    prisma.agentTask.findMany({ where: { userId: id } }),
    prisma.contentItem.findMany({ where: { userId: id }, include: { versions: true } }),
    prisma.lead.findMany({ where: { userId: id } }),
    prisma.influencer.findMany({ where: { userId: id } }),
    prisma.usageRecord.findMany({ where: { userId: id } }),
  ]);
  await audit(id, 'user.export', 'User', id);
  res.setHeader('content-disposition', 'attachment; filename="chardho-export.json"');
  res.json({ exportedAt: new Date(), user, businesses, tasks, content, leads, influencers, usage });
}));

// Account deletion: hard-delete user data (cascades), anonymise audit trail.
usersRouter.delete('/me', ah(async (req, res) => {
  const { confirm } = z.object({ confirm: z.literal('DELETE') }).parse(req.body);
  void confirm;
  const id = req.user!.id;
  await audit(id, 'user.delete', 'User', id);
  await prisma.$transaction([
    prisma.publishingJob.updateMany({ where: { account: { userId: id }, status: { in: ['PENDING'] } }, data: { status: 'CANCELLED' } }),
    prisma.user.delete({ where: { id } }),
  ]);
  res.status(204).end();
}));
