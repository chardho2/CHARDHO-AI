import { Router } from 'express';
import multer from 'multer';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { allowPaid, env } from '../lib/env';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { HttpError, notFound } from '../lib/errors';
import { decrypt } from '../lib/crypto';
import { assertWithinFairUse, recordUsage } from '../services/usage';
import { runAgent } from '../services/orchestrator';

export const STORAGE_DIR = process.env.MEDIA_DIR || path.resolve(process.cwd(), 'storage/media');
const MAX = 5 * 1024 * 1024;
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX, files: 1 } });

// Validate by magic bytes, never by client-supplied mime/extension.
function sniff(buf: Buffer): { mime: string; ext: string } | null {
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  if (buf.subarray(0, 3).toString() === 'GIF') return { mime: 'image/gif', ext: 'gif' };
  return null;
}
async function store(userId: string, businessId: string, buf: Buffer, extra: { kind: string; prompt?: string; aspect?: string }) {
  const t = sniff(buf);
  if (!t) throw new HttpError(415, 'Unsupported file type. Allowed: PNG, JPEG, WEBP, GIF');
  await fs.mkdir(STORAGE_DIR, { recursive: true });
  const file = `${crypto.randomUUID()}.${t.ext}`;
  await fs.writeFile(path.join(STORAGE_DIR, file), buf, { flag: 'wx' });
  return prisma.mediaAsset.create({ data: { userId, businessId, kind: extra.kind, mimeType: t.mime, path: file, sizeBytes: buf.length, prompt: extra.prompt, aspect: extra.aspect } });
}

// Public asset endpoint (needed so Instagram/Facebook can fetch the image). IDs are unguessable cuids; only images are ever stored.
export const mediaPublicRouter = Router();
mediaPublicRouter.get('/:id', ah(async (req, res) => {
  const a = await prisma.mediaAsset.findFirst({ where: { id: req.params.id, deletedAt: null } });
  if (!a) throw notFound('Media');
  res.setHeader('content-type', a.mimeType);
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('content-security-policy', "default-src 'none'");
  res.sendFile(path.join(STORAGE_DIR, path.basename(a.path)));
}));

export const mediaRouter = Router();
mediaRouter.use(requireAuth);

mediaRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.mediaAsset.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null }, orderBy: { createdAt: 'desc' }, take: 100 }));
}));
mediaRouter.post('/upload', upload.single('file'), ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.body);
  await ownBusiness(req.user!.id, businessId);
  if (!req.file) throw new HttpError(400, 'file is required');
  res.status(201).json(await store(req.user!.id, businessId, req.file.buffer, { kind: 'upload' }));
}));
mediaRouter.delete('/:id', ah(async (req, res) => {
  const a = await prisma.mediaAsset.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!a) throw notFound('Media');
  await prisma.mediaAsset.update({ where: { id: a.id }, data: { deletedAt: new Date() } });
  await fs.rm(path.join(STORAGE_DIR, path.basename(a.path)), { force: true });
  res.status(204).end();
}));

const ASPECT: Record<string, string> = { '1:1': '1024x1024', '4:5': '1024x1024', '9:16': '1024x1792', '16:9': '1792x1024' };
mediaRouter.post('/generate', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), prompt: z.string().min(3).max(1500), aspect: z.enum(['1:1', '4:5', '9:16', '16:9']).default('1:1') }).parse(req.body);
  const business = await ownBusiness(req.user!.id, b.businessId);
  await assertWithinFairUse(req.user!.id);
  const cfg = await prisma.providerConfig.findUnique({ where: { key: 'openai' } });
  const key = cfg?.apiKeyEnc ? decrypt(cfg.apiKeyEnc) : env.OPENAI_API_KEY;
  // Image generation currently needs a paid provider -> only with explicit owner authorisation.
  if (!(allowPaid && cfg?.enabled && key && cfg.capabilities.includes('image'))) {
    const task = await runAgent({ userId: req.user!.id, business, agentKey: 'image_agent', input: { request: `Write an image-generation prompt and platform variants for: ${b.prompt} (aspect ${b.aspect})`, priorOutputs: [] } });
    return res.status(200).json({ status: 'provider_unavailable', message: 'No image-generation provider is enabled by the platform owner. A creative brief was generated instead.', task });
  }
  const r = await fetch(`${cfg.baseUrl || 'https://api.openai.com/v1'}/images/generations`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` }, body: JSON.stringify({ model: 'dall-e-3', prompt: b.prompt, size: ASPECT[b.aspect], response_format: 'b64_json', n: 1 }) });
  if (!r.ok) throw new HttpError(502, `Image provider error ${r.status}`);
  const data = (await r.json()) as any;
  const asset = await store(req.user!.id, b.businessId, Buffer.from(data.data[0].b64_json, 'base64'), { kind: 'generated', prompt: b.prompt, aspect: b.aspect });
  await recordUsage({ userId: req.user!.id, kind: 'ai_request', agentKey: 'image_agent', provider: 'openai', model: 'dall-e-3' });
  await prisma.apiProviderCost.create({ data: { provider: 'openai', model: 'dall-e-3', tokensIn: 0, tokensOut: 0, costUsd: 0.04 } });
  res.status(201).json({ status: 'ok', asset });
}));
