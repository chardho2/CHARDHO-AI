import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { prisma } from '../lib/db';
import { env } from '../lib/env';
import { ah } from '../middleware/error';
import { requireAuth, signAccess } from '../middleware/auth';
import { HttpError } from '../lib/errors';
import { randomToken, sha256 } from '../lib/crypto';
import { sendMail } from '../lib/mail';
import { audit } from '../lib/audit';

export const authRouter = Router();
const strict = rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: true, legacyHeaders: false });

const password = z.string().min(10).max(128).regex(/[a-z]/).regex(/[A-Z]/).regex(/[0-9]/, 'Needs upper, lower and digit');

async function issueToken(userId: string, type: 'EMAIL_VERIFY' | 'PASSWORD_RESET', ttlMin: number) {
  const raw = randomToken();
  await prisma.authToken.create({ data: { userId, type, tokenHash: sha256(raw), expiresAt: new Date(Date.now() + ttlMin * 60_000) } });
  return raw;
}
async function consumeToken(raw: string, type: 'EMAIL_VERIFY' | 'PASSWORD_RESET') {
  const t = await prisma.authToken.findUnique({ where: { tokenHash: sha256(raw) } });
  if (!t || t.type !== type || t.usedAt || t.expiresAt < new Date()) throw new HttpError(400, 'Invalid or expired token');
  await prisma.authToken.update({ where: { id: t.id }, data: { usedAt: new Date() } });
  return t.userId;
}
const publicUser = (u: { id: string; email: string; name: string | null; role: string; emailVerifiedAt: Date | null }) =>
  ({ id: u.id, email: u.email, name: u.name, role: u.role, emailVerified: !!u.emailVerifiedAt });

authRouter.post('/register', strict, ah(async (req, res) => {
  const { email, password: pw, name } = z.object({ email: z.string().email().toLowerCase(), password, name: z.string().min(1).max(100) }).parse(req.body);
  if (await prisma.user.findUnique({ where: { email } })) throw new HttpError(409, 'Email already registered');
  const user = await prisma.user.create({ data: { email, name, passwordHash: await bcrypt.hash(pw, 12) } });
  const raw = await issueToken(user.id, 'EMAIL_VERIFY', 24 * 60);
  await sendMail(email, 'Verify your CHARDHO AI account', `Verify: ${env.APP_URL}/verify-email?token=${raw}`);
  await audit(user.id, 'auth.register', 'User', user.id, undefined, req.ip);
  res.status(201).json({ message: 'Registered. Check your email to verify your account.' });
}));

authRouter.post('/verify-email', strict, ah(async (req, res) => {
  const { token } = z.object({ token: z.string() }).parse(req.body);
  const userId = await consumeToken(token, 'EMAIL_VERIFY');
  await prisma.user.update({ where: { id: userId }, data: { emailVerifiedAt: new Date() } });
  res.json({ message: 'Email verified' });
}));

authRouter.post('/login', strict, ah(async (req, res) => {
  const { email, password: pw } = z.object({ email: z.string().email().toLowerCase(), password: z.string() }).parse(req.body);
  const user = await prisma.user.findUnique({ where: { email } });
  // constant-ish time: always compare against some hash
  const ok = await bcrypt.compare(pw, user?.passwordHash ?? '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
  if (!user || !ok || user.deletedAt || user.disabledAt) throw new HttpError(401, 'Invalid credentials');
  if (!user.emailVerifiedAt) throw new HttpError(403, 'Please verify your email first');
  await audit(user.id, 'auth.login', 'User', user.id, undefined, req.ip);
  res.json({ token: signAccess(user), user: publicUser(user) });
}));

authRouter.post('/forgot-password', strict, ah(async (req, res) => {
  const { email } = z.object({ email: z.string().email().toLowerCase() }).parse(req.body);
  const user = await prisma.user.findUnique({ where: { email } });
  if (user && !user.deletedAt) {
    const raw = await issueToken(user.id, 'PASSWORD_RESET', 60);
    await sendMail(email, 'Reset your CHARDHO AI password', `Reset: ${env.APP_URL}/reset-password?token=${raw}`);
  }
  res.json({ message: 'If that email exists, a reset link has been sent.' }); // no user enumeration
}));

authRouter.post('/reset-password', strict, ah(async (req, res) => {
  const { token, password: pw } = z.object({ token: z.string(), password }).parse(req.body);
  const userId = await consumeToken(token, 'PASSWORD_RESET');
  await prisma.user.update({ where: { id: userId }, data: { passwordHash: await bcrypt.hash(pw, 12), tokenVersion: { increment: 1 } } });
  await audit(userId, 'auth.password_reset', 'User', userId, undefined, req.ip);
  res.json({ message: 'Password updated. Please log in.' });
}));

authRouter.post('/logout-all', requireAuth, ah(async (req, res) => {
  await prisma.user.update({ where: { id: req.user!.id }, data: { tokenVersion: { increment: 1 } } });
  res.json({ message: 'All sessions revoked' });
}));

authRouter.get('/me', requireAuth, ah(async (req, res) => {
  const u = await prisma.user.findUniqueOrThrow({ where: { id: req.user!.id } });
  res.json(publicUser(u));
}));

// ---- Google OAuth (authorization code flow, signed `state`) ----
authRouter.get('/google', (_req, res) => {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) return res.status(501).json({ error: 'Google OAuth is not configured' });
  const state = jwt.sign({ n: randomToken() }, env.JWT_SECRET, { expiresIn: '10m' });
  const q = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID, redirect_uri: `${env.API_URL}/api/auth/google/callback`,
    response_type: 'code', scope: 'openid email profile', state, access_type: 'online', prompt: 'select_account',
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${q}`);
});

authRouter.get('/google/callback', ah(async (req, res) => {
  const { code, state } = z.object({ code: z.string(), state: z.string() }).parse(req.query);
  try { jwt.verify(state, env.JWT_SECRET); } catch { throw new HttpError(400, 'Invalid OAuth state'); }
  const tr = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ code, client_id: env.GOOGLE_CLIENT_ID!, client_secret: env.GOOGLE_CLIENT_SECRET!, redirect_uri: `${env.API_URL}/api/auth/google/callback`, grant_type: 'authorization_code' }),
  });
  if (!tr.ok) throw new HttpError(400, 'Google token exchange failed');
  const { access_token } = (await tr.json()) as { access_token: string };
  const ur = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { authorization: `Bearer ${access_token}` } });
  const info = (await ur.json()) as { sub: string; email: string; email_verified: boolean; name?: string };
  if (!info.email_verified) throw new HttpError(400, 'Google email not verified');
  const email = info.email.toLowerCase();
  let user = await prisma.user.findFirst({ where: { OR: [{ googleId: info.sub }, { email }] } });
  if (user?.deletedAt || user?.disabledAt) throw new HttpError(403, 'Account disabled');
  user = user
    ? await prisma.user.update({ where: { id: user.id }, data: { googleId: info.sub, emailVerifiedAt: user.emailVerifiedAt ?? new Date() } })
    : await prisma.user.create({ data: { email, name: info.name, googleId: info.sub, emailVerifiedAt: new Date() } });
  await audit(user.id, 'auth.google_login', 'User', user.id, undefined, req.ip);
  // token passed in URL fragment (never sent to servers / logs)
  res.redirect(`${env.APP_URL}/oauth-complete#token=${signAccess(user)}`);
}));
