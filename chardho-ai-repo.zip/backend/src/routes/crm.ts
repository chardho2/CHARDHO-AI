import { Router } from 'express';
import { z } from 'zod';
import { Platform } from '@prisma/client';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';
import { HttpError, notFound } from '../lib/errors';
import { generateText } from '../providers/manager';
import { assertWithinFairUse, recordUsage } from '../services/usage';

// ---------- Leads ----------
export const leadsRouter = Router();
leadsRouter.use(requireAuth);

export const dedupeKey = (l: { email?: string | null; phone?: string | null; businessName?: string | null; contactName?: string | null }) =>
  (l.email?.trim().toLowerCase() || l.phone?.replace(/\D/g, '') || `${(l.businessName ?? '').trim().toLowerCase()}|${(l.contactName ?? '').trim().toLowerCase()}`);

export function scoreLead(l: { email?: string | null; phone?: string | null; businessName?: string | null; industry?: string | null; status?: string }): number {
  let s = 0;
  if (l.email) s += 25; if (l.phone) s += 15; if (l.businessName) s += 10; if (l.industry) s += 10;
  s += ({ new: 0, contacted: 10, qualified: 30, won: 40, lost: -20 } as Record<string, number>)[l.status ?? 'new'] ?? 0;
  return Math.max(0, Math.min(100, s));
}

const leadSchema = z.object({
  businessId: z.string(), source: z.string().min(1).max(100), businessName: z.string().max(200).optional(), contactName: z.string().max(200).optional(),
  email: z.string().email().optional(), phone: z.string().max(40).optional(),
  // Authorized sources only: capture why we may contact this person.
  consentBasis: z.string().min(2).max(300), industry: z.string().max(100).optional(), status: z.enum(['new', 'contacted', 'qualified', 'won', 'lost']).default('new'),
  assignedToId: z.string().optional(), notes: z.string().max(4000).optional(),
});

leadsRouter.get('/', ah(async (req, res) => {
  const q = z.object({ businessId: z.string(), status: z.string().optional(), q: z.string().optional() }).parse(req.query);
  await ownBusiness(req.user!.id, q.businessId);
  res.json(await prisma.lead.findMany({ where: { userId: req.user!.id, businessId: q.businessId, deletedAt: null, ...(q.status && { status: q.status }), ...(q.q && { OR: [{ businessName: { contains: q.q, mode: 'insensitive' } }, { contactName: { contains: q.q, mode: 'insensitive' } }, { email: { contains: q.q, mode: 'insensitive' } }] }) }, orderBy: { score: 'desc' }, take: 500 }));
}));
leadsRouter.post('/', ah(async (req, res) => {
  const d = leadSchema.parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  const key = dedupeKey(d);
  const dup = await prisma.lead.findUnique({ where: { businessId_dedupeKey: { businessId: d.businessId, dedupeKey: key } } });
  if (dup && !dup.deletedAt) throw new HttpError(409, 'Duplicate lead', { existingId: dup.id });
  const data = { ...d, userId: req.user!.id, dedupeKey: key, score: scoreLead(d), activity: [{ at: new Date().toISOString(), event: 'created' }] };
  res.status(201).json(dup ? await prisma.lead.update({ where: { id: dup.id }, data: { ...data, deletedAt: null } }) : await prisma.lead.create({ data }));
}));
leadsRouter.patch('/:id', ah(async (req, res) => {
  const l = await prisma.lead.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null } });
  if (!l) throw notFound('Lead');
  const d = leadSchema.omit({ businessId: true }).partial().parse(req.body);
  const merged = { ...l, ...d };
  const activity = [...((l.activity as any[]) ?? []), ...(d.status && d.status !== l.status ? [{ at: new Date().toISOString(), event: `status:${l.status}->${d.status}` }] : []), ...(d.notes && d.notes !== l.notes ? [{ at: new Date().toISOString(), event: 'note_updated' }] : [])];
  res.json(await prisma.lead.update({ where: { id: l.id }, data: { ...d, score: scoreLead(merged), activity } }));
}));
leadsRouter.delete('/:id', ah(async (req, res) => {
  const r = await prisma.lead.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: { deletedAt: new Date() } });
  if (!r.count) throw notFound('Lead');
  res.status(204).end();
}));

// CSV (RFC4180-ish parser, with formula-injection guard on export)
function parseCsv(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let cur = ''; let q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some((x) => x.trim())) rows.push(row); row = []; }
    else cur += c;
  }
  row.push(cur); if (row.some((x) => x.trim())) rows.push(row);
  return rows;
}
const csvCell = (v: unknown) => { let s = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

leadsRouter.post('/import', ah(async (req, res) => {
  const b = z.object({ businessId: z.string(), csv: z.string().max(2_000_000), consentBasis: z.string().min(2).max(300), source: z.string().default('csv_import') }).parse(req.body);
  await ownBusiness(req.user!.id, b.businessId);
  const [head, ...rows] = parseCsv(b.csv);
  if (!head) throw new HttpError(400, 'Empty CSV');
  const idx = (n: string) => head.findIndex((h) => h.trim().toLowerCase() === n);
  const cols = { businessName: idx('businessname'), contactName: idx('contactname'), email: idx('email'), phone: idx('phone'), industry: idx('industry') };
  let created = 0, duplicates = 0, invalid = 0;
  for (const r of rows.slice(0, 5000)) {
    const get = (i: number) => (i >= 0 ? r[i]?.trim() || undefined : undefined);
    const l = { businessName: get(cols.businessName), contactName: get(cols.contactName), email: get(cols.email), phone: get(cols.phone), industry: get(cols.industry) };
    if ((l.email && !z.string().email().safeParse(l.email).success) || (!l.email && !l.phone && !l.businessName)) { invalid++; continue; }
    const key = dedupeKey(l);
    try {
      await prisma.lead.create({ data: { ...l, userId: req.user!.id, businessId: b.businessId, source: b.source, consentBasis: b.consentBasis, dedupeKey: key, score: scoreLead(l), activity: [{ at: new Date().toISOString(), event: 'imported' }] } });
      created++;
    } catch { duplicates++; }
  }
  res.json({ created, duplicates, invalid });
}));
leadsRouter.get('/export', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  const rows = await prisma.lead.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null } });
  const head = ['businessName', 'contactName', 'email', 'phone', 'industry', 'source', 'status', 'score', 'consentBasis', 'notes'];
  res.setHeader('content-type', 'text/csv; charset=utf-8');
  res.setHeader('content-disposition', 'attachment; filename="leads.csv"');
  res.send([head.join(','), ...rows.map((r) => head.map((h) => csvCell((r as any)[h])).join(','))].join('\n'));
}));

leadsRouter.post('/:id/outreach', ah(async (req, res) => {
  const l = await prisma.lead.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null }, include: { business: true } });
  if (!l) throw notFound('Lead');
  if (!l.consentBasis) throw new HttpError(422, 'Record the consent/lawful basis before generating outreach');
  await assertWithinFairUse(req.user!.id);
  const r = await generateText({ system: 'You write a short, honest, one-to-one business outreach email. Include a clear opt-out line. Never fabricate facts about the recipient. Return JSON {"subject":string,"body":string}.', prompt: JSON.stringify({ sender: { name: l.business.name, description: l.business.description }, recipient: { name: l.contactName, company: l.businessName, industry: l.industry }, basis: l.consentBasis }), json: true }, ['text', 'json']);
  await recordUsage({ userId: req.user!.id, kind: 'ai_request', agentKey: 'lead_gen', provider: r.provider, model: r.model, tokensIn: r.tokensIn, tokensOut: r.tokensOut });
  res.json({ draft: JSON.parse(r.text.replace(/^```json|```$/g, '').trim()), note: 'Draft only. Review and send yourself; CHARDHO AI does not send bulk or unsolicited messages.' });
}));

// ---------- Influencers ----------
export const influencersRouter = Router();
influencersRouter.use(requireAuth);
const infSchema = z.object({
  businessId: z.string(), name: z.string().min(1).max(200), platform: z.enum(['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X']), handle: z.string().min(1).max(100),
  profileUrl: z.string().url().optional(), niche: z.string().max(100).optional(), country: z.string().max(100).optional(), audience: z.string().max(200).optional(),
  followers: z.number().int().min(0).optional(), engagement: z.number().min(0).max(100).optional(),
  metricsSource: z.string().max(300).optional(), contactEmail: z.string().email().optional(), notes: z.string().max(4000).optional(),
}).refine((d) => (d.followers == null && d.engagement == null) || !!d.metricsSource, { message: 'metricsSource is required when recording follower/engagement numbers (no unverified metrics)' });

// "Search" only queries influencers the user has recorded or imported from authorised sources. It never invents profiles.
influencersRouter.get('/', ah(async (req, res) => {
  const q = z.object({ businessId: z.string(), niche: z.string().optional(), country: z.string().optional(), platform: z.string().optional(), audience: z.string().optional() }).parse(req.query);
  await ownBusiness(req.user!.id, q.businessId);
  res.json({
    results: await prisma.influencer.findMany({ where: { userId: req.user!.id, businessId: q.businessId, deletedAt: null, ...(q.niche && { niche: { contains: q.niche, mode: 'insensitive' } }), ...(q.country && { country: { contains: q.country, mode: 'insensitive' } }), ...(q.platform && { platform: q.platform.toUpperCase() as Platform }), ...(q.audience && { audience: { contains: q.audience, mode: 'insensitive' } }) }, orderBy: { createdAt: 'desc' }, take: 200 }),
    note: 'Results are limited to influencers you have added with a stated data source. CHARDHO AI does not fabricate influencer identities or metrics.',
  });
}));
influencersRouter.post('/', ah(async (req, res) => {
  const d = infSchema.parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  const platform = d.platform as Platform;
  res.status(201).json(await prisma.influencer.create({ data: { ...d, platform, userId: req.user!.id, metricsVerifiedAt: d.metricsSource ? new Date() : null } }).catch(() => { throw new HttpError(409, 'Influencer already recorded for this platform/handle'); }));
}));
influencersRouter.delete('/:id', ah(async (req, res) => {
  const r = await prisma.influencer.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: { deletedAt: new Date() } });
  if (!r.count) throw notFound('Influencer');
  res.status(204).end();
}));
influencersRouter.post('/:id/analyze', ah(async (req, res) => {
  const i = await prisma.influencer.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null }, include: { business: true } });
  if (!i) throw notFound('Influencer');
  await assertWithinFairUse(req.user!.id);
  const r = await generateText({ system: 'You assess influencer-brand fit using ONLY the data provided. If data is missing, say so. Return JSON {"fitScore":number 0-100,"reasons":string[],"risks":string[],"missingData":string[]}.', prompt: JSON.stringify({ brand: { name: i.business.name, audience: i.business.targetAudience, industry: i.business.industry }, influencer: { niche: i.niche, country: i.country, audience: i.audience, followers: i.followers, engagement: i.engagement, metricsSource: i.metricsSource } }), json: true }, ['text', 'json']);
  await recordUsage({ userId: req.user!.id, kind: 'ai_request', agentKey: 'influencer_manager', provider: r.provider, model: r.model, tokensIn: r.tokensIn, tokensOut: r.tokensOut });
  res.json(JSON.parse(r.text.replace(/^```json|```$/g, '').trim()));
}));
influencersRouter.post('/:id/outreach', ah(async (req, res) => {
  const b = z.object({ campaignId: z.string().optional(), kind: z.enum(['proposal', 'email']).default('email') }).parse(req.body ?? {});
  const i = await prisma.influencer.findFirst({ where: { id: req.params.id, userId: req.user!.id, deletedAt: null }, include: { business: true } });
  if (!i) throw notFound('Influencer');
  await assertWithinFairUse(req.user!.id);
  const r = await generateText({ system: `Write a concise, honest collaboration ${b.kind}. Do not invent facts, rates or past work. Return JSON {"subject":string,"message":string}.`, prompt: JSON.stringify({ brand: { name: i.business.name, description: i.business.description }, influencer: { name: i.name, platform: i.platform, niche: i.niche } }), json: true }, ['text', 'json']);
  await recordUsage({ userId: req.user!.id, kind: 'ai_request', agentKey: 'influencer_manager', provider: r.provider, model: r.model, tokensIn: r.tokensIn, tokensOut: r.tokensOut });
  const o = JSON.parse(r.text.replace(/^```json|```$/g, '').trim());
  res.status(201).json(await prisma.influencerOutreach.create({ data: { userId: req.user!.id, influencerId: i.id, campaignId: b.campaignId, subject: o.subject, message: o.message } }));
}));
influencersRouter.patch('/outreach/:id', ah(async (req, res) => {
  const d = z.object({ status: z.enum(['draft', 'sent', 'replied', 'accepted', 'declined', 'completed']).optional(), response: z.string().max(4000).optional(), deliverables: z.array(z.object({ title: z.string(), dueDate: z.string().optional(), done: z.boolean().default(false) })).optional(), message: z.string().max(8000).optional() }).parse(req.body);
  const r = await prisma.influencerOutreach.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: d });
  if (!r.count) throw notFound('Outreach');
  res.json(await prisma.influencerOutreach.findUnique({ where: { id: req.params.id } }));
}));
influencersRouter.get('/outreach/list', ah(async (req, res) => {
  res.json(await prisma.influencerOutreach.findMany({ where: { userId: req.user!.id }, include: { influencer: { select: { name: true, platform: true, handle: true } } }, orderBy: { createdAt: 'desc' }, take: 200 }));
}));

// ---------- Campaigns ----------
export const campaignsRouter = Router();
campaignsRouter.use(requireAuth);
campaignsRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  await ownBusiness(req.user!.id, businessId);
  res.json(await prisma.campaign.findMany({ where: { userId: req.user!.id, businessId, deletedAt: null }, orderBy: { createdAt: 'desc' } }));
}));
campaignsRouter.post('/', ah(async (req, res) => {
  const d = z.object({ businessId: z.string(), name: z.string().min(1).max(200), kind: z.string().default('marketing'), objective: z.string().max(2000).optional(), startsAt: z.coerce.date().optional(), endsAt: z.coerce.date().optional() }).parse(req.body);
  await ownBusiness(req.user!.id, d.businessId);
  res.status(201).json(await prisma.campaign.create({ data: { ...d, userId: req.user!.id } }));
}));
campaignsRouter.patch('/:id', ah(async (req, res) => {
  const d = z.object({ name: z.string().optional(), status: z.enum(['planned', 'active', 'paused', 'completed']).optional(), objective: z.string().optional() }).parse(req.body);
  const r = await prisma.campaign.updateMany({ where: { id: req.params.id, userId: req.user!.id }, data: d });
  if (!r.count) throw notFound('Campaign');
  res.json(await prisma.campaign.findUnique({ where: { id: req.params.id } }));
}));
// Report built from real recorded data (no AI-invented numbers)
campaignsRouter.get('/:id/report', ah(async (req, res) => {
  const c = await prisma.campaign.findFirst({ where: { id: req.params.id, userId: req.user!.id }, include: { content: { include: { jobs: true } }, outreach: true } });
  if (!c) throw notFound('Campaign');
  const jobs = c.content.flatMap((x) => x.jobs);
  const report = {
    campaign: { id: c.id, name: c.name, status: c.status },
    content: { total: c.content.length, byStatus: c.content.reduce<Record<string, number>>((a, x) => ((a[x.status] = (a[x.status] ?? 0) + 1), a), {}) },
    publishing: { succeeded: jobs.filter((j) => j.status === 'SUCCEEDED').length, failed: jobs.filter((j) => j.status === 'FAILED').length, pending: jobs.filter((j) => j.status === 'PENDING').length },
    influencerOutreach: { total: c.outreach.length, byStatus: c.outreach.reduce<Record<string, number>>((a, x) => ((a[x.status] = (a[x.status] ?? 0) + 1), a), {}) },
    deliverables: c.outreach.flatMap((o) => ((o.deliverables as any[]) ?? [])),
  };
  await prisma.campaign.update({ where: { id: c.id }, data: { report } });
  res.json(report);
}));
