import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { ownBusiness } from '../middleware/ownership';

export const businessesRouter = Router();
businessesRouter.use(requireAuth);

const schema = z.object({
  name: z.string().min(1).max(150),
  website: z.string().url().optional().or(z.literal('')),
  industry: z.string().max(100).optional(),
  description: z.string().max(4000).optional(),
  productsServices: z.string().max(4000).optional(),
  location: z.string().max(200).optional(),
  targetAudience: z.string().max(2000).optional(),
  objectives: z.string().max(2000).optional(),
  competitors: z.array(z.string().max(200)).max(20).default([]),
  socialLinks: z.record(z.string().url()).optional(),
  languages: z.array(z.string().max(30)).max(10).default(['en']),
});

businessesRouter.get('/', ah(async (req, res) => {
  res.json(await prisma.business.findMany({ where: { userId: req.user!.id, deletedAt: null }, orderBy: { createdAt: 'desc' } }));
}));
businessesRouter.post('/', ah(async (req, res) => {
  const d = schema.parse(req.body);
  res.status(201).json(await prisma.business.create({ data: { ...d, website: d.website || null, userId: req.user!.id } }));
}));
businessesRouter.get('/:id', ah(async (req, res) => res.json(await ownBusiness(req.user!.id, req.params.id))));
businessesRouter.patch('/:id', ah(async (req, res) => {
  await ownBusiness(req.user!.id, req.params.id);
  const d = schema.partial().parse(req.body);
  res.json(await prisma.business.update({ where: { id: req.params.id }, data: { ...d, website: d.website === '' ? null : d.website } }));
}));
businessesRouter.delete('/:id', ah(async (req, res) => {
  await ownBusiness(req.user!.id, req.params.id);
  await prisma.business.update({ where: { id: req.params.id }, data: { deletedAt: new Date() } });
  res.status(204).end();
}));
