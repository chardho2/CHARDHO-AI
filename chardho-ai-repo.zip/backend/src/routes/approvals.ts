import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { ah } from '../middleware/error';
import { requireAuth } from '../middleware/auth';
import { approve, cancel, schedule, submitForReview } from '../services/approvals';

export const approvalsRouter = Router();
approvalsRouter.use(requireAuth);

// Approval center: everything awaiting or holding a decision
approvalsRouter.get('/', ah(async (req, res) => {
  const { businessId } = z.object({ businessId: z.string() }).parse(req.query);
  res.json(await prisma.contentItem.findMany({
    where: { userId: req.user!.id, businessId, deletedAt: null, status: { in: ['QUALITY_CHECKED', 'PENDING_APPROVAL', 'APPROVED', 'SCHEDULED', 'PUBLISHING', 'PUBLISHED', 'FAILED'] }, platform: { not: null } },
    include: { versions: { orderBy: { version: 'desc' }, take: 1 }, approvals: { orderBy: { approvedAt: 'desc' }, take: 1 }, jobs: { orderBy: { createdAt: 'desc' }, take: 1 } },
    orderBy: { updatedAt: 'desc' },
  }));
}));
approvalsRouter.post('/:contentId/submit', ah(async (req, res) => res.json(await submitForReview(req.user!.id, req.params.contentId))));
approvalsRouter.post('/:contentId/approve', ah(async (req, res) => {
  const b = z.object({ socialAccountId: z.string(), scheduledFor: z.coerce.date().optional() }).parse(req.body);
  res.json(await approve(req.user!.id, req.params.contentId, b.socialAccountId, b.scheduledFor));
}));
approvalsRouter.post('/:contentId/schedule', ah(async (req, res) => {
  const b = z.object({ runAt: z.coerce.date().optional() }).parse(req.body ?? {});
  res.json(await schedule(req.user!.id, req.params.contentId, b.runAt));
}));
approvalsRouter.post('/:contentId/cancel', ah(async (req, res) => { await cancel(req.user!.id, req.params.contentId); res.json({ ok: true }); }));
