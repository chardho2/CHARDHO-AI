import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { env } from '../lib/env';
import { hmacSign } from '../lib/crypto';
import { logger } from '../lib/logger';
import { runAgent } from './orchestrator';
import { createContent } from './content';
import { schedule } from './approvals';

export const TRIGGERS = ['new_business', 'content_request', 'new_lead', 'scheduled', 'approved_post', 'customer_enquiry', 'campaign_complete'] as const;
export const ACTIONS = ['start_agent', 'generate_content', 'create_draft', 'notify', 'schedule_approved', 'prepare_email', 'update_crm', 'generate_report', 'n8n_webhook'] as const;

export const graphSchema = z.object({
  steps: z.array(z.object({
    id: z.string().min(1).max(40),
    action: z.enum(ACTIONS),
    params: z.record(z.any()).default({}),
    // conditional logic: run only if ctx[path] <op> value
    condition: z.object({ path: z.string(), op: z.enum(['eq', 'neq', 'gt', 'lt', 'contains', 'exists']), value: z.any().optional() }).optional(),
  })).min(1).max(30),
  schedule: z.object({ runAt: z.string().optional(), everyHours: z.number().min(1).max(24 * 30).optional(), lastRunAt: z.string().optional() }).optional(),
});
export type Graph = z.infer<typeof graphSchema>;

const get = (o: any, p: string) => p.split('.').reduce((a, k) => (a == null ? undefined : a[k]), o);
export function evalCondition(c: NonNullable<Graph['steps'][number]['condition']>, ctx: unknown): boolean {
  const v = get(ctx, c.path);
  switch (c.op) {
    case 'eq': return v === c.value; case 'neq': return v !== c.value;
    case 'gt': return Number(v) > Number(c.value); case 'lt': return Number(v) < Number(c.value);
    case 'contains': return typeof v === 'string' ? v.includes(String(c.value)) : Array.isArray(v) && v.includes(c.value);
    case 'exists': return v !== undefined && v !== null;
  }
}
// ${path} templating from context
const tpl = (s: unknown, ctx: unknown) => (typeof s === 'string' ? s.replace(/\$\{([\w.]+)\}/g, (_, p) => String(get(ctx, p) ?? '')) : s);
const render = (params: Record<string, any>, ctx: unknown): Record<string, any> => Object.fromEntries(Object.entries(params).map(([k, v]) => [k, tpl(v, ctx)]));

type Log = { at: string; step: string; status: 'ok' | 'skipped' | 'error'; message?: string };

async function execStep(step: Graph['steps'][number], ctx: Record<string, any>, run: { userId: string }, businessId: string) {
  const p = render(step.params, ctx);
  const business = await prisma.business.findFirstOrThrow({ where: { id: businessId, userId: run.userId, deletedAt: null } });
  switch (step.action) {
    case 'start_agent':
    case 'generate_content':
    case 'generate_report': {
      const agentKey = step.action === 'generate_report' ? 'analytics_agent' : step.action === 'generate_content' ? (p.agent ?? 'social_media_manager') : String(p.agent);
      const t = await runAgent({ userId: run.userId, business, agentKey, input: { request: String(p.request ?? 'Run your standard task'), priorOutputs: [] } });
      if (t.status !== 'SUCCEEDED') throw new Error(t.error ?? 'agent failed');
      ctx[step.id] = { taskId: t.id, summary: (t.output as any)?.summary, contentIds: (t.output as any)?.savedContentIds ?? [] };
      return;
    }
    case 'create_draft': {
      const c = await createContent({ userId: run.userId, businessId, type: String(p.type ?? 'social_post'), platform: p.platform, title: p.title, body: String(p.body ?? ''), hashtags: p.hashtags ?? [] });
      ctx[step.id] = { contentIds: [c.id] };
      return;
    }
    case 'notify':
      await prisma.notification.create({ data: { userId: run.userId, title: String(p.title ?? 'Workflow notification'), body: p.body ? String(p.body) : null } });
      return;
    case 'schedule_approved': {
      // Never approves. Only schedules content a human has already approved; otherwise the step fails visibly.
      await schedule(run.userId, String(p.contentId), p.runAt ? new Date(p.runAt) : undefined);
      return;
    }
    case 'prepare_email': {
      const e = await prisma.emailCampaign.create({ data: { userId: run.userId, businessId, name: String(p.name ?? 'Workflow email'), subject: String(p.subject ?? ''), body: String(p.body ?? ''), status: 'draft' } });
      ctx[step.id] = { emailCampaignId: e.id };
      return;
    }
    case 'update_crm': {
      const r = await prisma.lead.updateMany({ where: { id: String(p.leadId), userId: run.userId }, data: { ...(p.status && { status: String(p.status) }), ...(p.notes && { notes: String(p.notes) }) } });
      if (!r.count) throw new Error('lead not found');
      return;
    }
    case 'n8n_webhook': {
      if (!env.N8N_WEBHOOK_URL || !env.N8N_SHARED_SECRET) throw new Error('n8n is not configured');
      const body = JSON.stringify({ businessId, step: step.id, data: p, context: ctx });
      const r = await fetch(env.N8N_WEBHOOK_URL, { method: 'POST', headers: { 'content-type': 'application/json', 'x-chardho-signature': hmacSign(body, env.N8N_SHARED_SECRET) }, body, signal: AbortSignal.timeout(30_000) });
      if (!r.ok) throw new Error(`n8n responded ${r.status}`);
      return;
    }
  }
}

/** Advance a run step by step; honours pause (workflow.paused) between steps and retries transient failures per step. */
export async function executeRun(runId: string) {
  const claimed = await prisma.workflowRun.updateMany({ where: { id: runId, status: { in: ['QUEUED', 'RUNNING'] } }, data: { status: 'RUNNING', startedAt: new Date() } });
  if (!claimed.count) return;
  const run = await prisma.workflowRun.findUniqueOrThrow({ where: { id: runId }, include: { workflow: true } });
  const graph = graphSchema.parse(run.workflow.graph);
  const logs = (run.logs as Log[]) ?? [];
  const ctx: Record<string, any> = { trigger: run.triggerData ?? {} };
  // rebuild ctx from logs is not needed for most flows; step outputs are kept in memory per execution slice
  for (let i = run.stepIndex; i < graph.steps.length; i++) {
    const fresh = await prisma.automationWorkflow.findUnique({ where: { id: run.workflowId }, select: { paused: true, enabled: true, deletedAt: true } });
    if (!fresh || fresh.deletedAt || !fresh.enabled) { await prisma.workflowRun.update({ where: { id: runId }, data: { status: 'FAILED', error: 'Workflow disabled', finishedAt: new Date(), logs: logs as any } }); return; }
    if (fresh.paused) { await prisma.workflowRun.update({ where: { id: runId }, data: { status: 'PAUSED', stepIndex: i, logs: logs as any } }); return; }
    const step = graph.steps[i];
    if (step.condition && !evalCondition(step.condition, ctx)) { logs.push({ at: new Date().toISOString(), step: step.id, status: 'skipped', message: 'condition false' }); continue; }
    let ok = false, err = '';
    for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
      try { await execStep(step, ctx, run, run.workflow.businessId); ok = true; logs.push({ at: new Date().toISOString(), step: step.id, status: 'ok' }); }
      catch (e) { err = (e as Error).message; logger.warn({ runId, step: step.id, attempt, err }, 'workflow step failed'); await new Promise((r) => setTimeout(r, 500 * attempt)); }
    }
    await prisma.workflowRun.update({ where: { id: runId }, data: { stepIndex: i + 1, logs: logs as any } });
    if (!ok) {
      logs.push({ at: new Date().toISOString(), step: step.id, status: 'error', message: err });
      await prisma.workflowRun.update({ where: { id: runId }, data: { status: 'FAILED', error: `${step.id}: ${err}`, finishedAt: new Date(), logs: logs as any } });
      await prisma.notification.create({ data: { userId: run.userId, title: `Workflow "${run.workflow.name}" failed`, body: `${step.id}: ${err}`.slice(0, 300) } });
      return;
    }
  }
  await prisma.workflowRun.update({ where: { id: runId }, data: { status: 'SUCCEEDED', finishedAt: new Date(), logs: logs as any, stepIndex: graph.steps.length } });
}

/** Fire all enabled workflows of a business for a trigger. */
export async function fireTrigger(userId: string, businessId: string, trigger: string, data: Prisma.InputJsonValue = {}) {
  const wfs = await prisma.automationWorkflow.findMany({ where: { userId, businessId, trigger, enabled: true, deletedAt: null } });
  const runs = [];
  for (const w of wfs) runs.push(await prisma.workflowRun.create({ data: { workflowId: w.id, userId, triggerData: data, status: w.paused ? 'PAUSED' : 'QUEUED' } }));
  return runs;
}

export const TEMPLATES: { name: string; trigger: string; graph: Graph }[] = [
  { name: 'Welcome strategy on onboarding', trigger: 'new_business', graph: { steps: [
    { id: 'intel', action: 'start_agent', params: { agent: 'marketing_manager', request: 'Create a business intelligence report for this new business.' }, },
    { id: 'plan', action: 'generate_content', params: { agent: 'social_media_manager', request: 'Create a 7-day starter content plan with one post per day.' } },
    { id: 'tell', action: 'notify', params: { title: 'Your strategy and starter content are ready for review' } } ] } },
  { name: 'Weekly content drafts', trigger: 'scheduled', graph: { schedule: { everyHours: 168 }, steps: [
    { id: 'weekly', action: 'generate_content', params: { agent: 'social_media_manager', request: 'Create this week\'s posts for all platforms.' } },
    { id: 'tell', action: 'notify', params: { title: 'New weekly drafts are waiting in your approval center' } } ] } },
  { name: 'New lead follow-up draft', trigger: 'new_lead', graph: { steps: [
    { id: 'draft', action: 'start_agent', params: { agent: 'lead_gen', request: 'Draft a permission-based follow-up message for the new lead: ${trigger.businessName}' } },
    { id: 'crm', action: 'update_crm', params: { leadId: '${trigger.leadId}', notes: 'Follow-up draft prepared by AI' }, condition: { path: 'trigger.leadId', op: 'exists' } } ] } },
];
