import { Platform } from '@prisma/client';

export interface PublishPayload { text: string; hashtags: string[]; imageUrl?: string }
export interface PublishCtx { accessToken: string; externalId: string }
export interface PublishResult { postId: string; raw: unknown }

export interface OAuthConfig {
  authUrl: string; tokenUrl: string; scopes: string[];
  clientId?: string; clientSecret?: string; pkce?: boolean; scopeSep?: string; extraAuth?: Record<string, string>;
}

const e = (k: string) => process.env[k];
export const OAUTH: Record<Platform, OAuthConfig> = {
  X: { authUrl: 'https://twitter.com/i/oauth2/authorize', tokenUrl: 'https://api.twitter.com/2/oauth2/token', scopes: ['tweet.read', 'tweet.write', 'users.read', 'offline.access'], clientId: e('X_CLIENT_ID'), clientSecret: e('X_CLIENT_SECRET'), pkce: true },
  LINKEDIN: { authUrl: 'https://www.linkedin.com/oauth/v2/authorization', tokenUrl: 'https://www.linkedin.com/oauth/v2/accessToken', scopes: ['openid', 'profile', 'w_member_social'], clientId: e('LINKEDIN_CLIENT_ID'), clientSecret: e('LINKEDIN_CLIENT_SECRET') },
  FACEBOOK: { authUrl: 'https://www.facebook.com/v19.0/dialog/oauth', tokenUrl: 'https://graph.facebook.com/v19.0/oauth/access_token', scopes: ['pages_show_list', 'pages_manage_posts', 'pages_read_engagement'], clientId: e('META_APP_ID'), clientSecret: e('META_APP_SECRET'), scopeSep: ',' },
  INSTAGRAM: { authUrl: 'https://www.facebook.com/v19.0/dialog/oauth', tokenUrl: 'https://graph.facebook.com/v19.0/oauth/access_token', scopes: ['pages_show_list', 'instagram_basic', 'instagram_content_publish'], clientId: e('META_APP_ID'), clientSecret: e('META_APP_SECRET'), scopeSep: ',' },
  YOUTUBE: { authUrl: 'https://accounts.google.com/o/oauth2/v2/auth', tokenUrl: 'https://oauth2.googleapis.com/token', scopes: ['https://www.googleapis.com/auth/youtube.readonly', 'https://www.googleapis.com/auth/youtube.force-ssl'], clientId: e('YOUTUBE_CLIENT_ID') ?? e('GOOGLE_CLIENT_ID'), clientSecret: e('YOUTUBE_CLIENT_SECRET') ?? e('GOOGLE_CLIENT_SECRET'), extraAuth: { access_type: 'offline', prompt: 'consent' } },
};

async function j(r: Response) {
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(`${r.status} ${JSON.stringify(body).slice(0, 400)}`), { raw: body });
  return body as any;
}
const withTags = (p: PublishPayload) => [p.text, p.hashtags.map((h) => (h.startsWith('#') ? h : `#${h}`)).join(' ')].filter(Boolean).join('\n\n');

/** Resolve the account identity right after OAuth. Returns what we need to store. */
export async function fetchIdentity(platform: Platform, token: string): Promise<{ externalId: string; displayName: string; accessToken?: string }> {
  const auth = { authorization: `Bearer ${token}` };
  switch (platform) {
    case 'X': { const d = (await j(await fetch('https://api.twitter.com/2/users/me', { headers: auth }))).data; return { externalId: d.id, displayName: `@${d.username}` }; }
    case 'LINKEDIN': { const d = await j(await fetch('https://api.linkedin.com/v2/userinfo', { headers: auth })); return { externalId: d.sub, displayName: d.name }; }
    case 'YOUTUBE': { const d = (await j(await fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', { headers: auth }))).items?.[0]; if (!d) throw new Error('No YouTube channel on this account'); return { externalId: d.id, displayName: d.snippet.title }; }
    case 'FACEBOOK': { const d = (await j(await fetch(`https://graph.facebook.com/v19.0/me/accounts?access_token=${token}`))).data?.[0]; if (!d) throw new Error('No Facebook Page found'); return { externalId: d.id, displayName: d.name, accessToken: d.access_token }; }
    case 'INSTAGRAM': {
      const page = (await j(await fetch(`https://graph.facebook.com/v19.0/me/accounts?fields=id,name,access_token,instagram_business_account&access_token=${token}`))).data?.find((p: any) => p.instagram_business_account);
      if (!page) throw new Error('No Instagram Business account linked to a Facebook Page');
      return { externalId: page.instagram_business_account.id, displayName: page.name, accessToken: page.access_token };
    }
  }
}

export type Publisher = (p: PublishPayload, c: PublishCtx) => Promise<PublishResult>;

/** Official-API publishers. Where an API cannot do text-only posting we fail loudly rather than fake success. */
export const PUBLISHERS: Record<Platform, Publisher> = {
  async X(p, c) {
    const raw = await j(await fetch('https://api.twitter.com/2/tweets', { method: 'POST', headers: { authorization: `Bearer ${c.accessToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ text: withTags(p) }) }));
    return { postId: raw.data.id, raw };
  },
  async LINKEDIN(p, c) {
    const raw = await j(await fetch('https://api.linkedin.com/v2/ugcPosts', { method: 'POST', headers: { authorization: `Bearer ${c.accessToken}`, 'content-type': 'application/json', 'X-Restli-Protocol-Version': '2.0.0' }, body: JSON.stringify({ author: `urn:li:person:${c.externalId}`, lifecycleState: 'PUBLISHED', specificContent: { 'com.linkedin.ugc.ShareContent': { shareCommentary: { text: withTags(p) }, shareMediaCategory: 'NONE' } }, visibility: { 'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC' } }) }));
    return { postId: raw.id, raw };
  },
  async FACEBOOK(p, c) {
    const body = new URLSearchParams({ message: withTags(p), access_token: c.accessToken });
    const raw = await j(await fetch(`https://graph.facebook.com/v19.0/${c.externalId}/feed`, { method: 'POST', body }));
    return { postId: raw.id, raw };
  },
  async INSTAGRAM(p, c) {
    if (!p.imageUrl) throw new Error('Instagram requires an image or video; attach media before publishing');
    const create = await j(await fetch(`https://graph.facebook.com/v19.0/${c.externalId}/media`, { method: 'POST', body: new URLSearchParams({ image_url: p.imageUrl, caption: withTags(p), access_token: c.accessToken }) }));
    const raw = await j(await fetch(`https://graph.facebook.com/v19.0/${c.externalId}/media_publish`, { method: 'POST', body: new URLSearchParams({ creation_id: create.id, access_token: c.accessToken }) }));
    return { postId: raw.id, raw: { create, publish: raw } };
  },
  async YOUTUBE() {
    throw new Error('YouTube publishing requires a video upload, which is not supported yet. Use the generated script/description manually in YouTube Studio.');
  },
};
