import { prisma } from '../lib/db';
import { env } from '../lib/env';
import { HttpError } from '../lib/errors';

export async function dailyLimit(): Promise<number> {
  const s = await prisma.setting.findUnique({ where: { key: 'dailyAiRequestLimit' } });
  return typeof s?.value === 'number' ? s.value : env.DAILY_AI_REQUEST_LIMIT;
}

export async function usageToday(userId: string) {
  const since = new Date(); since.setHours(0, 0, 0, 0);
  const used = await prisma.usageRecord.count({ where: { userId, createdAt: { gte: since }, kind: 'ai_request' } });
  const limit = await dailyLimit();
  return { used, limit, remaining: Math.max(0, limit - used), resetsAt: new Date(since.getTime() + 86_400_000) };
}

export async function assertWithinFairUse(userId: string, units = 1) {
  const u = await usageToday(userId);
  if (u.used + units > u.limit) throw new HttpError(429, `Daily fair-use limit reached (${u.limit} AI requests/day). Resets at ${u.resetsAt.toISOString()}.`);
}

export const recordUsage = (data: { userId: string; kind: string; agentKey?: string; provider?: string; model?: string; tokensIn?: number; tokensOut?: number }) =>
  prisma.usageRecord.create({ data });
