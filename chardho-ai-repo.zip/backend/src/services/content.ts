import { Platform, Prisma } from '@prisma/client';
import { prisma } from '../lib/db';
import { contentHash } from '../lib/hash';

const LIMITS: Partial<Record<Platform, number>> = { X: 280, INSTAGRAM: 2200, LINKEDIN: 3000, FACEBOOK: 63206, YOUTUBE: 5000 };

/** Simple automated quality check used before a draft can enter review. */
export function qualityCheck(body: string, platform?: Platform | null): { ok: boolean; issues: string[] } {
  const issues: string[] = [];
  if (!body.trim()) issues.push('Content is empty');
  if (platform && LIMITS[platform] && body.length > LIMITS[platform]!) issues.push(`Exceeds ${platform} limit of ${LIMITS[platform]} characters`);
  if (/(lorem ipsum|\[insert|\bTODO\b)/i.test(body)) issues.push('Contains placeholder text');
  return { ok: issues.length === 0, issues };
}

export async function createContent(args: {
  userId: string; businessId: string; type: string; platform?: Platform | null; title?: string; body: string;
  hashtags?: string[]; language?: string; tone?: string; audience?: string; createdByAgent?: string; campaignId?: string;
}) {
  const hashtags = args.hashtags ?? [];
  const qc = qualityCheck(args.body, args.platform);
  return prisma.contentItem.create({
    data: {
      userId: args.userId, businessId: args.businessId, type: args.type, platform: args.platform ?? null, title: args.title,
      language: args.language ?? 'en', tone: args.tone, audience: args.audience, createdByAgent: args.createdByAgent, campaignId: args.campaignId,
      status: qc.ok ? 'QUALITY_CHECKED' : 'DRAFT',
      versions: { create: { version: 1, body: args.body, hashtags, mediaAssetIds: [], contentHash: contentHash(args.body, hashtags, []), createdBy: args.createdByAgent ?? args.userId } },
    },
    include: { versions: true },
  });
}

/**
 * Edit = new version. Any non-terminal approval for this content is invalidated
 * and the content returns to DRAFT, requiring a fresh approval.
 */
export async function editContent(contentId: string, userId: string, patch: { body?: string; hashtags?: string[]; mediaAssetIds?: string[]; title?: string }) {
  return prisma.$transaction(async (tx) => {
    const item = await tx.contentItem.findUniqueOrThrow({ where: { id: contentId }, include: { versions: { orderBy: { version: 'desc' }, take: 1 } } });
    const cur = item.versions[0];
    const body = patch.body ?? cur.body;
    const hashtags = patch.hashtags ?? cur.hashtags;
    const media = patch.mediaAssetIds ?? cur.mediaAssetIds;
    const hash = contentHash(body, hashtags, media);
    if (hash === cur.contentHash && patch.title === undefined) return item;
    if (hash !== cur.contentHash) {
      await tx.contentVersion.create({ data: { contentId, version: cur.version + 1, body, hashtags, mediaAssetIds: media, contentHash: hash, createdBy: userId } });
      await tx.approval.updateMany({ where: { contentId, invalidatedAt: null }, data: { invalidatedAt: new Date(), invalidReason: 'Content edited after approval' } });
      await tx.publishingJob.updateMany({ where: { contentId, status: 'PENDING' }, data: { status: 'CANCELLED', error: 'Content edited; approval invalidated' } });
    }
    const qc = qualityCheck(body, item.platform);
    const wasPublished = item.status === 'PUBLISHED';
    return tx.contentItem.update({
      where: { id: contentId },
      data: { title: patch.title ?? item.title, currentVersion: hash !== cur.contentHash ? cur.version + 1 : cur.version, status: wasPublished ? 'PUBLISHED' : qc.ok ? 'QUALITY_CHECKED' : 'DRAFT' },
    });
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}
