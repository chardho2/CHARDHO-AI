import { Prisma } from '@prisma/client';
import { prisma } from '../lib/db';
import { HttpError, notFound } from '../lib/errors';
import { contentHash } from '../lib/hash';
import { decrypt, encrypt } from '../lib/crypto';
import { audit } from '../lib/audit';
import { logger } from '../lib/logger';
import { qualityCheck } from './content';
import { OAUTH, PUBLISHERS } from './platforms';

const ser = { isolationLevel: Prisma.TransactionIsolationLevel.Serializable };
const MAX_PUBLISH_ATTEMPTS = 3;

async function ownedContent(userId: string, id: string) {
  const c = await prisma.contentItem.findFirst({ where: { id, userId, deletedAt: null }, include: { versions: { orderBy: { version: 'desc' }, take: 1 } } });
  if (!c) throw notFound('Content');
  return c;
}

/** DRAFT/QUALITY_CHECKED -> PENDING_APPROVAL (user review). Re-runs the quality gate. */
export async function submitForReview(userId: string, contentId: string) {
  const c = await ownedContent(userId, contentId);
  if (!['DRAFT', 'QUALITY_CHECKED'].includes(c.status)) throw new HttpError(409, `Cannot submit content in status ${c.status}`);
  const qc = qualityCheck(c.versions[0].body, c.platform);
  if (!qc.ok) throw new HttpError(422, 'Quality check failed', qc.issues);
  return prisma.contentItem.update({ where: { id: contentId }, data: { status: 'PENDING_APPROVAL' } });
}

/** Human approval of a specific version for a specific destination account. Agents have no path to this function. */
export async function approve(userId: string, contentId: string, socialAccountId: string, scheduledFor?: Date) {
  const c = await ownedContent(userId, contentId);
  if (c.status !== 'PENDING_APPROVAL') throw new HttpError(409, 'Content must be in review (PENDING_APPROVAL) to approve');
  const acct = await prisma.socialAccount.findFirst({ where: { id: socialAccountId, userId, businessId: c.businessId, deletedAt: null } });
  if (!acct) throw notFound('Social account');
  if (c.platform && c.platform !== acct.platform) throw new HttpError(422, `Content is for ${c.platform} but account is ${acct.platform}`);
  const v = c.versions[0];
  if (v.version !== c.currentVersion) throw new HttpError(409, 'Content changed; reload and review the latest version');
  if (scheduledFor && scheduledFor.getTime() < Date.now() - 60_000) throw new HttpError(422, 'scheduledFor is in the past');
  const approval = await prisma.$transaction(async (tx) => {
    await tx.approval.updateMany({ where: { contentId, invalidatedAt: null }, data: { invalidatedAt: new Date(), invalidReason: 'Superseded by new approval' } });
    const a = await tx.approval.create({ data: { contentId, version: v.version, contentHash: v.contentHash, socialAccountId, approvedById: userId, scheduledFor } });
    await tx.contentItem.update({ where: { id: contentId }, data: { status: 'APPROVED' } });
    return a;
  }, ser);
  await audit(userId, 'content.approve', 'ContentItem', contentId, { version: v.version, socialAccountId });
  return approval;
}

/** APPROVED -> SCHEDULED. Creates exactly one job per (content version, account) thanks to the unique idempotency key. */
export async function schedule(userId: string, contentId: string, runAt?: Date) {
  const c = await ownedContent(userId, contentId);
  const approval = await prisma.approval.findFirst({ where: { contentId, invalidatedAt: null }, orderBy: { approvedAt: 'desc' } });
  if (!approval || c.status !== 'APPROVED') throw new HttpError(409, 'Content has no valid approval. Approve the latest version first.');
  if (approval.contentHash !== c.versions[0].contentHash) throw new HttpError(409, 'Approval does not match current content version');
  const when = runAt ?? approval.scheduledFor ?? new Date();
  const key = `${contentId}:${approval.version}:${approval.socialAccountId}`;
  const existing = await prisma.publishingJob.findUnique({ where: { idempotencyKey: key } });
  if (existing && existing.status !== 'CANCELLED') throw new HttpError(409, `Already ${existing.status === 'SUCCEEDED' ? 'published' : 'scheduled'} (duplicate publishing prevented)`);
  const job = await prisma.$transaction(async (tx) => {
    // A cancelled job for the same version can be revived (same key).
    const j = existing
      ? await tx.publishingJob.update({ where: { id: existing.id }, data: { status: 'PENDING', runAt: when, error: null, approvalId: approval.id, attempts: 0 } })
      : await tx.publishingJob.create({ data: { contentId, approvalId: approval.id, socialAccountId: approval.socialAccountId, idempotencyKey: key, runAt: when } });
    await tx.contentItem.update({ where: { id: contentId }, data: { status: 'SCHEDULED' } });
    return j;
  }, ser);
  await audit(userId, 'content.schedule', 'PublishingJob', job.id, { runAt: when });
  return job;
}

export async function cancel(userId: string, contentId: string) {
  const c = await ownedContent(userId, contentId);
  const r = await prisma.publishingJob.updateMany({ where: { contentId, status: 'PENDING' }, data: { status: 'CANCELLED', error: 'Cancelled by user' } });
  if (!r.count && c.status === 'PUBLISHED') throw new HttpError(409, 'Already published');
  await prisma.approval.updateMany({ where: { contentId, invalidatedAt: null }, data: { invalidatedAt: new Date(), invalidReason: 'Cancelled by user' } });
  await prisma.contentItem.update({ where: { id: contentId }, data: { status: c.status === 'PUBLISHED' ? 'PUBLISHED' : 'CANCELLED' } });
  await audit(userId, 'content.cancel', 'ContentItem', contentId);
}

async function freshToken(acctId: string): Promise<string> {
  const a = await prisma.socialAccount.findUniqueOrThrow({ where: { id: acctId } });
  if (a.expiresAt && a.expiresAt.getTime() - Date.now() < 120_000 && a.refreshTokenEnc) {
    const cfg = OAUTH[a.platform];
    const body = new URLSearchParams({ grant_type: 'refresh_token', refresh_token: decrypt(a.refreshTokenEnc), client_id: cfg.clientId ?? '' });
    const headers: Record<string, string> = { 'content-type': 'application/x-www-form-urlencoded' };
    if (cfg.clientSecret) { if (a.platform === 'X') headers.authorization = `Basic ${Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString('base64')}`; else body.set('client_secret', cfg.clientSecret); }
    const r = await fetch(cfg.tokenUrl, { method: 'POST', headers, body });
    const t = (await r.json()) as any;
    if (!r.ok || !t.access_token) throw new Error(`Token refresh failed: ${JSON.stringify(t).slice(0, 200)}`);
    await prisma.socialAccount.update({ where: { id: a.id }, data: { accessTokenEnc: encrypt(t.access_token), refreshTokenEnc: t.refresh_token ? encrypt(t.refresh_token) : a.refreshTokenEnc, expiresAt: t.expires_in ? new Date(Date.now() + t.expires_in * 1000) : null } });
    return t.access_token;
  }
  return decrypt(a.accessTokenEnc);
}

/**
 * Execute one job. Safe to call concurrently: the PENDING->IN_PROGRESS claim is atomic, and
 * approval + hash are re-verified at the last moment so an edit racing the worker can never publish stale/unapproved content.
 */
export async function runPublishingJob(jobId: string): Promise<'published' | 'skipped' | 'failed' | 'retry'> {
  const claimed = await prisma.publishingJob.updateMany({ where: { id: jobId, status: 'PENDING', runAt: { lte: new Date() } }, data: { status: 'IN_PROGRESS', attempts: { increment: 1 } } });
  if (!claimed.count) return 'skipped';
  const job = await prisma.publishingJob.findUniqueOrThrow({ where: { id: jobId }, include: { approval: true, account: true, content: { include: { versions: { orderBy: { version: 'desc' }, take: 1 } } } } });
  const fail = async (error: string, apiResponse?: unknown, retryable = false) => {
    const retry = retryable && job.attempts < MAX_PUBLISH_ATTEMPTS;
    await prisma.publishingJob.update({ where: { id: jobId }, data: { status: retry ? 'PENDING' : 'FAILED', runAt: retry ? new Date(Date.now() + 2 ** job.attempts * 60_000) : job.runAt, error, apiResponse: apiResponse as Prisma.InputJsonValue ?? undefined } });
    if (!retry) {
      await prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'FAILED' } });
      await prisma.notification.create({ data: { userId: job.content.userId, title: 'Publishing failed', body: `${job.content.title ?? job.content.type}: ${error.slice(0, 200)}` } });
    }
    return retry ? 'retry' as const : 'failed' as const;
  };

  const v = job.content.versions[0];
  if (job.approval.invalidatedAt || job.approval.contentHash !== v.contentHash || job.approval.version !== v.version) {
    await prisma.publishingJob.update({ where: { id: jobId }, data: { status: 'CANCELLED', error: 'Approval invalid or content changed' } });
    return 'skipped';
  }
  try {
    await prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'PUBLISHING' } });
    const token = await freshToken(job.socialAccountId);
    let imageUrl: string | undefined;
    if (v.mediaAssetIds[0]) imageUrl = `${process.env.API_URL}/media/${v.mediaAssetIds[0]}`;
    const res = await PUBLISHERS[job.account.platform]({ text: v.body, hashtags: v.hashtags, imageUrl }, { accessToken: token, externalId: job.account.externalId });
    await prisma.$transaction([
      prisma.publishingJob.update({ where: { id: jobId }, data: { status: 'SUCCEEDED', externalPostId: res.postId, apiResponse: res.raw as Prisma.InputJsonValue, error: null } }),
      prisma.contentItem.update({ where: { id: job.contentId }, data: { status: 'PUBLISHED' } }),
    ]);
    return 'published';
  } catch (e) {
    logger.warn({ jobId, err: (e as Error).message }, 'publish failed');
    const raw = (e as { raw?: unknown }).raw;
    const msg = (e as Error).message;
    // A 4xx from the platform is not retryable (and an ambiguous timeout is NOT retried, to avoid double posting).
    return fail(msg, raw ?? { message: msg }, /\b5\d\d\b/.test(msg.slice(0, 4)));
  }
}

export async function runDueJobs(limit = 20) {
  const due = await prisma.publishingJob.findMany({ where: { status: 'PENDING', runAt: { lte: new Date() } }, orderBy: { runAt: 'asc' }, take: limit, select: { id: true } });
  for (const d of due) await runPublishingJob(d.id);
  return due.length;
}
