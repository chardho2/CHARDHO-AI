import { Business, Platform, Prisma } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../lib/db';
import { HttpError } from '../lib/errors';
import { logger } from '../lib/logger';
import { generateText } from '../providers/manager';
import { AGENT_MAP, AGENTS, AgentDef } from '../agents/definitions';
import { assertWithinFairUse, recordUsage } from './usage';
import { createContent } from './content';

const PLATFORMS = ['INSTAGRAM', 'FACEBOOK', 'YOUTUBE', 'LINKEDIN', 'X'] as const;
const draftSchema = z.object({
  type: z.string().min(1).max(60),
  platform: z.preprocess((v) => (typeof v === 'string' ? v.toUpperCase().replace('TWITTER', 'X') : null), z.enum(PLATFORMS).nullable()).default(null),
  title: z.string().max(300).default(''),
  body: z.string().min(1).max(20000),
  hashtags: z.array(z.string().max(60)).max(40).default([]),
});
export const outputSchema = z.object({
  summary: z.string().min(1),
  drafts: z.array(draftSchema).max(30).optional(),
  sections: z.array(z.object({ heading: z.string(), points: z.array(z.string()) })).optional(),
  workflows: z.array(z.object({ name: z.string(), trigger: z.string(), steps: z.array(z.object({ action: z.string(), params: z.record(z.any()).default({}) })) })).optional(),
  notes: z.array(z.string()).default([]),
}).passthrough();
export type AgentOutput = z.infer<typeof outputSchema>;

export const inputSchema = z.object({
  request: z.string().min(3).max(4000),
  language: z.string().max(30).optional(),
  tone: z.string().max(60).optional(),
  audience: z.string().max(200).optional(),
  length: z.enum(['short', 'medium', 'long']).optional(),
  priorOutputs: z.array(z.object({ agent: z.string(), summary: z.string() })).default([]),
});
export type AgentInput = z.infer<typeof inputSchema>;

export function parseJsonLoose(text: string): unknown {
  const t = text.trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try { return JSON.parse(t); } catch {
    const m = t.match(/\{[\s\S]*\}/);
    if (m) return JSON.parse(m[0]);
    throw new Error('Model did not return valid JSON');
  }
}

/** Pick agents: ask the LLM first, fall back to keyword routing so the system works even with a weak model. */
export async function planAgents(request: string): Promise<string[]> {
  const lower = ` ${request.toLowerCase()} `;
  const byKeyword = AGENTS.filter((a) => a.keywords.some((k) => lower.includes(k))).map((a) => a.key);
  try {
    const r = await generateText({
      system: 'You route marketing requests to specialist agents. Output JSON {"agents": string[]} with 1-4 keys.',
      prompt: `Agents:\n${AGENTS.map((a) => `- ${a.key}: ${a.description}`).join('\n')}\n\nRequest: ${request}`,
      json: true, temperature: 0, maxTokens: 200,
    }, ['text', 'json']);
    const picked = (parseJsonLoose(r.text) as { agents?: string[] }).agents?.filter((k) => AGENT_MAP.has(k)) ?? [];
    if (picked.length) return [...new Set(picked)].slice(0, 4);
  } catch (e) { logger.warn({ err: (e as Error).message }, 'planner failed, using keyword routing'); }
  return (byKeyword.length ? byKeyword : ['marketing_manager']).slice(0, 4);
}

async function buildContext(def: AgentDef, business: Business, userId: string) {
  const ctx: Record<string, unknown> = {};
  if (def.tools.includes('read_business')) {
    ctx.business = { name: business.name, website: business.website, industry: business.industry, description: business.description, productsServices: business.productsServices, location: business.location, targetAudience: business.targetAudience, objectives: business.objectives, competitors: business.competitors, languages: business.languages };
  }
  if (def.tools.includes('read_influencers')) {
    ctx.influencers = (await prisma.influencer.findMany({ where: { businessId: business.id, userId, deletedAt: null }, take: 50 }))
      .map((i) => ({ name: i.name, platform: i.platform, handle: i.handle, niche: i.niche, country: i.country, followers: i.followers, engagement: i.engagement, metricsSource: i.metricsSource }));
  }
  if (def.tools.includes('read_leads')) {
    ctx.leads = (await prisma.lead.findMany({ where: { businessId: business.id, userId, deletedAt: null }, take: 50 })).map((l) => ({ source: l.source, industry: l.industry, status: l.status, score: l.score }));
  }
  if (def.tools.includes('read_analytics')) {
    ctx.analytics = await prisma.analyticsSnapshot.findMany({ where: { businessId: business.id, userId }, orderBy: { capturedAt: 'desc' }, take: 100, select: { platform: true, metric: true, value: true, capturedAt: true, source: true } });
  }
  return ctx;
}

async function persistTools(def: AgentDef, out: AgentOutput, taskId: string, business: Business, userId: string, input: AgentInput) {
  const saved: string[] = [];
  if (def.tools.includes('save_drafts') && out.drafts?.length) {
    for (const d of out.drafts) {
      // Tool is write-only into DRAFT/QUALITY_CHECKED states. Agents cannot approve or publish.
      const item = await createContent({ userId, businessId: business.id, type: d.type, platform: d.platform as Platform | null, title: d.title, body: d.body, hashtags: d.hashtags, language: input.language ?? business.languages[0] ?? 'en', tone: input.tone, audience: input.audience, createdByAgent: def.key });
      saved.push(item.id);
    }
  }
  if (def.tools.includes('save_intelligence') && out.sections) {
    await prisma.business.update({ where: { id: business.id }, data: { intelligence: { generatedAt: new Date().toISOString(), summary: out.summary, sections: out.sections, notes: out.notes, taskId } as Prisma.InputJsonValue } });
  }
  return saved;
}

const MAX_ATTEMPTS = 3;

export async function runAgent(opts: { userId: string; business: Business; agentKey: string; input: AgentInput; parentId?: string }) {
  const def = AGENT_MAP.get(opts.agentKey);
  if (!def) throw new HttpError(400, `Unknown agent ${opts.agentKey}`);
  const agentRow = await prisma.aiAgent.findUnique({ where: { key: def.key } });
  if (agentRow && !agentRow.enabled) throw new HttpError(403, `Agent ${def.name} is currently disabled by the administrator`);
  const input = inputSchema.parse(opts.input);
  await assertWithinFairUse(opts.userId);

  const task = await prisma.agentTask.create({ data: { userId: opts.userId, businessId: opts.business.id, agentKey: def.key, parentId: opts.parentId, input: input as Prisma.InputJsonValue, status: 'RUNNING', startedAt: new Date() } });
  const system = agentRow?.systemPrompt ?? def.systemPrompt;
  let lastErr = '';
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      await prisma.agentTask.update({ where: { id: task.id }, data: { attempts: attempt } });
      const ctx = await buildContext(def, opts.business, opts.userId);
      const prompt = [
        `Request: ${input.request}`,
        input.language && `Language: ${input.language}`, input.tone && `Tone: ${input.tone}`, input.audience && `Audience: ${input.audience}`, input.length && `Length: ${input.length}`,
        `Context (authoritative, do not contradict):\n${JSON.stringify(ctx)}`,
        input.priorOutputs.length ? `Outputs from collaborating agents:\n${JSON.stringify(input.priorOutputs)}` : '',
        lastErr && `Your previous answer was rejected: ${lastErr}. Return valid JSON in the required shape.`,
      ].filter(Boolean).join('\n\n');
      const res = await generateText({ system, prompt, json: true }, ['text', 'json']);
      const out = outputSchema.parse(parseJsonLoose(res.text));
      const saved = await persistTools(def, out, task.id, opts.business, opts.userId, input);
      await recordUsage({ userId: opts.userId, kind: 'ai_request', agentKey: def.key, provider: res.provider, model: res.model, tokensIn: res.tokensIn, tokensOut: res.tokensOut });
      return prisma.agentTask.update({ where: { id: task.id }, data: { status: 'SUCCEEDED', output: { ...out, savedContentIds: saved } as Prisma.InputJsonValue, provider: res.provider, model: res.model, tokensIn: res.tokensIn, tokensOut: res.tokensOut, finishedAt: new Date(), error: null } });
    } catch (e) {
      lastErr = (e as Error).message.slice(0, 300);
      logger.warn({ task: task.id, attempt, err: lastErr }, 'agent attempt failed');
      // provider-exhaustion is not worth retrying
      if (e instanceof HttpError && e.status === 503) break;
    }
  }
  return prisma.agentTask.update({ where: { id: task.id }, data: { status: 'FAILED', error: lastErr, finishedAt: new Date() } });
}

/** Orchestrate: plan -> run agents sequentially, passing each agent's summary forward. */
export async function orchestrate(opts: { userId: string; business: Business; input: Omit<AgentInput, 'priorOutputs'>; agents?: string[] }) {
  const agents = opts.agents?.length ? opts.agents : await planAgents(opts.input.request);
  await assertWithinFairUse(opts.userId, agents.length);
  const prior: AgentInput['priorOutputs'] = [];
  const tasks = [];
  let parentId: string | undefined;
  for (const key of agents) {
    const t = await runAgent({ userId: opts.userId, business: opts.business, agentKey: key, input: { ...opts.input, priorOutputs: prior }, parentId });
    parentId ??= t.id;
    tasks.push(t);
    if (t.status === 'SUCCEEDED') prior.push({ agent: key, summary: String((t.output as any)?.summary ?? '').slice(0, 800) });
  }
  return { agents, tasks };
}
