import nodemailer from 'nodemailer';
import { env } from './env';
import { logger } from './logger';

const transport = env.SMTP_HOST
  ? nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
    })
  : null;

export async function sendMail(to: string, subject: string, text: string) {
  if (!transport) {
    logger.info({ to, subject, text }, '[mail:dev] SMTP not configured, logging email instead');
    return;
  }
  await transport.sendMail({ from: env.MAIL_FROM, to, subject, text });
}
