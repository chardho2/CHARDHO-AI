import crypto from 'crypto';

/** Canonical hash of the publishable parts of a content version. */
export function contentHash(body: string, hashtags: string[], mediaAssetIds: string[]): string {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify({ body: body.trim(), hashtags: [...hashtags].sort(), media: [...mediaAssetIds].sort() }))
    .digest('hex');
}
