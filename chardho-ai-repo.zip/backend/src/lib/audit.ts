import { prisma } from './db';

export async function audit(userId: string | null, action: string, entity?: string, entityId?: string, meta?: object, ip?: string) {
  try {
    await prisma.auditLog.create({ data: { userId, action, entity, entityId, meta: meta as any, ip } });
  } catch {
    /* audit must never break the request */
  }
}
