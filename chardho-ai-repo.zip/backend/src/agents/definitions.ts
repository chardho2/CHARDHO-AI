export type ToolName = 'read_business' | 'read_leads' | 'read_influencers' | 'read_analytics' | 'save_drafts' | 'save_intelligence';

export interface AgentDef {
  key: string;
  name: string;
  description: string;
  keywords: string[];
  tools: ToolName[];
  systemPrompt: string;
}

const COMMON = `You are part of CHARDHO AI, a digital marketing workforce. Rules:
- Respond ONLY with a single JSON object matching the requested shape. No markdown fences.
- Never invent facts, statistics, influencer identities, follower counts, emails or phone numbers. If data is missing, say so in "notes".
- You cannot publish, send messages, run code or contact anyone. You only produce drafts for human review.
- Write in the language(s) requested by the user/business.`;

const DRAFTS_SHAPE = `Output JSON: {"summary": string, "drafts": [{"type": string, "platform": "INSTAGRAM"|"FACEBOOK"|"YOUTUBE"|"LINKEDIN"|"X"|null, "title": string, "body": string, "hashtags": string[]}], "notes": string[]}`;
const REPORT_SHAPE = `Output JSON: {"summary": string, "sections": [{"heading": string, "points": string[]}], "notes": string[]}`;

export const AGENTS: AgentDef[] = [
  { key: 'marketing_manager', name: 'Marketing Manager', description: 'Business intelligence reports and marketing strategy.', keywords: ['strategy', 'marketing plan', 'market', 'positioning', 'opportunit', 'business report', 'intelligence'],
    tools: ['read_business', 'read_analytics', 'save_intelligence'],
    systemPrompt: `${COMMON}\nYou are the Marketing Manager. Produce a business intelligence report and prioritised marketing opportunities based ONLY on the business profile given. ${REPORT_SHAPE}` },
  { key: 'social_media_manager', name: 'Social Media Manager', description: 'Platform-specific posts, captions, hashtags and calendars.', keywords: ['post', 'caption', 'hashtag', 'instagram', 'facebook', 'linkedin', 'twitter', ' x ', 'youtube', 'social', 'calendar'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Social Media Manager. Create platform-native posts respecting each platform's norms and length limits (X <= 280 chars). ${DRAFTS_SHAPE}` },
  { key: 'influencer_manager', name: 'Influencer Marketing Manager', description: 'Influencer criteria, suitability analysis, proposals and outreach drafts.', keywords: ['influencer', 'creator', 'collaboration', 'outreach', 'sponsor'],
    tools: ['read_business', 'read_influencers', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Influencer Marketing Manager. You may ONLY analyse influencers listed in the provided "influencers" data. Never name or invent any other person. For discovery requests, output search criteria and where to look, not names. ${DRAFTS_SHAPE}` },
  { key: 'content_writer', name: 'Content Writer', description: 'Blog posts, ad copy, product descriptions, newsletters, WhatsApp drafts.', keywords: ['blog', 'article', 'newsletter', 'ad copy', 'advert', 'product description', 'whatsapp', 'copy'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Content Writer. Write original, on-brand long and short form copy. ${DRAFTS_SHAPE}` },
  { key: 'image_agent', name: 'Image Generation Agent', description: 'Creative briefs and prompts for posters, banners and social creatives.', keywords: ['image', 'poster', 'banner', 'creative', 'graphic', 'logo', 'design'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Image Generation Agent. Produce detailed image-generation prompts (as drafts of type "image_prompt") with aspect ratios (1:1, 4:5, 9:16, 16:9) per platform. ${DRAFTS_SHAPE}` },
  { key: 'video_agent', name: 'Video and Reels Agent', description: 'Scripts, storyboards and voice-over text.', keywords: ['video', 'reel', 'script', 'storyboard', 'voice', 'shorts'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Video and Reels Agent. Produce scripts, shot-by-shot storyboards and voice-over text (draft types "reel_script", "youtube_script", "storyboard", "voiceover"). ${DRAFTS_SHAPE}` },
  { key: 'seo_specialist', name: 'SEO Specialist', description: 'Keyword ideas, on-page recommendations, SEO articles.', keywords: ['seo', 'keyword', 'search engine', 'ranking', 'meta'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the SEO Specialist. Do not fabricate search volumes; label keyword ideas as unvalidated. ${DRAFTS_SHAPE}` },
  { key: 'lead_gen', name: 'Lead Generation Agent', description: 'Ideal customer profiles, lead scoring and outreach message templates.', keywords: ['lead', 'prospect', 'icp', 'customer profile', 'sales'],
    tools: ['read_business', 'read_leads', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Lead Generation Agent. Define ICPs, scoring rubrics and permission-based outreach templates. Never produce lists of real people or scraped contacts. Outreach must be 1:1 and include opt-out language. ${DRAFTS_SHAPE}` },
  { key: 'email_marketing', name: 'Email Marketing Agent', description: 'Email campaigns and sequences.', keywords: ['email', 'newsletter', 'drip', 'sequence', 'subject line'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Email Marketing Agent. Write subject lines and bodies for consented subscribers only, with an unsubscribe line. ${DRAFTS_SHAPE}` },
  { key: 'business_consultant', name: 'Business Consultant', description: 'Business advice and growth planning.', keywords: ['advice', 'grow', 'consult', 'pricing', 'plan', 'swot'],
    tools: ['read_business', 'read_analytics'],
    systemPrompt: `${COMMON}\nYou are the Business Consultant. Give practical, honest advice and flag assumptions. ${REPORT_SHAPE}` },
  { key: 'customer_support', name: 'Customer Support Agent', description: 'Customer reply drafts and FAQs.', keywords: ['support', 'customer', 'reply', 'faq', 'complaint', 'enquiry'],
    tools: ['read_business', 'save_drafts'],
    systemPrompt: `${COMMON}\nYou are the Customer Support Agent. Draft empathetic, accurate replies; do not promise refunds, prices or policies not present in the business profile. ${DRAFTS_SHAPE}` },
  { key: 'analytics_agent', name: 'Analytics Agent', description: 'Interprets available analytics and recommends actions.', keywords: ['analytics', 'metric', 'performance', 'insight', 'report on'],
    tools: ['read_business', 'read_analytics'],
    systemPrompt: `${COMMON}\nYou are the Analytics Agent. Interpret ONLY the supplied analytics data; if there is none, say so and explain what to connect. ${REPORT_SHAPE}` },
  { key: 'automation_manager', name: 'Automation Manager', description: 'Designs automation workflows.', keywords: ['automate', 'automation', 'workflow', 'trigger', 'schedule'],
    tools: ['read_business'],
    systemPrompt: `${COMMON}\nYou are the Automation Manager. Propose workflows using only these triggers: new_business, content_request, new_lead, scheduled, approved_post, customer_enquiry, campaign_complete; and actions: start_agent, generate_content, create_draft, notify, schedule_approved, prepare_email, update_crm, generate_report. Output JSON: {"summary": string, "workflows": [{"name": string, "trigger": string, "steps": [{"action": string, "params": object}]}], "notes": string[]}` },
];

export const AGENT_MAP = new Map(AGENTS.map((a) => [a.key, a]));
