import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import pinoHttp from 'pino-http';
import swaggerUi from 'swagger-ui-express';
import { env } from './lib/env';
import { logger } from './lib/logger';
import { prisma } from './lib/db';
import { errorHandler } from './middleware/error';
import { authRouter } from './routes/auth';
import { usersRouter } from './routes/users';
import { businessesRouter } from './routes/businesses';
import { agentsRouter, conversationsRouter, marketingRouter, seoRouter, usageRouter } from './routes/agents';
import { contentRouter } from './routes/content';
import { approvalsRouter } from './routes/approvals';
import { socialRouter } from './routes/social';
import { mediaPublicRouter, mediaRouter } from './routes/media';
import { campaignsRouter, influencersRouter, leadsRouter } from './routes/crm';
import { automationRouter, n8nWebhookRouter } from './routes/automation';
import { analyticsRouter } from './routes/analytics';
import { adminRouter } from './routes/admin';
import { calendarRouter, emailRouter, integrationsRouter, notificationsRouter, supportRouter } from './routes/misc';
import { openapi } from './openapi';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use(pinoHttp({ logger, autoLogging: { ignore: (r) => r.url === '/health' } }));
  app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  // Bearer-token API (no cookies) => CSRF is not applicable; CORS limited to the app origin.
  app.use(cors({ origin: env.APP_URL, credentials: false }));
  app.use(compression());
  app.use(express.json({ limit: '2mb', verify: (req, _res, buf) => { (req as any).rawBody = buf.toString('utf8'); } }));
  app.use('/api', rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false }));

  app.get('/health', async (_req, res) => {
    try { await prisma.$queryRaw`SELECT 1`; res.json({ status: 'ok', time: new Date().toISOString() }); }
    catch { res.status(503).json({ status: 'db_unavailable' }); }
  });
  app.use('/media', mediaPublicRouter);
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openapi));
  app.get('/api/openapi.json', (_req, res) => res.json(openapi));

  app.use('/api/auth', authRouter);
  app.use('/api/users', usersRouter);
  app.use('/api/businesses', businessesRouter);
  app.use('/api/agents', agentsRouter);
  app.use('/api/conversations', conversationsRouter);
  app.use('/api/content', contentRouter);
  app.use('/api/media', mediaRouter);
  app.use('/api/marketing', marketingRouter);
  app.use('/api/influencers', influencersRouter);
  app.use('/api/social', socialRouter);
  app.use('/api/campaigns', campaignsRouter);
  app.use('/api/approvals', approvalsRouter);
  app.use('/api/calendar', calendarRouter);
  app.use('/api/automation/webhook', n8nWebhookRouter);
  app.use('/api/automation', automationRouter);
  app.use('/api/leads', leadsRouter);
  app.use('/api/email', emailRouter);
  app.use('/api/seo', seoRouter);
  app.use('/api/analytics', analyticsRouter);
  app.use('/api/notifications', notificationsRouter);
  app.use('/api/integrations', integrationsRouter);
  app.use('/api/support', supportRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api/usage', usageRouter);

  app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
  app.use(errorHandler);
  return app;
}
