import { prisma } from '../lib/db';
import { notFound } from '../lib/errors';

/** Tenant isolation: every business-scoped route resolves the business through the authenticated user. */
export async function ownBusiness(userId: string, businessId: string) {
  const b = await prisma.business.findFirst({ where: { id: businessId, userId, deletedAt: null } });
  if (!b) throw notFound('Business');
  return b;
}
