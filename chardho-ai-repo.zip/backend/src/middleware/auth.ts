import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { Role } from '@prisma/client';
import { env } from '../lib/env';
import { prisma } from '../lib/db';
import { HttpError } from '../lib/errors';

export interface AuthUser { id: string; email: string; role: Role }
declare global { namespace Express { interface Request { user?: AuthUser } } }

export function signAccess(u: { id: string; email: string; role: Role; tokenVersion: number }) {
  return jwt.sign({ sub: u.id, tv: u.tokenVersion }, env.JWT_SECRET, { expiresIn: '12h' });
}

export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const h = req.headers.authorization;
    if (!h?.startsWith('Bearer ')) throw new HttpError(401, 'Authentication required');
    const payload = jwt.verify(h.slice(7), env.JWT_SECRET) as { sub: string; tv: number };
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.deletedAt || user.disabledAt || user.tokenVersion !== payload.tv) throw new HttpError(401, 'Session invalid');
    req.user = { id: user.id, email: user.email, role: user.role };
    next();
  } catch (e) {
    next(e instanceof HttpError ? e : new HttpError(401, 'Authentication required'));
  }
}

const RANK: Record<Role, number> = { USER: 0, ADMIN: 1, SUPER_ADMIN: 2, OWNER: 3 };
export const requireRole = (min: Role) => (req: Request, _res: Response, next: NextFunction) =>
  req.user && RANK[req.user.role] >= RANK[min] ? next() : next(new HttpError(403, 'Insufficient role'));
export const roleRank = (r: Role) => RANK[r];
