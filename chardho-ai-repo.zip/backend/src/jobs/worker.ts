import { prisma } from '../lib/db';
import { logger } from '../lib/logger';
import { runDueJobs } from '../services/approvals';
import { executeRun, fireTrigger, graphSchema } from '../services/workflows';
import { AGENTS } from '../agents/definitions';
import { ensureProviderConfigs } from '../providers/manager';

/**
 * Database-backed worker. All claims are atomic UPDATEs, so any number of worker replicas can run safely.
 * - publishes due approved jobs
 * - executes queued workflow runs
 * - fires scheduled workflows
 */
async function tick() {
  try { await runDueJobs(); } catch (e) { logger.error(e, 'publish loop'); }
  try {
    const runs = await prisma.workflowRun.findMany({ where: { status: 'QUEUED' }, orderBy: { createdAt: 'asc' }, take: 10, select: { id: true } });
    for (const r of runs) await executeRun(r.id).catch((e) => logger.error(e, 'run failed'));
  } catch (e) { logger.error(e, 'workflow loop'); }
  try {
    const wfs = await prisma.automationWorkflow.findMany({ where: { trigger: 'scheduled', enabled: true, paused: false, deletedAt: null } });
    for (const w of wfs) {
      const g = graphSchema.parse(w.graph);
      const s = g.schedule; if (!s) continue;
      const last = s.lastRunAt ? new Date(s.lastRunAt).getTime() : 0;
      const due = s.runAt ? !s.lastRunAt && new Date(s.runAt).getTime() <= Date.now() : s.everyHours ? Date.now() - last >= s.everyHours * 3_600_000 : false;
      if (!due) continue;
      // claim by compare-and-set on updatedAt so replicas don't double-fire
      const c = await prisma.automationWorkflow.updateMany({ where: { id: w.id, updatedAt: w.updatedAt }, data: { graph: { ...g, schedule: { ...s, lastRunAt: new Date().toISOString() } } } });
      if (c.count) await fireTrigger(w.userId, w.businessId, 'scheduled', { workflowId: w.id });
    }
  } catch (e) { logger.error(e, 'schedule loop'); }
}

async function main() {
  await ensureProviderConfigs();
  void AGENTS;
  logger.info('CHARDHO AI worker started');
  for (;;) { await tick(); await new Promise((r) => setTimeout(r, 10_000)); }
}
main().catch((e) => { logger.fatal(e); process.exit(1); });
