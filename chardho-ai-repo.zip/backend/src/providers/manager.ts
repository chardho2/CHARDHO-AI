import { prisma } from '../lib/db';
import { allowPaid, env } from '../lib/env';
import { decrypt } from '../lib/crypto';
import { HttpError } from '../lib/errors';
import { logger } from '../lib/logger';
import { PROVIDERS } from './impl';
import { GenRequest, GenResult } from './types';

/** Seed defaults on first boot; owner can edit via /api/admin/providers. */
export async function ensureProviderConfigs() {
  const defaults = [
    { key: 'ollama', name: 'Ollama (local)', model: env.OLLAMA_MODEL, paid: false, priority: 10, capabilities: ['text', 'json'] },
    { key: 'gemini', name: 'Google Gemini', model: env.GEMINI_MODEL, paid: false, priority: 20, capabilities: ['text', 'json'] },
    { key: 'openai', name: 'OpenAI', model: env.OPENAI_MODEL, paid: true, priority: 90, capabilities: ['text', 'json', 'image'] },
  ];
  for (const d of defaults) await prisma.providerConfig.upsert({ where: { key: d.key }, create: d, update: {} });
}

async function dailyCount(provider: string) {
  const since = new Date(); since.setHours(0, 0, 0, 0);
  return prisma.apiProviderCost.count({ where: { provider, createdAt: { gte: since } } });
}

/**
 * Pick providers in priority order. Paid providers are skipped unless the owner
 * has explicitly allowed paid usage (env flag AND provider flagged enabled).
 */
export async function generateText(req: GenRequest, need: string[] = ['text']): Promise<GenResult> {
  const cfgs = await prisma.providerConfig.findMany({ where: { enabled: true }, orderBy: { priority: 'asc' } });
  const errors: string[] = [];
  for (const cfg of cfgs) {
    const p = PROVIDERS[cfg.key];
    if (!p || (cfg.paid && !allowPaid) || !need.every((n) => cfg.capabilities.includes(n))) continue;
    if (cfg.dailyLimit && (await dailyCount(cfg.key)) >= cfg.dailyLimit) { errors.push(`${cfg.key}: daily limit reached`); continue; }
    const pc = { apiKey: cfg.apiKeyEnc ? decrypt(cfg.apiKeyEnc) : null, baseUrl: cfg.baseUrl, model: cfg.model };
    if (!(await p.isAvailable(pc))) { errors.push(`${cfg.key}: unavailable`); continue; }
    try {
      const out = await p.generate(req, pc);
      const costUsd = cfg.paid ? (out.tokensIn * p.pricing[0] + out.tokensOut * p.pricing[1]) / 1_000_000 : 0;
      await prisma.apiProviderCost.create({ data: { provider: cfg.key, model: cfg.model, tokensIn: out.tokensIn, tokensOut: out.tokensOut, costUsd } });
      return out;
    } catch (e) {
      logger.warn({ provider: cfg.key, err: (e as Error).message }, 'provider failed, trying next');
      errors.push(`${cfg.key}: ${(e as Error).message}`);
    }
  }
  throw new HttpError(503, 'No AI provider is currently available. Free capacity may be exhausted; try again later.', errors);
}
