import { AiProvider } from './types';
import { env } from '../lib/env';

async function postJson(url: string, body: unknown, headers: Record<string, string> = {}, timeoutMs = 120_000) {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(timeoutMs) });
  if (!r.ok) throw new Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 300)}`);
  return r.json() as Promise<any>;
}

export const ollama: AiProvider = {
  key: 'ollama', paid: false, capabilities: ['text', 'json'], pricing: [0, 0],
  async isAvailable(cfg) {
    try { return (await fetch(`${cfg.baseUrl || env.OLLAMA_BASE_URL}/api/tags`, { signal: AbortSignal.timeout(2000) })).ok; } catch { return false; }
  },
  async generate(req, cfg) {
    const j = await postJson(`${cfg.baseUrl || env.OLLAMA_BASE_URL}/api/chat`, {
      model: cfg.model, stream: false, format: req.json ? 'json' : undefined,
      options: { temperature: req.temperature ?? 0.7, num_predict: req.maxTokens },
      messages: [{ role: 'system', content: req.system }, { role: 'user', content: req.prompt }],
    });
    return { text: j.message?.content ?? '', tokensIn: j.prompt_eval_count ?? 0, tokensOut: j.eval_count ?? 0, provider: 'ollama', model: cfg.model };
  },
};

export const gemini: AiProvider = {
  key: 'gemini', paid: false, capabilities: ['text', 'json'], pricing: [0, 0], // free tier; owner can flip `paid` in admin if billing is enabled
  async isAvailable(cfg) { return !!(cfg.apiKey || env.GEMINI_API_KEY); },
  async generate(req, cfg) {
    const key = cfg.apiKey || env.GEMINI_API_KEY!;
    const j = await postJson(`https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent`, {
      systemInstruction: { parts: [{ text: req.system }] },
      contents: [{ role: 'user', parts: [{ text: req.prompt }] }],
      generationConfig: { temperature: req.temperature ?? 0.7, maxOutputTokens: req.maxTokens, responseMimeType: req.json ? 'application/json' : undefined },
    }, { 'x-goog-api-key': key });
    const text = j.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ?? '';
    return { text, tokensIn: j.usageMetadata?.promptTokenCount ?? 0, tokensOut: j.usageMetadata?.candidatesTokenCount ?? 0, provider: 'gemini', model: cfg.model };
  },
};

/** Works for OpenAI and any OpenAI-compatible endpoint (Groq, OpenRouter, vLLM, LM Studio...) via baseUrl. */
export const openai: AiProvider = {
  key: 'openai', paid: true, capabilities: ['text', 'json', 'image'], pricing: [0.15, 0.6],
  async isAvailable(cfg) { return !!(cfg.apiKey || env.OPENAI_API_KEY); },
  async generate(req, cfg) {
    const key = cfg.apiKey || env.OPENAI_API_KEY!;
    const j = await postJson(`${cfg.baseUrl || 'https://api.openai.com/v1'}/chat/completions`, {
      model: cfg.model, temperature: req.temperature ?? 0.7, max_tokens: req.maxTokens,
      response_format: req.json ? { type: 'json_object' } : undefined,
      messages: [{ role: 'system', content: req.system }, { role: 'user', content: req.prompt }],
    }, { authorization: `Bearer ${key}` });
    return { text: j.choices?.[0]?.message?.content ?? '', tokensIn: j.usage?.prompt_tokens ?? 0, tokensOut: j.usage?.completion_tokens ?? 0, provider: 'openai', model: cfg.model };
  },
};

export const PROVIDERS: Record<string, AiProvider> = { ollama, gemini, openai };
