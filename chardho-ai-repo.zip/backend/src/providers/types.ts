export interface GenRequest { system: string; prompt: string; json?: boolean; temperature?: number; maxTokens?: number }
export interface GenResult { text: string; tokensIn: number; tokensOut: number; provider: string; model: string }
export interface AiProvider {
  key: string;
  paid: boolean;
  capabilities: string[];
  /** USD per 1M tokens [in, out]; 0 for local/free tier */
  pricing: [number, number];
  isAvailable(cfg: { apiKey?: string | null; baseUrl?: string | null }): Promise<boolean>;
  generate(req: GenRequest, cfg: { apiKey?: string | null; baseUrl?: string | null; model: string }): Promise<GenResult>;
}
