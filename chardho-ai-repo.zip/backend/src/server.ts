import { createApp } from './app';
import { env } from './lib/env';
import { logger } from './lib/logger';
import { prisma } from './lib/db';
import { AGENTS } from './agents/definitions';
import { ensureProviderConfigs } from './providers/manager';

async function bootstrap() {
  for (const a of AGENTS) {
    await prisma.aiAgent.upsert({ where: { key: a.key }, create: { key: a.key, name: a.name, description: a.description, systemPrompt: a.systemPrompt, tools: a.tools }, update: { name: a.name, description: a.description, tools: a.tools } });
  }
  await ensureProviderConfigs();
  const app = createApp();
  const server = app.listen(env.PORT, () => logger.info(`CHARDHO AI API listening on :${env.PORT}`));
  const stop = async () => { server.close(); await prisma.$disconnect(); process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
bootstrap().catch((e) => { logger.fatal(e); process.exit(1); });
